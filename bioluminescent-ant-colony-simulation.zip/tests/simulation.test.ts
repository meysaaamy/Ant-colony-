import { describe, expect, it } from "vitest";
import { AntColonyEngine, weberFechnerLaw } from "../lib/ant-soa-engine";
import {
  computeSaturatingDeposit,
  PheromoneGrid,
} from "../lib/pheromone-grid";
import { DEFAULT_SIMULATION_PARAMS } from "../lib/types";

describe("Bioluminescent Macro-Sanctuary Scientific Kernel", () => {
  it("computes Weber-Fechner logarithmic neural stimulus S = ln(1 + C)", () => {
    expect(weberFechnerLaw(0)).toBeCloseTo(0, 6);
    expect(weberFechnerLaw(Math.E - 1)).toBeCloseTo(1.0, 6);
    expect(weberFechnerLaw(99)).toBeCloseTo(Math.log(100), 6);
  });

  it("executes exact exponential pheromone evaporation with 3.5x faster alarm decay", () => {
    const grid = new PheromoneGrid(120, 120);
    const idx = 5 * grid.cols + 5;
    grid.foodTrail[idx] = 80;
    grid.alarm[idx] = 80;

    const dt = 0.1;
    const lambda = 0.2;
    // Step with zero diffusion to isolate exact exponential decay
    grid.stepPhysics(dt, lambda, 0.0);

    const expectedTrail = 80 * Math.exp(-dt * lambda);
    const expectedAlarm = 80 * Math.exp(-dt * lambda * 3.5);

    expect(grid.foodTrail[idx]).toBeCloseTo(expectedTrail, 4);
    expect(grid.alarm[idx]).toBeCloseTo(expectedAlarm, 4);
  });

  it("enforces strict zero-flux Neumann boundary conditions across solid walls", () => {
    const grid = new PheromoneGrid(180, 180);
    // Construct an impenetrable vertical wall at column x = 10
    for (let y = 0; y < grid.rows; y++) {
      grid.wallMask[y * grid.cols + 10] = 1;
    }

    // Deposit maximum pheromone immediately left of the wall at (9, 10)
    grid.foodTrail[10 * grid.cols + 9] = 100.0;

    // Run 10 diffusion ticks
    for (let step = 0; step < 10; step++) {
      grid.stepPhysics(1 / 60, 0.05, 0.24);
    }

    // Wall cell (10, 10) and right-of-wall cell (11, 10) must have strictly 0 concentration
    expect(grid.foodTrail[10 * grid.cols + 10]).toBe(0);
    expect(grid.foodTrail[10 * grid.cols + 11]).toBe(0);

    // Line-of-sight across the wall must also be blocked
    const losAcrossWall = grid.hasLineOfSight(
      9 * grid.cellSize,
      10 * grid.cellSize,
      11 * grid.cellSize,
      10 * grid.cellSize
    );
    expect(losAcrossWall).toBe(false);
  });

  it("calculates saturating age-attenuated deposition accurately", () => {
    const baseStrength = 25;
    const decayRate = 0.1;
    const timeSinceLastVisit = 4.0;
    const localConc = 50.0;

    const expected =
      (baseStrength * Math.exp(-decayRate * timeSinceLastVisit)) /
      (1.0 + 0.08 * localConc);
    const actual = computeSaturatingDeposit(
      baseStrength,
      decayRate,
      timeSinceLastVisit,
      localConc
    );

    expect(actual).toBeCloseTo(expected, 6);
  });

  it("spawns 1 new ant at the Nest for every 3 delivered food units", () => {
    const grid = new PheromoneGrid(400, 400);
    const colony = new AntColonyEngine(400, 400);
    colony.resetColony(200, 200, 10, 500);

    expect(colony.activeCount).toBe(10);

    // Place 3 food-carrying ants inside the Nest harvest radius
    for (let i = 0; i < 3; i++) {
      colony.x[i] = 200;
      colony.y[i] = 200;
      colony.carryingFood[i] = 1;
    }

    colony.stepAnts(1 / 60, grid, DEFAULT_SIMULATION_PARAMS);

    expect(colony.nest.storedFood).toBe(3);
    expect(colony.activeCount).toBe(11);
  });
});
