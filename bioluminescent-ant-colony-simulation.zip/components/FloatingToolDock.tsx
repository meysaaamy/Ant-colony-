"use client";

import React, { useState } from "react";
import {
  AlarmIcon,
  EraserIcon,
  FoodClusterIcon,
  FoodTrailIcon,
  HomeTrailIcon,
  WallIcon,
} from "./ui/icons";
import { DEFAULT_SIMULATION_PARAMS, ToolMode } from "@/lib/types";

interface ToolConfig {
  id: ToolMode;
  label: string;
  shortLabel: string;
  color: string;
  shortcut: string;
  Icon: React.ComponentType<{ className?: string; size?: number }>;
}

export const TOOL_CONFIGS: ToolConfig[] = [
  {
    id: "foodTrail",
    label: "Food trail",
    shortLabel: "Food",
    color: "#ffae00",
    shortcut: "1",
    Icon: FoodTrailIcon,
  },
  {
    id: "homeGuide",
    label: "Home trail",
    shortLabel: "Home",
    color: "#00f0ff",
    shortcut: "2",
    Icon: HomeTrailIcon,
  },
  {
    id: "alarm",
    label: "Alarm",
    shortLabel: "Alarm",
    color: "#ff0a43",
    shortcut: "3",
    Icon: AlarmIcon,
  },
  {
    id: "foodCluster",
    label: "Food cluster",
    shortLabel: "Crystal",
    color: "#00e676",
    shortcut: "4",
    Icon: FoodClusterIcon,
  },
  {
    id: "wall",
    label: "Wall",
    shortLabel: "Wall",
    color: "#384d6b",
    shortcut: "5",
    Icon: WallIcon,
  },
  {
    id: "eraser",
    label: "Eraser",
    shortLabel: "Erase",
    color: "#cbd5e1",
    shortcut: "6",
    Icon: EraserIcon,
  },
];

interface FloatingToolDockProps {
  activeTool: ToolMode;
  brushRadius: number;
  depositionIntensity: number;
  isChromeDimmed: boolean;
  onSelectTool: (tool: ToolMode) => void;
  onChangeBrushRadius: (radius: number) => void;
  onChangeDepositionIntensity: (intensity: number) => void;
}

export function FloatingToolDock({
  activeTool,
  brushRadius,
  depositionIntensity,
  isChromeDimmed,
  onSelectTool,
  onChangeBrushRadius,
  onChangeDepositionIntensity,
}: FloatingToolDockProps) {
  const [brushPopoverOpen, setBrushPopoverOpen] = useState(false);

  const activeConfig =
    TOOL_CONFIGS.find((t) => t.id === activeTool) || TOOL_CONFIGS[0];

  const handleToolClick = (tool: ToolMode) => {
    if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
      try {
        navigator.vibrate(8);
      } catch {
        // Ignore vibration errors on unsupported devices
      }
    }
    onSelectTool(tool);
  };

  // Visual preview circle diameter inside Brush Chip (clamped 8px..28px)
  const previewDiameter = Math.max(8, Math.min(28, Math.round((brushRadius / 72) * 28)));

  return (
    <div
      className={`fixed bottom-14 md:bottom-4 left-0 right-0 z-30 flex flex-col items-center pointer-events-none safe-bottom safe-x transition-opacity duration-200 ${
        isChromeDimmed ? "opacity-30" : "opacity-100"
      }`}
    >
      <div className="relative flex flex-col items-end w-full max-w-[392px]">
        {/* Compact Brush Chip Popover */}
        {brushPopoverOpen && !isChromeDimmed && (
          <div
            className="glass-chrome glass-chrome-blur pointer-events-auto mb-2 w-72 p-4 rounded-[20px] text-slate-100 shadow-2xl"
            role="dialog"
            aria-label="Brush size and intensity controls"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                Brush Calibration
              </span>
              <span className="text-[11px] text-slate-400">
                Shortcuts: [ and ]
              </span>
            </div>

            {/* Brush Radius Slider */}
            <div className="mb-3">
              <div className="flex justify-between text-xs mb-1">
                <label htmlFor="dock-brush-radius" className="text-slate-200 font-medium">
                  Brush radius (world units)
                </label>
                <span className="tabular-nums font-semibold text-[#00f0ff]">
                  {brushRadius} u
                </span>
              </div>
              <input
                id="dock-brush-radius"
                type="range"
                min={12}
                max={72}
                step={2}
                value={brushRadius}
                aria-valuetext={`${brushRadius} logical world units`}
                onChange={(e) => onChangeBrushRadius(Number(e.target.value))}
                onDoubleClick={() =>
                  onChangeBrushRadius(DEFAULT_SIMULATION_PARAMS.brushRadius)
                }
                className="sanctuary-slider"
              />
              <p className="text-[11px] text-slate-400 leading-tight">
                Controls stroke width. Double-tap slider to reset ({DEFAULT_SIMULATION_PARAMS.brushRadius} u).
              </p>
            </div>

            {/* Deposition Intensity Slider */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <label htmlFor="dock-brush-intensity" className="text-slate-200 font-medium">
                  Deposition intensity (flux)
                </label>
                <span className="tabular-nums font-semibold text-[#ffae00]">
                  {depositionIntensity}%
                </span>
              </div>
              <input
                id="dock-brush-intensity"
                type="range"
                min={10}
                max={100}
                step={2}
                value={depositionIntensity}
                aria-valuetext={`${depositionIntensity} percent concentration`}
                onChange={(e) =>
                  onChangeDepositionIntensity(Number(e.target.value))
                }
                onDoubleClick={() =>
                  onChangeDepositionIntensity(
                    DEFAULT_SIMULATION_PARAMS.depositionIntensity
                  )
                }
                className="sanctuary-slider"
              />
              <p className="text-[11px] text-slate-400 leading-tight">
                Chemical saturation added per brush dab.
              </p>
            </div>
          </div>
        )}

        {/* Floating Brush Chip above the right end of the dock */}
        <button
          type="button"
          onClick={() => setBrushPopoverOpen((prev) => !prev)}
          aria-label={`Brush size ${brushRadius} units, intensity ${depositionIntensity} percent. Toggle brush popover.`}
          aria-expanded={brushPopoverOpen}
          title="Adjust Brush Radius & Deposition Intensity ([ / ])"
          className={`glass-chrome glass-chrome-blur mb-2 px-3 min-h-[48px] rounded-full flex items-center gap-2.5 text-xs font-medium text-slate-200 hover:text-white active:scale-95 transition-all ${
            isChromeDimmed ? "pointer-events-none" : "pointer-events-auto"
          }`}
        >
          <span
            className="rounded-full inline-block transition-all"
            style={{
              width: `${previewDiameter}px`,
              height: `${previewDiameter}px`,
              backgroundColor: `${activeConfig.color}33`,
              border: `2px ${activeTool === "eraser" ? "dashed" : "solid"} ${activeConfig.color}`,
            }}
          />
          <span className="tabular-nums font-semibold">{brushRadius}u</span>
          <span className="text-slate-400">·</span>
          <span className="tabular-nums text-slate-300">{depositionIntensity}%</span>
        </button>

        {/* Main 6-Tool Dock */}
        <nav
          aria-label="Scent painting and terrain tools"
          className={`glass-chrome glass-chrome-blur w-full px-1.5 py-1.5 rounded-[28px] grid grid-cols-6 gap-1 select-none ${
            isChromeDimmed ? "pointer-events-none" : "pointer-events-auto"
          }`}
        >
          {TOOL_CONFIGS.map((tool) => {
            const isSelected = activeTool === tool.id;
            const Icon = tool.Icon;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => handleToolClick(tool.id)}
                aria-label={`${tool.label} tool (Shortcut ${tool.shortcut})`}
                aria-pressed={isSelected}
                title={`${tool.label} [Key ${tool.shortcut}]`}
                style={{
                  borderColor: isSelected ? tool.color : "transparent",
                  boxShadow: isSelected
                    ? `0 4px 16px -2px ${tool.color}55, inset 0 1px 0 0 ${tool.color}66`
                    : "none",
                }}
                className={`min-h-[50px] rounded-[20px] flex flex-col items-center justify-center gap-0.5 transition-all duration-150 border ${
                  isSelected
                    ? "bg-[#131d31] -translate-y-1 text-white"
                    : "bg-transparent text-slate-400 hover:text-slate-200 hover:bg-white/5"
                }`}
              >
                <span style={{ color: tool.color }}>
                  <Icon size={20} />
                </span>
                <span className="text-[10px] font-medium tracking-tight leading-none">
                  {tool.shortLabel}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
