"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  BilateralAntennaDiagramSVG,
  ChevronDownIcon,
  CloseIcon,
  DoubleBridgeDiagramSVG,
  PheromoneLutLegendSVG,
} from "./ui/icons";

interface FieldGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface GuideSection {
  id: string;
  title: string;
  subtitle: string;
  inNature: string;
  inSandbox: string;
  Diagram: React.ComponentType<{ className?: string }>;
}

const GUIDE_SECTIONS: GuideSection[] = [
  {
    id: "tropotaxis",
    title: "1. Bilateral Tropotaxis & Weber-Fechner Sensing",
    subtitle: "How individual ants surf invisible chemical plumes",
    inNature:
      "Foraging workers of Lasius niger and Linepithema humile sweep their elbowed antennae ahead of their mandibles, comparing odorant concentrations between Left and Right chemoreceptors. Because neural receptor firing scales logarithmically with stimulus intensity (Weber-Fechner Law, S = ln(1 + C)), ants remain sensitive across four orders of magnitude of trail concentration without saturating.",
    inSandbox:
      "Each agent samples Left (-theta), Center (0), and Right (+theta) points 17.5 units ahead using line-of-sight wall raycasts. Steering torque is proportional to alpha * (S_right - S_left) / (1 + 0.22 * S_center), blended with persistent Ornstein-Uhlenbeck wander noise and orthokinetic speed modulation.",
    Diagram: BilateralAntennaDiagramSVG,
  },
  {
    id: "pheromones",
    title: "2. Tri-Channel Chemical Ecology & Saturating Deposition",
    subtitle: "Trail recruitment, footprint hydrocarbons & mandibular alarm",
    inNature:
      "Ant colonies rely on multiple glandular blends with distinct volatility profiles. Returning nectar-carriers deposit durable recruitment esters from their hindgut or poison gland; outgoing explorers leave passive cuticular hydrocarbon footprints; and disturbed workers release volatile mandibular ketones that evaporate rapidly after dispersing threats.",
    inSandbox:
      "Three double-buffered Float32Array fields evolve via exact exponential decay exp(-dt * lambda) (with Alarm decaying 3.5x faster) and CFL-stable 3x3 Laplacian diffusion with strict zero-flux Neumann wall boundaries. Deposition attenuates with time-since-visit and local saturation: deposit = (base * exp(-k * t)) / (1 + 0.08 * C).",
    Diagram: PheromoneLutLegendSVG,
  },
  {
    id: "autocatalysis",
    title: "3. Deneubourg's Double Bridge & Emergent Shortest Path",
    subtitle: "Self-organized colony intelligence without central command",
    inNature:
      "In Jean-Louis Deneubourg's classic 1989 double-bridge experiment, ants traversing a shorter branch reach the food source and return to the nest sooner than ants on a longer branch. Their early return reinforces the short branch with fresh trail pheromone before evaporation can erode it, triggering an autocatalytic symmetry-breaking cascade.",
    inSandbox:
      "Load 'Deneubourg's Double Bridge' in the World tab to watch emergent shortest-path convergence live. You can also paint custom Amber Food Trails to redirect traffic or sculpt Basalt Walls to force adaptive detour discovery.",
    Diagram: DoubleBridgeDiagramSVG,
  },
];

export function FieldGuideModal({ isOpen, onClose }: FieldGuideModalProps) {
  const [openId, setOpenId] = useState<string>("tropotaxis");
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    closeBtnRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      } else if (e.key === "Tab" && dialogRef.current) {
        const focusables = dialogRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="field-guide-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        className="glass-chrome glass-chrome-blur w-full sm:max-w-[560px] h-[92dvh] sm:h-auto sm:max-h-[86dvh] rounded-t-[28px] sm:rounded-[28px] flex flex-col overflow-hidden text-slate-100 shadow-2xl"
      >
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-[#384d6b]/50 flex items-center justify-between shrink-0">
          <div>
            <span className="text-[11px] uppercase tracking-widest text-[#00f0ff] font-semibold block">
              Computational Neuroethology Monograph
            </span>
            <h2
              id="field-guide-title"
              className="font-display text-lg sm:text-xl font-bold text-white"
            >
              Bioluminescent Macro-Sanctuary Field Guide
            </h2>
          </div>
          <button
            ref={closeBtnRef}
            type="button"
            onClick={onClose}
            aria-label="Close Field Guide (Escape)"
            className="min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center bg-[#0f172a] hover:bg-[#1e293b] text-slate-200 border border-[#384d6b]/60 transition-all"
          >
            <CloseIcon size={18} />
          </button>
        </div>

        {/* Scrollable Accordion Content */}
        <div className="p-5 overflow-y-auto space-y-3 text-xs sm:text-sm">
          {GUIDE_SECTIONS.map((sec) => {
            const isExpanded = openId === sec.id;
            const Diagram = sec.Diagram;
            return (
              <div
                key={sec.id}
                className="rounded-2xl border border-[#384d6b]/60 bg-[#070b14]/90 overflow-hidden"
              >
                <button
                  type="button"
                  aria-expanded={isExpanded}
                  onClick={() => setOpenId(isExpanded ? "" : sec.id)}
                  className="w-full px-4 py-3.5 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
                >
                  <div>
                    <div className="font-display font-semibold text-sm sm:text-base text-slate-100">
                      {sec.title}
                    </div>
                    <div className="text-xs text-slate-400">{sec.subtitle}</div>
                  </div>
                  <ChevronDownIcon
                    size={18}
                    className={`text-[#00f0ff] shrink-0 transition-transform duration-200 ${
                      isExpanded ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {isExpanded && (
                  <div className="px-4 pb-4 pt-1 space-y-3 border-t border-[#384d6b]/35">
                    <Diagram />
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="p-3 rounded-xl bg-[#0d1526] border border-[#00e676]/30">
                        <div className="text-[11px] font-bold uppercase tracking-wider text-[#00e676] mb-1">
                          In nature
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {sec.inNature}
                        </p>
                      </div>
                      <div className="p-3 rounded-xl bg-[#0d1526] border border-[#00f0ff]/30">
                        <div className="text-[11px] font-bold uppercase tracking-wider text-[#00f0ff] mb-1">
                          In this sandbox
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {sec.inSandbox}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Credits & Procedural Architecture Ledger */}
          <div className="p-4 rounded-2xl border border-[#384d6b]/50 bg-[#050811] space-y-2">
            <h3 className="font-display text-sm font-semibold text-[#ffae00]">
              Credits &amp; Procedural Architecture
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              100% of textures, articulated 8-frame x 3-state ant sprites, faceted emerald crystal clusters, 256-entry non-linear RGB LUTs, and FBM basalt caverns are deterministically synthesized at boot in pure TypeScript with zero external engine dependencies.
            </p>
            <div className="flex flex-wrap gap-2 pt-1 text-[11px] text-slate-400 font-mono">
              <span className="px-2 py-1 rounded bg-[#0f172a] border border-[#384d6b]/40">
                SoA Capacity: 3,000 Agents
              </span>
              <span className="px-2 py-1 rounded bg-[#0f172a] border border-[#384d6b]/40">
                O(1) Spatial Hash: 24u Cell
              </span>
              <span className="px-2 py-1 rounded bg-[#0f172a] border border-[#384d6b]/40">
                Pheromone Grid: 6u Double-Buffered
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
