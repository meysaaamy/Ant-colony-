"use client";

import React from "react";

interface ToastOverlayProps {
  toastMessage: string | null;
  captionMessage: string | null;
  showFirstRunGhostPrompt: boolean;
  isChromeDimmed: boolean;
}

export function ToastOverlay({
  toastMessage,
  captionMessage,
  showFirstRunGhostPrompt,
  isChromeDimmed,
}: ToastOverlayProps) {
  const activeCaption = showFirstRunGhostPrompt
    ? "Draw an amber trail from the nest to the crystals."
    : captionMessage;

  return (
    <div
      className={`fixed bottom-40 md:bottom-32 left-0 right-0 z-30 flex flex-col items-center gap-2 pointer-events-none px-4 transition-opacity duration-200 ${
        isChromeDimmed ? "opacity-40" : "opacity-100"
      }`}
    >
      {/* Contextual 1-line tool / first-run caption */}
      {activeCaption && (
        <div className="glass-chrome glass-chrome-blur px-4 py-2 rounded-full text-xs sm:text-sm font-medium text-[#fff3b0] border border-[#ffae00]/50 shadow-lg text-center max-w-md">
          {activeCaption}
        </div>
      )}

      {/* Single non-stacking aria-live="polite" toast */}
      <div aria-live="polite" aria-atomic="true">
        {toastMessage && (
          <div className="glass-chrome glass-chrome-blur px-4 py-2 rounded-full text-xs sm:text-sm font-semibold text-[#00f0ff] border border-[#00f0ff]/50 shadow-lg text-center max-w-md">
            {toastMessage}
          </div>
        )}
      </div>
    </div>
  );
}
