"use client";

import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import { AntColonyEngine } from "@/lib/ant-soa-engine";
import { PheromoneGrid } from "@/lib/pheromone-grid";
import { applyPresetWorld } from "@/lib/presets";
import { generateProceduralAssets } from "@/lib/procedural-assets";
import { SanctuaryRenderer } from "@/lib/renderer";
import {
  ActiveStrokeState,
  PresetId,
  SimulationParams,
  TelemetrySnapshot,
  ToolMode,
} from "@/lib/types";

export interface SanctuaryCanvasHandle {
  clearPheromones: () => void;
  resetCurrentPreset: () => void;
  loadPreset: (presetId: PresetId) => void;
}

interface SanctuaryCanvasProps {
  activeTool: ToolMode;
  params: SimulationParams;
  activePreset: PresetId;
  showFirstRunGhost: boolean;
  onDismissFirstRunGhost: () => void;
  onStrokeStateChange: (isDrawing: boolean) => void;
  onTelemetryUpdate: (snapshot: TelemetrySnapshot) => void;
  onFirstFoodDelivered: () => void;
  onCapacityReached: () => void;
}

const MAX_RIBBON_POINTS = 48;

export const SanctuaryCanvas = forwardRef<
  SanctuaryCanvasHandle,
  SanctuaryCanvasProps
>(function SanctuaryCanvas(
  {
    activeTool,
    params,
    activePreset,
    showFirstRunGhost,
    onDismissFirstRunGhost,
    onStrokeStateChange,
    onTelemetryUpdate,
    onFirstFoodDelivered,
    onCapacityReached,
  },
  ref
) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [bootSplashVisible, setBootSplashVisible] = useState(true);
  const [presetCrossfade, setPresetCrossfade] = useState(false);

  // Mutable refs for zero-allocation access inside requestAnimationFrame
  const paramsRef = useRef<SimulationParams>(params);
  paramsRef.current = params;

  const toolRef = useRef<ToolMode>(activeTool);
  toolRef.current = activeTool;

  const presetRef = useRef<PresetId>(activePreset);
  presetRef.current = activePreset;

  const showGhostRef = useRef<boolean>(showFirstRunGhost);
  showGhostRef.current = showFirstRunGhost;

  const gridRef = useRef<PheromoneGrid | null>(null);
  const colonyRef = useRef<AntColonyEngine | null>(null);
  const rendererRef = useRef<SanctuaryRenderer | null>(null);

  const displayCssSizeRef = useRef<{ width: number; height: number }>({
    width: 1280,
    height: 720,
  });

  // Preallocated active pointer stroke state
  const strokeRef = useRef<ActiveStrokeState>({
    active: false,
    pointerId: null,
    tool: "foodTrail",
    worldX: 0,
    worldY: 0,
    lastWorldX: 0,
    lastWorldY: 0,
    prevWorldX: 0,
    prevWorldY: 0,
    startX: 0,
    startY: 0,
    startRipple: 0,
    ribbon: Array.from({ length: MAX_RIBBON_POINTS }, () => ({
      x: 0,
      y: 0,
      radius: 28,
      age: 0,
    })),
    ribbonCount: 0,
  });

  useImperativeHandle(ref, () => ({
    clearPheromones: () => {
      gridRef.current?.clearPheromones();
    },
    resetCurrentPreset: () => {
      const grid = gridRef.current;
      const colony = colonyRef.current;
      if (!grid || !colony) return;
      setPresetCrossfade(true);
      window.setTimeout(() => {
        applyPresetWorld(
          presetRef.current,
          grid,
          colony,
          paramsRef.current.maxPopulation
        );
        setPresetCrossfade(false);
      }, 160);
    },
    loadPreset: (presetId: PresetId) => {
      const grid = gridRef.current;
      const colony = colonyRef.current;
      if (!grid || !colony) return;
      presetRef.current = presetId;
      setPresetCrossfade(true);
      window.setTimeout(() => {
        applyPresetWorld(
          presetId,
          grid,
          colony,
          paramsRef.current.maxPopulation
        );
        setPresetCrossfade(false);
      }, 160);
    },
  }));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // 1. Determine fixed logical simulation world coordinate space at boot
    // Minimum 720x1280 (portrait) or 1280x720 (landscape) matching boot aspect ratio
    const bootW = Math.max(360, window.innerWidth || 1280);
    const bootH = Math.max(640, window.innerHeight || 720);
    const aspect = bootW / bootH;

    let worldWidth = 1280;
    let worldHeight = 720;
    if (aspect < 1) {
      worldWidth = 720;
      worldHeight = Math.max(1280, Math.round(720 / aspect));
      worldHeight = Math.min(1440, worldHeight);
    } else {
      worldHeight = 720;
      worldWidth = Math.max(1280, Math.round(720 * aspect));
      worldWidth = Math.min(1600, worldWidth);
    }

    // 2. Bake procedural textures & sprite-sheets and initialize SoA + PheromoneGrid
    const assets = generateProceduralAssets();
    const grid = new PheromoneGrid(worldWidth, worldHeight);
    const colony = new AntColonyEngine(worldWidth, worldHeight);
    colony.onFirstFoodDelivered = onFirstFoodDelivered;
    colony.onCapacityReached = onCapacityReached;

    applyPresetWorld(
      presetRef.current,
      grid,
      colony,
      paramsRef.current.maxPopulation
    );

    const renderer = new SanctuaryRenderer(
      worldWidth,
      worldHeight,
      grid,
      assets
    );

    gridRef.current = grid;
    colonyRef.current = colony;
    rendererRef.current = renderer;

    // Update display canvas resolution without wiping simulation state
    const syncDisplayCanvasSize = () => {
      const c = canvasRef.current;
      if (!c) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cssW = Math.max(320, window.innerWidth);
      const cssH = Math.max(320, window.innerHeight);
      displayCssSizeRef.current.width = cssW;
      displayCssSizeRef.current.height = cssH;
      c.width = Math.round(cssW * dpr);
      c.height = Math.round(cssH * dpr);
    };

    syncDisplayCanvasSize();

    // Fade out boot splash after 300ms
    const splashTimer = window.setTimeout(() => {
      setBootSplashVisible(false);
    }, 300);

    // Debounced (150ms) window and visualViewport resize handler preserving 100% world state
    let resizeTimeout: number | null = null;
    const handleResize = () => {
      if (resizeTimeout !== null) {
        window.clearTimeout(resizeTimeout);
      }
      resizeTimeout = window.setTimeout(() => {
        syncDisplayCanvasSize();
      }, 150);
    };

    window.addEventListener("resize", handleResize);
    window.visualViewport?.addEventListener("resize", handleResize);

    // Document visibilitychange lifecycle auto-pause & accumulator reset
    let isDocumentHidden = document.hidden;
    let lastFrameTime = performance.now();
    let physicsAccumulator = 0;

    const handleVisibilityChange = () => {
      isDocumentHidden = document.hidden;
      if (!isDocumentHidden) {
        lastFrameTime = performance.now();
        physicsAccumulator = 0;
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);

    // Main simulation & rendering requestAnimationFrame loop
    let rafId = 0;
    let lastTelemetryTime = performance.now();
    let ghostPhase = 0;
    const FIXED_DT = 1 / 60;

    const tick = (now: number) => {
      rafId = window.requestAnimationFrame(tick);
      if (isDocumentHidden) return;

      const rawDeltaMs = now - lastFrameTime;
      lastFrameTime = now;
      renderer.recordFrameDelta(rawDeltaMs);

      const dtSeconds = Math.min(0.05, Math.max(0.001, rawDeltaMs / 1000));
      const currentParams = paramsRef.current;

      // Update stroke ribbon ages & start ripple
      const st = strokeRef.current;
      if (st.startRipple > 0) {
        st.startRipple = Math.max(0, st.startRipple - dtSeconds * 2.5);
      }
      if (st.ribbonCount > 0) {
        let writeIdx = 0;
        for (let i = 0; i < st.ribbonCount; i++) {
          const pt = st.ribbon[i];
          pt.age += dtSeconds;
          if (pt.age < 0.32) {
            if (writeIdx !== i) {
              const target = st.ribbon[writeIdx];
              target.x = pt.x;
              target.y = pt.y;
              target.radius = pt.radius;
              target.age = pt.age;
            }
            writeIdx++;
          }
        }
        st.ribbonCount = writeIdx;
      }

      // Continuous brush emission while pointer is held stationary
      if (
        st.active &&
        (st.tool === "foodTrail" ||
          st.tool === "homeGuide" ||
          st.tool === "alarm")
      ) {
        grid.applyBrushDab(
          st.worldX,
          st.worldY,
          currentParams.brushRadius,
          st.tool,
          currentParams.depositionIntensity * 0.35,
          colony.nest.x,
          colony.nest.y,
          colony.nest.radius + 14
        );
      }

      // Advance Fixed-Timestep Simulation Physics
      if (!currentParams.paused) {
        physicsAccumulator += dtSeconds;
        // Clamp accumulator to prevent spiral-of-death frame spikes
        if (physicsAccumulator > FIXED_DT * 3) {
          physicsAccumulator = FIXED_DT * 3;
        }

        const timeScale = currentParams.timeScale;
        while (physicsAccumulator >= FIXED_DT) {
          physicsAccumulator -= FIXED_DT;
          for (let sub = 0; sub < timeScale; sub++) {
            if (renderer.shouldStepDiffusionThisTick()) {
              grid.stepPhysics(
                FIXED_DT,
                currentParams.evaporationRate,
                currentParams.diffusionRate
              );
            }
            colony.stepAnts(FIXED_DT, grid, currentParams);
          }
        }
      }

      // First-run ghost stroke progress
      let ghostProgress: number | null = null;
      if (showGhostRef.current) {
        ghostPhase = (ghostPhase + dtSeconds * 0.55) % 1.0;
        ghostProgress = ghostPhase;
      }

      // Render Multi-Layer Frame
      const ctx = canvas.getContext("2d");
      if (ctx) {
        renderer.renderFrame(
          ctx,
          canvas.width,
          canvas.height,
          grid,
          colony,
          st,
          ghostProgress,
          dtSeconds
        );
      }

      // Emit HUD Telemetry throttled to 10Hz (every 100ms)
      if (now - lastTelemetryTime >= 100) {
        lastTelemetryTime = now;
        onTelemetryUpdate({
          fps: renderer.currentFps,
          activeAnts: colony.activeCount,
          storedFood: colony.nest.storedFood,
          qualityTier: renderer.qualityTier,
          presetId: presetRef.current,
        });
      }
    };

    rafId = window.requestAnimationFrame(tick);

    return () => {
      window.cancelAnimationFrame(rafId);
      window.clearTimeout(splashTimer);
      if (resizeTimeout !== null) window.clearTimeout(resizeTimeout);
      window.removeEventListener("resize", handleResize);
      window.visualViewport?.removeEventListener("resize", handleResize);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [onCapacityReached, onFirstFoodDelivered, onTelemetryUpdate]);

  // Convert client pointer coordinates to logical simulation world coordinates
  const clientToWorld = (clientX: number, clientY: number) => {
    const grid = gridRef.current;
    const canvas = canvasRef.current;
    if (!grid || !canvas) return { wx: 0, wy: 0 };
    const rect = canvas.getBoundingClientRect();
    const normX = (clientX - rect.left) / Math.max(1, rect.width);
    const normY = (clientY - rect.top) / Math.max(1, rect.height);
    return {
      wx: Math.max(0, Math.min(grid.worldWidth, normX * grid.worldWidth)),
      wy: Math.max(0, Math.min(grid.worldHeight, normY * grid.worldHeight)),
    };
  };

  const pushRibbonPoint = (wx: number, wy: number, radius: number) => {
    const st = strokeRef.current;
    if (st.ribbonCount < MAX_RIBBON_POINTS) {
      const pt = st.ribbon[st.ribbonCount];
      pt.x = wx;
      pt.y = wy;
      pt.radius = radius;
      pt.age = 0;
      st.ribbonCount++;
    } else {
      for (let i = 1; i < MAX_RIBBON_POINTS; i++) {
        const dst = st.ribbon[i - 1];
        const src = st.ribbon[i];
        dst.x = src.x;
        dst.y = src.y;
        dst.radius = src.radius;
        dst.age = src.age;
      }
      const last = st.ribbon[MAX_RIBBON_POINTS - 1];
      last.x = wx;
      last.y = wy;
      last.radius = radius;
      last.age = 0;
    }
  };

  /**
   * Dense stroke interpolation spaced at 0.25 * brushRadius for unbroken chemical trails and smooth walls.
   */
  const applyInterpolatedStrokeSegment = (
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    tool: ToolMode
  ) => {
    const grid = gridRef.current;
    const colony = colonyRef.current;
    if (!grid || !colony) return;

    const radius = paramsRef.current.brushRadius;
    const intensity = paramsRef.current.depositionIntensity;
    const stepSize = Math.max(2.5, radius * 0.25);
    const dist = Math.hypot(x1 - x0, y1 - y0);
    const steps = Math.max(1, Math.ceil(dist / stepSize));

    let wallModified = false;

    for (let i = 0; i <= steps; i++) {
      const t = steps === 0 ? 1 : i / steps;
      const wx = x0 + (x1 - x0) * t;
      const wy = y0 + (y1 - y0) * t;

      if (tool === "foodCluster") {
        // Place crystal clusters spaced sensibly along drag
        if (i === 0 || dist >= radius * 0.9) {
          colony.addFoodCluster(
            wx,
            wy,
            Math.round(120 + intensity * 1.8),
            Math.max(20, Math.min(34, radius * 0.95))
          );
        }
      } else {
        const touchedNest = grid.applyBrushDab(
          wx,
          wy,
          radius,
          tool,
          intensity,
          colony.nest.x,
          colony.nest.y,
          colony.nest.radius + 14
        );
        if (touchedNest && tool === "eraser") {
          colony.nest.eraserProtectPulse = 1.0;
        }
        if (tool === "wall") {
          wallModified = true;
          colony.eraseEntitiesInRadius(wx, wy, radius * 0.85);
        } else if (tool === "eraser") {
          colony.eraseEntitiesInRadius(wx, wy, radius);
        }
      }
    }

    if (wallModified) {
      colony.ejectAntsFromWalls(grid);
    }
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    // Ignore non-primary mouse buttons or secondary multi-touch pointers
    if (e.button !== 0 && e.pointerType === "mouse") return;
    const st = strokeRef.current;
    if (st.active && st.pointerId !== null) return;

    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore pointer capture errors
    }

    if (showGhostRef.current) {
      onDismissFirstRunGhost();
    }

    const { wx, wy } = clientToWorld(e.clientX, e.clientY);
    const tool = toolRef.current;
    const radius = paramsRef.current.brushRadius;

    st.active = true;
    st.pointerId = e.pointerId;
    st.tool = tool;
    st.worldX = wx;
    st.worldY = wy;
    st.lastWorldX = wx;
    st.lastWorldY = wy;
    st.prevWorldX = wx;
    st.prevWorldY = wy;
    st.startX = wx;
    st.startY = wy;
    st.startRipple = 1.0;
    st.ribbonCount = 0;

    pushRibbonPoint(wx, wy, radius);
    applyInterpolatedStrokeSegment(wx, wy, wx, wy, tool);

    const sparkColor =
      tool === "foodTrail"
        ? "#ffae00"
        : tool === "homeGuide"
        ? "#00f0ff"
        : tool === "alarm"
        ? "#ff0a43"
        : tool === "foodCluster"
        ? "#00e676"
        : "#cbd5e1";
    colonyRef.current?.emitSparks(wx, wy, 5, sparkColor, 0.65);

    onStrokeStateChange(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const st = strokeRef.current;
    if (!st.active || st.pointerId !== e.pointerId) return;

    const { wx, wy } = clientToWorld(e.clientX, e.clientY);
    const radius = paramsRef.current.brushRadius;

    applyInterpolatedStrokeSegment(
      st.lastWorldX,
      st.lastWorldY,
      wx,
      wy,
      st.tool
    );

    st.prevWorldX = st.lastWorldX;
    st.prevWorldY = st.lastWorldY;
    st.lastWorldX = wx;
    st.lastWorldY = wy;
    st.worldX = wx;
    st.worldY = wy;

    pushRibbonPoint(wx, wy, radius);

    if (Math.hypot(wx - st.prevWorldX, wy - st.prevWorldY) > 6) {
      const sparkColor =
        st.tool === "foodTrail"
          ? "#ffae00"
          : st.tool === "homeGuide"
          ? "#00f0ff"
          : st.tool === "alarm"
          ? "#ff0a43"
          : st.tool === "foodCluster"
          ? "#00e676"
          : "#cbd5e1";
      colonyRef.current?.emitSparks(wx, wy, 1, sparkColor, 0.45);
    }
  };

  const endPointerStroke = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const st = strokeRef.current;
    if (!st.active || (st.pointerId !== null && st.pointerId !== e.pointerId)) {
      return;
    }
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {
      // Ignore release errors
    }
    st.active = false;
    st.pointerId = null;
    onStrokeStateChange(false);
  };

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#03050a] select-none">
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={endPointerStroke}
        onPointerCancel={endPointerStroke}
        onLostPointerCapture={endPointerStroke}
        aria-label="Bioluminescent Ant-Colony Simulation and Scent-Painting Canvas"
        className={`block w-full h-full touch-none select-none cursor-crosshair transition-opacity duration-200 ${
          presetCrossfade ? "opacity-25" : "opacity-100"
        }`}
      />

      {/* Minimal Boot Splash (Nest concentric rings pulsing once, fading out over 300ms) */}
      <div
        aria-hidden="true"
        className={`fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#03050a] pointer-events-none transition-opacity duration-300 ${
          bootSplashVisible ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="relative flex items-center justify-center w-24 h-24">
          <span className="absolute inset-0 rounded-full border-2 border-[#00f0ff]/60 animate-ping" />
          <span className="w-14 h-14 rounded-full border-2 border-[#ffae00] bg-[#07101e]" />
        </div>
        <span className="mt-4 font-display text-sm tracking-widest uppercase text-slate-300">
          Synthesizing Macro-Sanctuary
        </span>
      </div>
    </div>
  );
});
