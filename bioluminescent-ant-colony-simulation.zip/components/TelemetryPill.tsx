"use client";

import React from "react";
import {
  AntGlyphIcon,
  BookScienceIcon,
  FoodClusterIcon,
  PauseIcon,
  PlayIcon,
  SlidersIcon,
} from "./ui/icons";
import { TelemetrySnapshot, TimeScale } from "@/lib/types";

interface TelemetryPillProps {
  telemetry: TelemetrySnapshot;
  timeScale: TimeScale;
  paused: boolean;
  isChromeDimmed: boolean;
  isSheetOpen: boolean;
  onCycleSpeed: () => void;
  onTogglePause: () => void;
  onOpenFieldGuide: () => void;
  onToggleSettings: () => void;
}

export function TelemetryPill({
  telemetry,
  timeScale,
  paused,
  isChromeDimmed,
  isSheetOpen,
  onCycleSpeed,
  onTogglePause,
  onOpenFieldGuide,
  onToggleSettings,
}: TelemetryPillProps) {
  const fpsColor =
    telemetry.fps >= 55
      ? "#00e676"
      : telemetry.fps >= 40
      ? "#ffae00"
      : "#ff0a43";

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-30 flex justify-center safe-top safe-x transition-opacity duration-200 ${
        isChromeDimmed ? "opacity-30 pointer-events-none" : "opacity-100"
      }`}
    >
      <div className="glass-chrome glass-chrome-blur flex items-center gap-1.5 sm:gap-3 px-2.5 sm:px-4 py-1.5 rounded-[28px] max-w-full overflow-x-auto select-none">
        {/* Brand emblem & Live FPS status indicator */}
        <div
          className="flex items-center gap-1.5 pr-2 border-r border-[#384d6b]/50"
          title={`Frame Rate: ${telemetry.fps} FPS (${telemetry.qualityTier} tier)`}
        >
          <span
            className="w-2.5 h-2.5 rounded-full shrink-0"
            style={{
              backgroundColor: fpsColor,
              boxShadow: `0 0 8px ${fpsColor}`,
            }}
            aria-hidden="true"
          />
          <span className="tabular-nums text-xs sm:text-sm font-semibold text-slate-100">
            {telemetry.fps}
          </span>
          <span className="text-[11px] uppercase tracking-wider text-slate-400">
            FPS
          </span>
        </div>

        {/* Active Ants Counter */}
        <div
          className="flex items-center gap-1.5 px-1.5 sm:px-2 border-r border-[#384d6b]/50"
          title="Active Colony Workers"
        >
          <AntGlyphIcon size={15} className="text-[#00f0ff] shrink-0" />
          <div className="flex flex-col leading-none">
            <span className="tabular-nums text-xs sm:text-sm font-semibold text-slate-100">
              {telemetry.activeAnts}
            </span>
            <span className="text-[10px] text-slate-400">Ants</span>
          </div>
        </div>

        {/* Stored Food Counter */}
        <div
          className="flex items-center gap-1.5 px-1.5 sm:px-2 border-r border-[#384d6b]/50"
          title="Stored Nutrients (Every 3 units spawns 1 ant)"
        >
          <FoodClusterIcon size={15} className="text-[#00e676] shrink-0" />
          <div className="flex flex-col leading-none">
            <span className="tabular-nums text-xs sm:text-sm font-semibold text-slate-100">
              {telemetry.storedFood}
            </span>
            <span className="text-[10px] text-slate-400">Food</span>
          </div>
        </div>

        {/* Simulation Speed Cycle Button (1x, 2x, 4x) */}
        <button
          type="button"
          onClick={onCycleSpeed}
          aria-label={`Simulation speed ${timeScale}x. Activate to cycle speed.`}
          title="Cycle simulation time scale (1x, 2x, 4x)"
          className="min-w-[48px] min-h-[48px] px-2.5 rounded-full flex items-center justify-center text-xs sm:text-sm font-bold tabular-nums text-[#00f0ff] bg-[#0f172a]/80 hover:bg-[#1e293b] active:scale-95 transition-all border border-[#384d6b]/60"
        >
          {timeScale}x
        </button>

        {/* Play / Pause Toggle */}
        <button
          type="button"
          onClick={onTogglePause}
          aria-label={paused ? "Resume simulation (Space)" : "Pause simulation (Space)"}
          title={paused ? "Resume simulation [Space]" : "Pause simulation [Space]"}
          className={`min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center transition-all active:scale-95 border ${
            paused
              ? "bg-[#ffae00]/20 text-[#ffae00] border-[#ffae00]/60"
              : "bg-[#0f172a]/80 text-slate-100 hover:bg-[#1e293b] border-[#384d6b]/60"
          }`}
        >
          {paused ? <PlayIcon size={18} /> : <PauseIcon size={18} />}
        </button>

        {/* Field Guide & Science Modal Trigger */}
        <button
          type="button"
          onClick={onOpenFieldGuide}
          aria-label="Open Entomological Field Guide and Science Reference"
          title="Field Guide & Neuroethology Reference"
          className="min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center text-slate-200 bg-[#0f172a]/80 hover:bg-[#1e293b] hover:text-[#00f0ff] active:scale-95 transition-all border border-[#384d6b]/60"
        >
          <BookScienceIcon size={18} />
        </button>

        {/* Settings / Parameter Sheet Toggle */}
        <button
          type="button"
          onClick={onToggleSettings}
          aria-label="Toggle Colony and Pheromone Parameters Sheet"
          aria-expanded={isSheetOpen}
          title="Simulation Parameters & Presets"
          className={`min-w-[48px] min-h-[48px] rounded-full flex items-center justify-center transition-all active:scale-95 border ${
            isSheetOpen
              ? "bg-[#00f0ff]/20 text-[#00f0ff] border-[#00f0ff]/70"
              : "bg-[#0f172a]/80 text-slate-200 hover:bg-[#1e293b] border-[#384d6b]/60"
          }`}
        >
          <SlidersIcon size={18} />
        </button>
      </div>
    </header>
  );
}
