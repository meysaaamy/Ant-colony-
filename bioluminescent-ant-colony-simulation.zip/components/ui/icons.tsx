import React from "react";

export interface IconProps {
  className?: string;
  size?: number;
}

export function FoodTrailIcon({ className = "", size = 22 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M3 17C6.5 17 7.5 7 12 7C16.5 7 17.5 17 21 17" />
      <path d="M3 12C6.5 12 8.5 4 12 4C15.5 4 17.5 12 21 12" strokeOpacity={0.55} />
      <circle cx="6" cy="15.5" r="1.25" fill="currentColor" stroke="none" />
      <circle cx="12" cy="7" r="1.5" fill="currentColor" stroke="none" />
      <circle cx="18" cy="15.5" r="1.25" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function HomeTrailIcon({ className = "", size = 22 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <circle cx="12" cy="12" r="8.5" strokeDasharray="3 2.5" />
      <polygon points="12,5.5 14.8,13.5 12,11.8 9.2,13.5" fill="currentColor" fillOpacity={0.25} />
      <circle cx="12" cy="17.5" r="1.2" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function AlarmIcon({ className = "", size = 22 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <circle cx="12" cy="12" r="3" fill="currentColor" fillOpacity={0.35} />
      <circle cx="12" cy="12" r="6.5" strokeOpacity={0.8} />
      <circle cx="12" cy="12" r="10" strokeDasharray="2.5 2.5" strokeOpacity={0.55} />
      <path d="M12 2V4M12 20V22M2 12H4M20 12H22" />
    </svg>
  );
}

export function FoodClusterIcon({ className = "", size = 22 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <polygon points="12,3 16,9 14.5,19 9.5,19 8,9" fill="currentColor" fillOpacity={0.24} />
      <polygon points="6,8 9.5,11 9.5,19 5,17" fill="currentColor" fillOpacity={0.14} />
      <polygon points="18,7 19.5,16.5 14.5,19 15,10.5" fill="currentColor" fillOpacity={0.14} />
      <path d="M12 3V19" strokeOpacity={0.6} />
    </svg>
  );
}

export function WallIcon({ className = "", size = 22 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M3.5 18.5L6.5 8.5L11.5 5.5L17.5 7.5L20.5 18.5Z" fill="currentColor" fillOpacity={0.22} />
      <path d="M6.5 8.5L12 12.5L17.5 7.5" strokeOpacity={0.75} />
      <path d="M12 12.5V18.5" strokeOpacity={0.75} />
    </svg>
  );
}

export function EraserIcon({ className = "", size = 22 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <circle cx="12" cy="12" r="8.5" strokeDasharray="3.5 2.5" />
      <path d="M8.5 8.5L15.5 15.5M15.5 8.5L8.5 15.5" />
    </svg>
  );
}

export function PlayIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <polygon points="6,4.5 19.5,12 6,19.5" />
    </svg>
  );
}

export function PauseIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect x="6" y="4.5" width="4" height="15" rx="1" />
      <rect x="14" y="4.5" width="4" height="15" rx="1" />
    </svg>
  );
}

export function BookScienceIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M2 5.5C2 4.4 2.9 3.5 4 3.5H10C11.1 3.5 12 4.4 12 5.5V19.5C12 18.7 11.3 18 10.5 18H4C2.9 18 2 17.1 2 16V5.5Z" />
      <path d="M22 5.5C22 4.4 21.1 3.5 20 3.5H14C12.9 3.5 12 4.4 12 5.5V19.5C12 18.7 12.7 18 13.5 18H20C21.1 18 22 17.1 22 16V5.5Z" />
      <path d="M6 8.5H8.5M15.5 8.5H18M6 12H8.5M15.5 12H18" />
    </svg>
  );
}

export function SlidersIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <line x1="4" y1="6" x2="20" y2="6" />
      <line x1="4" y1="12" x2="20" y2="12" />
      <line x1="4" y1="18" x2="20" y2="18" />
      <circle cx="9" cy="6" r="2.2" fill="#0a0f1a" />
      <circle cx="15" cy="12" r="2.2" fill="#0a0f1a" />
      <circle cx="10" cy="18" r="2.2" fill="#0a0f1a" />
    </svg>
  );
}

export function CloseIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M18 6L6 18M6 6L18 18" />
    </svg>
  );
}

export function ChevronDownIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M6 9L12 15L18 9" />
    </svg>
  );
}

export function ResetIcon({ className = "", size = 16 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
      <path d="M3 3v5h5" />
    </svg>
  );
}

export function SparkClearIcon({ className = "", size = 16 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M12 3V7M12 17V21M3 12H7M17 12H21" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

export function AntGlyphIcon({ className = "", size = 16 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <circle cx="12" cy="6.5" r="2" />
      <ellipse cx="12" cy="11.5" rx="1.6" ry="2.5" />
      <ellipse cx="12" cy="17.5" rx="2.8" ry="3.5" />
      <path d="M10.5 5L8 3M13.5 5L16 3" />
      <path d="M10.4 10.5L6.5 9M13.6 10.5L17.5 9" />
      <path d="M10.4 12L6 12.5M13.6 12L18 12.5" />
      <path d="M10.4 13.5L7 16.5M13.6 13.5L17 16.5" />
    </svg>
  );
}

export function BilateralAntennaDiagramSVG({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 460 190"
      fill="none"
      className={`w-full h-auto rounded-xl border border-[#26354d]/70 bg-[#03050a] ${className}`}
      role="img"
      aria-label="Bilateral Antenna Tropotaxis Diagram showing Left, Center, and Right receptor sampling cones and Weber-Fechner logarithmic stimulus"
    >
      <defs>
        <radialGradient id="plumeGrad" cx="65%" cy="35%" r="55%">
          <stop offset="0%" stopColor="#fff3b0" stopOpacity="0.65" />
          <stop offset="40%" stopColor="#ffae00" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#4d1f00" stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx="290" cy="70" rx="145" ry="62" fill="url(#plumeGrad)" />
      {/* Ant body */}
      <g transform="translate(150, 125) rotate(-25)">
        <ellipse cx="-26" cy="0" rx="13" ry="9" fill="#101622" stroke="#384d6b" strokeWidth="1.5" />
        <ellipse cx="-6" cy="0" rx="9" ry="5.5" fill="#101622" stroke="#384d6b" strokeWidth="1.5" />
        <ellipse cx="12" cy="0" rx="7" ry="6" fill="#151f30" stroke="#00f0ff" strokeWidth="1.5" />
        {/* Sensor rays */}
        <line x1="18" y1="0" x2="78" y2="-42" stroke="#00f0ff" strokeWidth="1.5" strokeDasharray="3 3" />
        <line x1="18" y1="0" x2="88" y2="0" stroke="#fff3b0" strokeWidth="1.5" strokeDasharray="3 3" />
        <line x1="18" y1="0" x2="78" y2="42" stroke="#ffae00" strokeWidth="2" />
        <circle cx="78" cy="-42" r="5" fill="#003366" stroke="#00f0ff" strokeWidth="1.5" />
        <circle cx="88" cy="0" r="5" fill="#4d1f00" stroke="#fff3b0" strokeWidth="1.5" />
        <circle cx="78" cy="42" r="6" fill="#ffae00" stroke="#fff3b0" strokeWidth="1.75" />
      </g>
      <text x="16" y="28" fill="#e2e8f0" fontSize="11" fontFamily="monospace">
        S = ln(1 + C)  [Weber-Fechner Law]
      </text>
      <text x="16" y="48" fill="#94a3b8" fontSize="10" fontFamily="sans-serif">
        Torque = k * (S_right - S_left) / (1 + 0.25 * S_center)
      </text>
      <text x="188" y="42" fill="#00f0ff" fontSize="10" fontFamily="monospace">
        S_left (-theta)
      </text>
      <text x="242" y="92" fill="#fff3b0" fontSize="10" fontFamily="monospace">
        S_center (0)
      </text>
      <text x="232" y="142" fill="#ffae00" fontSize="10" fontFamily="monospace">
        S_right (+theta, High C)
      </text>
    </svg>
  );
}

export function PheromoneLutLegendSVG({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 460 156"
      fill="none"
      className={`w-full h-auto rounded-xl border border-[#26354d]/70 bg-[#03050a] ${className}`}
      role="img"
      aria-label="256-entry non-linear RGB Pheromone Look-Up Table color ramps"
    >
      <defs>
        <linearGradient id="lutFood" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#03050a" />
          <stop offset="28%" stopColor="#4d1f00" />
          <stop offset="72%" stopColor="#ffae00" />
          <stop offset="100%" stopColor="#fff3b0" />
        </linearGradient>
        <linearGradient id="lutHome" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#03050a" />
          <stop offset="35%" stopColor="#003366" />
          <stop offset="85%" stopColor="#00f0ff" />
          <stop offset="100%" stopColor="#ccfaff" />
        </linearGradient>
        <linearGradient id="lutAlarm" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#03050a" />
          <stop offset="40%" stopColor="#590016" />
          <stop offset="85%" stopColor="#ff0a43" />
          <stop offset="100%" stopColor="#ff99b0" />
        </linearGradient>
      </defs>
      <text x="18" y="26" fill="#ffae00" fontSize="11" fontFamily="monospace">
        FOOD TRAIL (Lasius niger recruitment ester): #4d1f00 -&gt; #ffae00 -&gt; #fff3b0
      </text>
      <rect x="18" y="32" width="424" height="16" rx="4" fill="url(#lutFood)" stroke="#26354d" strokeWidth="1" />

      <text x="18" y="72" fill="#00f0ff" fontSize="11" fontFamily="monospace">
        HOME GUIDE (Cuticular footprint hydrocarbon): #003366 -&gt; #00f0ff
      </text>
      <rect x="18" y="78" width="424" height="16" rx="4" fill="url(#lutHome)" stroke="#26354d" strokeWidth="1" />

      <text x="18" y="118" fill="#ff0a43" fontSize="11" fontFamily="monospace">
        ALARM SIGNAL (Mandibular gland ketone, 3.5x decay): #590016 -&gt; #ff0a43
      </text>
      <rect x="18" y="124" width="424" height="16" rx="4" fill="url(#lutAlarm)" stroke="#26354d" strokeWidth="1" />
    </svg>
  );
}

export function DoubleBridgeDiagramSVG({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 460 185"
      fill="none"
      className={`w-full h-auto rounded-xl border border-[#26354d]/70 bg-[#03050a] ${className}`}
      role="img"
      aria-label="Deneubourg Double-Bridge Shortest Path Autocatalysis Diagram"
    >
      <path
        d="M64 95 L145 95 L220 46 L295 95 L396 95"
        stroke="#ffae00"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M145 95 L220 156 L295 95"
        stroke="#00f0ff"
        strokeWidth="1.75"
        strokeDasharray="4 4"
        strokeOpacity="0.55"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polygon points="158,95 220,62 282,95 220,134" fill="#101622" stroke="#384d6b" strokeWidth="1.5" />
      <circle cx="54" cy="95" r="15" fill="#07101e" stroke="#00f0ff" strokeWidth="2" />
      <circle cx="54" cy="95" r="8" stroke="#ffae00" strokeWidth="1.5" />
      <polygon
        points="396,80 410,90 406,108 386,108 382,90"
        fill="#00e676"
        fillOpacity="0.28"
        stroke="#00e676"
        strokeWidth="1.75"
      />
      <text x="38" y="128" fill="#94a3b8" fontSize="10" fontFamily="monospace">
        NEST
      </text>
      <text x="372" y="128" fill="#00e676" fontSize="10" fontFamily="monospace">
        NUTRIENTS
      </text>
      <text x="150" y="32" fill="#ffae00" fontSize="10" fontFamily="monospace">
        Short Branch (1.0x L): Positive Feedback Lock
      </text>
      <text x="148" y="174" fill="#00f0ff" fontSize="10" fontFamily="monospace">
        Long Branch (2.0x L): Evaporative Attenuation
      </text>
    </svg>
  );
}
