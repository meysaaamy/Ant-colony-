"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  ChevronDownIcon,
  ResetIcon,
  SparkClearIcon,
} from "./ui/icons";
import {
  DEFAULT_SIMULATION_PARAMS,
  ParameterTab,
  PresetId,
  SheetSnapPoint,
  SimulationParams,
  TimeScale,
} from "@/lib/types";
import { PRESET_DEFINITIONS, renderPresetPreviewCanvas } from "@/lib/presets";

interface ParameterSheetProps {
  snapPoint: SheetSnapPoint;
  activeTab: ParameterTab;
  params: SimulationParams;
  activePreset: PresetId;
  isChromeDimmed: boolean;
  onChangeSnapPoint: (snap: SheetSnapPoint) => void;
  onChangeTab: (tab: ParameterTab) => void;
  onUpdateParams: (partial: Partial<SimulationParams>) => void;
  onSelectPreset: (presetId: PresetId) => void;
  onClearPheromones: () => void;
  onResetWorld: () => void;
}

const TABS: ParameterTab[] = ["Colony", "Pheromones", "Brush", "World"];

function PresetPreviewCanvas({ presetId }: { presetId: PresetId }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      renderPresetPreviewCanvas(canvasRef.current, presetId);
    }
  }, [presetId]);

  return (
    <canvas
      ref={canvasRef}
      width={180}
      height={76}
      className="w-full h-[76px] rounded-lg border border-[#384d6b]/50 bg-[#03050a] mb-2"
    />
  );
}

export function ParameterSheet({
  snapPoint,
  activeTab,
  params,
  activePreset,
  isChromeDimmed,
  onChangeSnapPoint,
  onChangeTab,
  onUpdateParams,
  onSelectPreset,
  onClearPheromones,
  onResetWorld,
}: ParameterSheetProps) {
  const [resetArmed, setResetArmed] = useState(false);
  const armTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (armTimerRef.current !== null) {
        window.clearTimeout(armTimerRef.current);
      }
    };
  }, []);

  const handleResetWorldClick = () => {
    if (!resetArmed) {
      setResetArmed(true);
      if (armTimerRef.current !== null) {
        window.clearTimeout(armTimerRef.current);
      }
      armTimerRef.current = window.setTimeout(() => {
        setResetArmed(false);
      }, 3000);
    } else {
      setResetArmed(false);
      if (armTimerRef.current !== null) {
        window.clearTimeout(armTimerRef.current);
      }
      onResetWorld();
    }
  };

  const cycleSnapPoint = () => {
    if (snapPoint === "peek") onChangeSnapPoint("half");
    else if (snapPoint === "half") onChangeSnapPoint("full");
    else onChangeSnapPoint("peek");
  };

  const currentPresetDef =
    PRESET_DEFINITIONS.find((p) => p.id === activePreset) ||
    PRESET_DEFINITIONS[0];

  // Height class based on snapPoint on mobile; fixed 360px right panel when open on desktop (md:)
  const heightClasses =
    snapPoint === "peek"
      ? "max-h-[54px] md:max-h-[58px]"
      : snapPoint === "half"
      ? "max-h-[48dvh] md:max-h-[68dvh]"
      : "max-h-[82dvh] md:max-h-[86dvh]";

  return (
    <aside
      aria-label="Simulation Parameters and World Presets"
      className={`fixed bottom-0 left-0 right-0 md:left-auto md:right-4 md:top-20 md:bottom-auto z-20 md:w-[360px] transition-all duration-300 ${
        isChromeDimmed ? "opacity-30 pointer-events-none" : "opacity-100"
      }`}
    >
      <div
        className={`glass-chrome glass-chrome-blur rounded-t-[24px] md:rounded-[24px] flex flex-col overflow-hidden transition-all duration-300 ${heightClasses}`}
      >
        {/* Peek Strip Header (Always Visible) */}
        <div className="px-3 py-1.5 flex items-center justify-between gap-1.5 border-b border-[#384d6b]/40 shrink-0 select-none">
          <button
            type="button"
            onClick={cycleSnapPoint}
            aria-label={`Parameter sheet (${snapPoint}). Activate to expand or collapse.`}
            className="min-h-[42px] px-2 flex items-center gap-2 text-left rounded-xl hover:bg-white/5 transition-colors"
          >
            <span className="w-6 h-1.5 rounded-full bg-slate-500/80 md:hidden shrink-0" />
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-[#00f0ff] font-semibold leading-none">
                Scenario
              </span>
              <span className="text-xs font-semibold text-slate-100 truncate max-w-[115px] sm:max-w-[140px]">
                {currentPresetDef.name}
              </span>
            </div>
            <ChevronDownIcon
              size={15}
              className={`text-slate-400 transition-transform duration-200 ${
                snapPoint === "peek" ? "rotate-180 md:rotate-0" : ""
              }`}
            />
          </button>

          {/* Instant Clear Pheromones & 2-Step Armed Reset World */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onClearPheromones}
              aria-label="Clear Pheromones"
              title="Erase all active pheromone trails while keeping walls & ants"
              className="min-h-[40px] px-2.5 rounded-xl flex items-center gap-1 text-[11px] font-semibold text-slate-200 bg-[#0f172a]/90 hover:bg-[#1e293b] border border-[#384d6b]/60 active:scale-95 transition-all"
            >
              <SparkClearIcon size={14} className="text-[#00f0ff]" />
              <span>Clear Pheromones</span>
            </button>

            <button
              type="button"
              onClick={handleResetWorldClick}
              aria-label={resetArmed ? "Tap again to confirm world reset" : "Reset World"}
              className={`min-h-[40px] px-2.5 rounded-xl flex items-center gap-1 text-[11px] font-semibold transition-all active:scale-95 border ${
                resetArmed
                  ? "bg-[#ff0a43]/25 text-[#ff99b0] border-[#ff0a43]"
                  : "bg-[#0f172a]/90 text-slate-200 hover:bg-[#1e293b] border-[#384d6b]/60"
              }`}
            >
              <ResetIcon size={14} className={resetArmed ? "text-[#ff0a43]" : "text-[#ffae00]"} />
              <span>{resetArmed ? "Tap again to reset" : "Reset World"}</span>
            </button>
          </div>
        </div>

        {/* Expanded Body (Tabs + Controls) */}
        {snapPoint !== "peek" && (
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* 4-Tab Bar */}
            <div
              role="tablist"
              aria-label="Parameter categories"
              className="grid grid-cols-4 gap-1 p-2 bg-[#060a12]/60 border-b border-[#384d6b]/40 shrink-0"
            >
              {TABS.map((tab) => {
                const isActive = activeTab === tab;
                return (
                  <button
                    key={tab}
                    role="tab"
                    type="button"
                    aria-selected={isActive}
                    onClick={() => onChangeTab(tab)}
                    className={`min-h-[40px] rounded-xl text-xs font-semibold transition-all ${
                      isActive
                        ? "bg-[#162238] text-[#00f0ff] border border-[#00f0ff]/50 shadow-sm"
                        : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                    }`}
                  >
                    {tab}
                  </button>
                );
              })}
            </div>

            {/* Scrollable Tab Content */}
            <div className="p-4 overflow-y-auto space-y-4 text-xs">
              {activeTab === "Colony" && (
                <div className="space-y-4">
                  {/* Max Colony Population */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="param-max-pop" className="font-semibold text-slate-200">
                        Max colony population (carrying capacity)
                      </label>
                      <span className="tabular-nums font-bold text-[#00f0ff]">
                        {params.maxPopulation} ants
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        id="param-max-pop"
                        type="range"
                        min={100}
                        max={3000}
                        step={50}
                        value={params.maxPopulation}
                        aria-valuetext={`${params.maxPopulation} maximum ants`}
                        onChange={(e) =>
                          onUpdateParams({ maxPopulation: Number(e.target.value) })
                        }
                        onDoubleClick={() =>
                          onUpdateParams({
                            maxPopulation: DEFAULT_SIMULATION_PARAMS.maxPopulation,
                          })
                        }
                        className="sanctuary-slider"
                      />
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Every 3 delivered food crystals spawns 1 new worker up to this cap (default {DEFAULT_SIMULATION_PARAMS.maxPopulation}).
                    </p>
                  </div>

                  {/* Trail Sensitivity (alpha) */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="param-sensitivity" className="font-semibold text-slate-200">
                        Trail sensitivity (alpha)
                      </label>
                      <span className="tabular-nums font-bold text-[#ffae00]">
                        {params.trailSensitivity.toFixed(1)}
                      </span>
                    </div>
                    <input
                      id="param-sensitivity"
                      type="range"
                      min={0.5}
                      max={5.0}
                      step={0.1}
                      value={params.trailSensitivity}
                      aria-valuetext={`Alpha ${params.trailSensitivity.toFixed(1)}`}
                      onChange={(e) =>
                        onUpdateParams({ trailSensitivity: Number(e.target.value) })
                      }
                      onDoubleClick={() =>
                        onUpdateParams({
                          trailSensitivity: DEFAULT_SIMULATION_PARAMS.trailSensitivity,
                        })
                      }
                      className="sanctuary-slider"
                    />
                    <p className="text-[11px] text-slate-400">
                      Amplifies bilateral Weber-Fechner steering torque toward stronger chemical gradients.
                    </p>
                  </div>

                  {/* Antenna Sensor Angle (degrees) */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="param-antenna-angle" className="font-semibold text-slate-200">
                        Antenna sensor angle (degrees)
                      </label>
                      <span className="tabular-nums font-bold text-[#00e676]">
                        {params.antennaAngleDeg} deg
                      </span>
                    </div>
                    <input
                      id="param-antenna-angle"
                      type="range"
                      min={15}
                      max={65}
                      step={1}
                      value={params.antennaAngleDeg}
                      aria-valuetext={`${params.antennaAngleDeg} degrees`}
                      onChange={(e) =>
                        onUpdateParams({ antennaAngleDeg: Number(e.target.value) })
                      }
                      onDoubleClick={() =>
                        onUpdateParams({
                          antennaAngleDeg: DEFAULT_SIMULATION_PARAMS.antennaAngleDeg,
                        })
                      }
                      className="sanctuary-slider"
                    />
                    <p className="text-[11px] text-slate-400">
                      Angular spread between Left (-theta) and Right (+theta) chemoreceptor tips.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateParams({
                        maxPopulation: DEFAULT_SIMULATION_PARAMS.maxPopulation,
                        trailSensitivity: DEFAULT_SIMULATION_PARAMS.trailSensitivity,
                        antennaAngleDeg: DEFAULT_SIMULATION_PARAMS.antennaAngleDeg,
                      })
                    }
                    className="w-full min-h-[44px] rounded-xl border border-[#384d6b]/60 bg-[#0f172a] hover:bg-[#1e293b] text-slate-200 font-semibold transition-all"
                  >
                    Reset to defaults
                  </button>
                </div>
              )}

              {activeTab === "Pheromones" && (
                <div className="space-y-4">
                  {/* Trail Fade (evaporation, lambda) */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="param-evaporation" className="font-semibold text-slate-200">
                        Trail fade (evaporation, lambda)
                      </label>
                      <span className="tabular-nums font-bold text-[#ffae00]">
                        {params.evaporationRate.toFixed(2)} /s
                      </span>
                    </div>
                    <input
                      id="param-evaporation"
                      type="range"
                      min={0.02}
                      max={0.45}
                      step={0.01}
                      value={params.evaporationRate}
                      aria-valuetext={`${params.evaporationRate.toFixed(2)} per second`}
                      onChange={(e) =>
                        onUpdateParams({ evaporationRate: Number(e.target.value) })
                      }
                      onDoubleClick={() =>
                        onUpdateParams({
                          evaporationRate: DEFAULT_SIMULATION_PARAMS.evaporationRate,
                        })
                      }
                      className="sanctuary-slider"
                    />
                    <p className="text-[11px] text-slate-400">
                      Exponential decay rate exp(-dt * lambda). Alarm pheromones evaporate 3.5x faster.
                    </p>
                  </div>

                  {/* Chemical Spread (diffusion coefficient) */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="param-diffusion" className="font-semibold text-slate-200">
                        Chemical spread (diffusion coefficient)
                      </label>
                      <span className="tabular-nums font-bold text-[#00f0ff]">
                        {params.diffusionRate.toFixed(2)}
                      </span>
                    </div>
                    <input
                      id="param-diffusion"
                      type="range"
                      min={0.02}
                      max={0.24}
                      step={0.01}
                      value={params.diffusionRate}
                      aria-valuetext={`Diffusion coefficient ${params.diffusionRate.toFixed(2)}`}
                      onChange={(e) =>
                        onUpdateParams({ diffusionRate: Number(e.target.value) })
                      }
                      onDoubleClick={() =>
                        onUpdateParams({
                          diffusionRate: DEFAULT_SIMULATION_PARAMS.diffusionRate,
                        })
                      }
                      className="sanctuary-slider"
                    />
                    <p className="text-[11px] text-slate-400">
                      3x3 Laplacian spatial dispersion rate with zero-flux Neumann wall boundaries.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateParams({
                        evaporationRate: DEFAULT_SIMULATION_PARAMS.evaporationRate,
                        diffusionRate: DEFAULT_SIMULATION_PARAMS.diffusionRate,
                      })
                    }
                    className="w-full min-h-[44px] rounded-xl border border-[#384d6b]/60 bg-[#0f172a] hover:bg-[#1e293b] text-slate-200 font-semibold transition-all"
                  >
                    Reset to defaults
                  </button>
                </div>
              )}

              {activeTab === "Brush" && (
                <div className="space-y-4">
                  {/* Brush Radius */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="sheet-brush-radius" className="font-semibold text-slate-200">
                        Brush radius (stroke width)
                      </label>
                      <span className="tabular-nums font-bold text-[#00f0ff]">
                        {params.brushRadius} u
                      </span>
                    </div>
                    <input
                      id="sheet-brush-radius"
                      type="range"
                      min={12}
                      max={72}
                      step={2}
                      value={params.brushRadius}
                      aria-valuetext={`${params.brushRadius} world units`}
                      onChange={(e) =>
                        onUpdateParams({ brushRadius: Number(e.target.value) })
                      }
                      onDoubleClick={() =>
                        onUpdateParams({
                          brushRadius: DEFAULT_SIMULATION_PARAMS.brushRadius,
                        })
                      }
                      className="sanctuary-slider"
                    />
                    <p className="text-[11px] text-slate-400">
                      Interpolates dabs every 0.25 * radius for unbroken chemical highways.
                    </p>
                  </div>

                  {/* Deposition Intensity */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="sheet-deposition" className="font-semibold text-slate-200">
                        Deposition intensity (chemical flux)
                      </label>
                      <span className="tabular-nums font-bold text-[#ffae00]">
                        {params.depositionIntensity}%
                      </span>
                    </div>
                    <input
                      id="sheet-deposition"
                      type="range"
                      min={10}
                      max={100}
                      step={2}
                      value={params.depositionIntensity}
                      aria-valuetext={`${params.depositionIntensity} percent`}
                      onChange={(e) =>
                        onUpdateParams({
                          depositionIntensity: Number(e.target.value),
                        })
                      }
                      onDoubleClick={() =>
                        onUpdateParams({
                          depositionIntensity:
                            DEFAULT_SIMULATION_PARAMS.depositionIntensity,
                        })
                      }
                      className="sanctuary-slider"
                    />
                    <p className="text-[11px] text-slate-400">
                      Controls both hand-painted trail saturation and worker pheromone output.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateParams({
                        brushRadius: DEFAULT_SIMULATION_PARAMS.brushRadius,
                        depositionIntensity:
                          DEFAULT_SIMULATION_PARAMS.depositionIntensity,
                      })
                    }
                    className="w-full min-h-[44px] rounded-xl border border-[#384d6b]/60 bg-[#0f172a] hover:bg-[#1e293b] text-slate-200 font-semibold transition-all"
                  >
                    Reset to defaults
                  </button>
                </div>
              )}

              {activeTab === "World" && (
                <div className="space-y-4">
                  {/* Horizontal Snap-Scroll Deterministic Preset Cards */}
                  <div>
                    <span className="block font-semibold text-slate-200 mb-2">
                      Deterministic Sanctuary Scenarios
                    </span>
                    <div className="flex gap-3 overflow-x-auto pb-2 snap-x snap-mandatory">
                      {PRESET_DEFINITIONS.map((preset) => {
                        const isSelected = activePreset === preset.id;
                        return (
                          <button
                            key={preset.id}
                            type="button"
                            onClick={() => onSelectPreset(preset.id)}
                            className={`snap-start shrink-0 w-[220px] p-3 rounded-2xl text-left transition-all border ${
                              isSelected
                                ? "bg-[#131f35] border-[#00f0ff] shadow-[0_0_20px_-4px_rgba(0,240,255,0.4)]"
                                : "bg-[#0a101d]/90 border-[#384d6b]/50 hover:border-[#384d6b]"
                            }`}
                          >
                            <PresetPreviewCanvas presetId={preset.id} />
                            <div className="font-display text-sm font-semibold text-slate-100 mb-0.5">
                              {preset.name}
                            </div>
                            <p className="text-[11px] text-slate-400 line-clamp-2 leading-snug">
                              {preset.description}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Simulation Time Scale Segmented Control (1x, 2x, 4x) */}
                  <div>
                    <span className="block font-semibold text-slate-200 mb-1.5">
                      Simulation time scale (physics sub-stepping)
                    </span>
                    <div className="grid grid-cols-3 gap-2">
                      {([1, 2, 4] as TimeScale[]).map((scale) => {
                        const active = params.timeScale === scale;
                        return (
                          <button
                            key={scale}
                            type="button"
                            onClick={() => onUpdateParams({ timeScale: scale })}
                            className={`min-h-[44px] rounded-xl font-bold tabular-nums transition-all border ${
                              active
                                ? "bg-[#00f0ff]/20 text-[#00f0ff] border-[#00f0ff]"
                                : "bg-[#0f172a] text-slate-300 border-[#384d6b]/60 hover:bg-[#1e293b]"
                            }`}
                          >
                            {scale}x Speed
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateParams({
                        timeScale: DEFAULT_SIMULATION_PARAMS.timeScale,
                      })
                    }
                    className="w-full min-h-[44px] rounded-xl border border-[#384d6b]/60 bg-[#0f172a] hover:bg-[#1e293b] text-slate-200 font-semibold transition-all"
                  >
                    Reset to defaults
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
