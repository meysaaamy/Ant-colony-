import { AntColonyEngine, weberFechnerLaw } from "@/lib/ant-soa-engine";
import {
  computeSaturatingDeposit,
  createPheromoneLUTs,
  PheromoneGrid,
} from "@/lib/pheromone-grid";
import { applyPresetWorld, PRESET_DEFINITIONS } from "@/lib/presets";
import { MAX_ANTS } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    // 1. Verify LUT generation bounds (256 * 4 RGBA entries per channel)
    const luts = createPheromoneLUTs();
    const lutValid =
      luts.foodTrailLUT.length === 1024 &&
      luts.homeGuideLUT.length === 1024 &&
      luts.alarmLUT.length === 1024;

    // 2. Verify Weber-Fechner law S = ln(1 + C) & saturating deposition
    const wfCheck = Math.abs(weberFechnerLaw(Math.E - 1) - 1.0) < 1e-6;
    const depCheck = computeSaturatingDeposit(20, 0.1, 0, 0) === 20;

    // 3. Verify zero-flux Neumann boundary across a wall cell
    const testGrid = new PheromoneGrid(180, 180);
    const midY = 10;
    // Build a solid vertical wall at column x = 10
    for (let y = 0; y < testGrid.rows; y++) {
      testGrid.wallMask[y * testGrid.cols + 10] = 1;
    }
    // Deposit 100 concentration at x = 9 (left of wall)
    testGrid.foodTrail[midY * testGrid.cols + 9] = 100.0;
    testGrid.stepPhysics(1 / 60, 0.1, 0.2);

    const wallCellValue = testGrid.foodTrail[midY * testGrid.cols + 10];
    const rightOfWallValue = testGrid.foodTrail[midY * testGrid.cols + 11];
    const zeroFluxValid = wallCellValue === 0 && rightOfWallValue === 0;

    // 4. Verify SoA capacity and all 3 deterministic presets
    const testColony = new AntColonyEngine(720, 1280);
    const presetCheckGrid = new PheromoneGrid(720, 1280);
    let presetsValid = testColony.x.length === MAX_ANTS;

    for (const preset of PRESET_DEFINITIONS) {
      applyPresetWorld(preset.id, presetCheckGrid, testColony, 600);
      if (testColony.activeCount <= 0 || testColony.foodClusters.length <= 0) {
        presetsValid = false;
      }
    }

    const ok = lutValid && wfCheck && depCheck && zeroFluxValid && presetsValid;

    return Response.json(
      {
        ok,
        engine: "Bioluminescent Macro-Sanctuary SoA Neuroethology Kernel",
        diagnostics: {
          maxAntsCapacity: MAX_ANTS,
          lutEntriesPerChannel: 256,
          weberFechnerVerified: wfCheck,
          saturatingDepositionVerified: depCheck,
          zeroFluxWallBoundaryVerified: zeroFluxValid,
          presetsVerified: presetsValid,
        },
      },
      { status: ok ? 200 : 500 }
    );
  } catch (err) {
    return Response.json(
      {
        ok: false,
        error: err instanceof Error ? err.message : "Health check error",
      },
      { status: 500 }
    );
  }
}
