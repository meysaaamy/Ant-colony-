"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  SanctuaryCanvas,
  SanctuaryCanvasHandle,
} from "@/components/SanctuaryCanvas";
import { TelemetryPill } from "@/components/TelemetryPill";
import { FloatingToolDock, TOOL_CONFIGS } from "@/components/FloatingToolDock";
import { ParameterSheet } from "@/components/ParameterSheet";
import { FieldGuideModal } from "@/components/FieldGuideModal";
import { ToastOverlay } from "@/components/ToastOverlay";
import { PRESET_DEFINITIONS } from "@/lib/presets";
import {
  DEFAULT_SIMULATION_PARAMS,
  ParameterTab,
  PresetId,
  SheetSnapPoint,
  SimulationParams,
  TelemetrySnapshot,
  TimeScale,
  ToolMode,
} from "@/lib/types";

const FIRST_USE_TOOL_CAPTIONS: Record<ToolMode, string> = {
  foodTrail: "Food trail lures foraging ants toward crystals.",
  homeGuide: "Home trail guides returning ants back to the nest.",
  alarm: "Alarm scares ants away from this spot.",
  foodCluster: "Emerald crystals feed the colony when harvested.",
  wall: "Basalt walls block ants and pheromone diffusion.",
  eraser: "Eraser clears trails, walls, and crystals (never the nest).",
};

const inMemoryStorageFallback: Record<string, string> = {};

function safeGetStorage(key: string): string | null {
  try {
    if (typeof window !== "undefined" && window.localStorage) {
      return window.localStorage.getItem(key);
    }
  } catch {
    // Fallback to in-memory
  }
  return inMemoryStorageFallback[key] ?? null;
}

function safeSetStorage(key: string, value: string): void {
  inMemoryStorageFallback[key] = value;
  try {
    if (typeof window !== "undefined" && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  } catch {
    // Fallback already stored in-memory
  }
}

export default function SanctuaryPage() {
  const canvasHandleRef = useRef<SanctuaryCanvasHandle | null>(null);

  const [activeTool, setActiveTool] = useState<ToolMode>("foodTrail");
  const [params, setParams] = useState<SimulationParams>(
    DEFAULT_SIMULATION_PARAMS
  );
  const [activePreset, setActivePreset] = useState<PresetId>("open-sanctuary");
  const [sheetSnap, setSheetSnap] = useState<SheetSnapPoint>("peek");
  const [activeTab, setActiveTab] = useState<ParameterTab>("World");
  const [fieldGuideOpen, setFieldGuideOpen] = useState(false);

  const [telemetry, setTelemetry] = useState<TelemetrySnapshot>({
    fps: 60,
    activeAnts: 280,
    storedFood: 0,
    qualityTier: "high",
    presetId: "open-sanctuary",
  });

  // UI chrome fade to 30% while drawing + 200ms post-pointerup protection
  const [isChromeDimmed, setIsChromeDimmed] = useState(false);
  const chromeRestoreTimerRef = useRef<number | null>(null);

  // Onboarding ghost stroke & contextual captions / single toast
  const [showFirstRunGhost, setShowFirstRunGhost] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [captionMessage, setCaptionMessage] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);
  const captionTimerRef = useRef<number | null>(null);
  const seenToolsRef = useRef<Set<ToolMode>>(new Set(["foodTrail"]));

  useEffect(() => {
    const onboarded = safeGetStorage("sanctuary_onboarded_v1");
    if (!onboarded) {
      setShowFirstRunGhost(true);
    }
    const storedTools = safeGetStorage("sanctuary_seen_tools_v1");
    if (storedTools) {
      try {
        const parsed = JSON.parse(storedTools) as ToolMode[];
        seenToolsRef.current = new Set(parsed);
      } catch {
        // Ignore parse error
      }
    }
  }, []);

  const triggerToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2000);
  }, []);

  const triggerCaption = useCallback((msg: string) => {
    setCaptionMessage(msg);
    if (captionTimerRef.current !== null) {
      window.clearTimeout(captionTimerRef.current);
    }
    captionTimerRef.current = window.setTimeout(() => {
      setCaptionMessage(null);
    }, 3000);
  }, []);

  const handleDismissFirstRunGhost = useCallback(() => {
    setShowFirstRunGhost(false);
    safeSetStorage("sanctuary_onboarded_v1", "1");
  }, []);

  const handleStrokeStateChange = useCallback((isDrawing: boolean) => {
    if (chromeRestoreTimerRef.current !== null) {
      window.clearTimeout(chromeRestoreTimerRef.current);
      chromeRestoreTimerRef.current = null;
    }
    if (isDrawing) {
      setIsChromeDimmed(true);
      setSheetSnap("peek");
    } else {
      // Keep UI taps ignored for 200ms after pointerup
      chromeRestoreTimerRef.current = window.setTimeout(() => {
        setIsChromeDimmed(false);
      }, 200);
    }
  }, []);

  const handleSelectTool = useCallback(
    (tool: ToolMode) => {
      setActiveTool(tool);
      if (!seenToolsRef.current.has(tool)) {
        seenToolsRef.current.add(tool);
        safeSetStorage(
          "sanctuary_seen_tools_v1",
          JSON.stringify(Array.from(seenToolsRef.current))
        );
        triggerCaption(FIRST_USE_TOOL_CAPTIONS[tool]);
      }
    },
    [triggerCaption]
  );

  const handleUpdateParams = useCallback(
    (partial: Partial<SimulationParams>) => {
      setParams((prev) => ({ ...prev, ...partial }));
    },
    []
  );

  const handleCycleSpeed = useCallback(() => {
    setParams((prev) => {
      const nextSpeed: TimeScale =
        prev.timeScale === 1 ? 2 : prev.timeScale === 2 ? 4 : 1;
      return { ...prev, timeScale: nextSpeed };
    });
  }, []);

  const handleTogglePause = useCallback(() => {
    setParams((prev) => ({ ...prev, paused: !prev.paused }));
  }, []);

  const handleSelectPreset = useCallback(
    (presetId: PresetId) => {
      setActivePreset(presetId);
      canvasHandleRef.current?.loadPreset(presetId);
      const def = PRESET_DEFINITIONS.find((p) => p.id === presetId);
      if (def) {
        triggerToast(`Loaded ${def.name}`);
      }
    },
    [triggerToast]
  );

  const handleClearPheromones = useCallback(() => {
    canvasHandleRef.current?.clearPheromones();
    triggerToast("Pheromones cleared");
  }, [triggerToast]);

  const handleResetWorld = useCallback(() => {
    canvasHandleRef.current?.resetCurrentPreset();
    triggerToast("World reset");
  }, [triggerToast]);

  const handleFirstFoodDelivered = useCallback(() => {
    triggerCaption("Food delivered. Every 3 units adds an ant.");
  }, [triggerCaption]);

  const handleCapacityReached = useCallback(() => {
    triggerToast("Colony at capacity. Raise the cap in Colony settings.");
  }, [triggerToast]);

  // Global Desktop Keyboard Shortcuts: 1-6 tools, Space pause/play, [ and ] brush radius, Esc close modals
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;

      if (e.key >= "1" && e.key <= "6") {
        const idx = Number(e.key) - 1;
        const toolCfg = TOOL_CONFIGS[idx];
        if (toolCfg) {
          e.preventDefault();
          handleSelectTool(toolCfg.id);
        }
      } else if (e.key === " " || e.code === "Space") {
        e.preventDefault();
        handleTogglePause();
      } else if (e.key === "[") {
        e.preventDefault();
        setParams((prev) => ({
          ...prev,
          brushRadius: Math.max(12, prev.brushRadius - 4),
        }));
      } else if (e.key === "]") {
        e.preventDefault();
        setParams((prev) => ({
          ...prev,
          brushRadius: Math.min(72, prev.brushRadius + 4),
        }));
      } else if (e.key === "Escape") {
        if (fieldGuideOpen) {
          setFieldGuideOpen(false);
        } else if (sheetSnap !== "peek") {
          setSheetSnap("peek");
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [fieldGuideOpen, handleSelectTool, handleTogglePause, sheetSnap]);

  return (
    <main className="relative w-full h-[100vh] h-[100dvh] overflow-hidden bg-[#03050a] select-none">
      {/* Full-bleed Interactive Simulation & Multi-Layer Compositor Canvas */}
      <SanctuaryCanvas
        ref={canvasHandleRef}
        activeTool={activeTool}
        params={params}
        activePreset={activePreset}
        showFirstRunGhost={showFirstRunGhost}
        onDismissFirstRunGhost={handleDismissFirstRunGhost}
        onStrokeStateChange={handleStrokeStateChange}
        onTelemetryUpdate={setTelemetry}
        onFirstFoodDelivered={handleFirstFoodDelivered}
        onCapacityReached={handleCapacityReached}
      />

      {/* Top Compact Telemetry Pill */}
      <TelemetryPill
        telemetry={telemetry}
        timeScale={params.timeScale}
        paused={params.paused}
        isChromeDimmed={isChromeDimmed}
        isSheetOpen={sheetSnap !== "peek"}
        onCycleSpeed={handleCycleSpeed}
        onTogglePause={handleTogglePause}
        onOpenFieldGuide={() => setFieldGuideOpen(true)}
        onToggleSettings={() =>
          setSheetSnap((prev) => (prev === "peek" ? "half" : "peek"))
        }
      />

      {/* Contextual Captions & Single Non-Stacking Toast Overlay */}
      <ToastOverlay
        toastMessage={toastMessage}
        captionMessage={captionMessage}
        showFirstRunGhostPrompt={showFirstRunGhost}
        isChromeDimmed={isChromeDimmed}
      />

      {/* Bottom Floating Tool Dock & Brush Chip */}
      <FloatingToolDock
        activeTool={activeTool}
        brushRadius={params.brushRadius}
        depositionIntensity={params.depositionIntensity}
        isChromeDimmed={isChromeDimmed}
        onSelectTool={handleSelectTool}
        onChangeBrushRadius={(brushRadius) =>
          handleUpdateParams({ brushRadius })
        }
        onChangeDepositionIntensity={(depositionIntensity) =>
          handleUpdateParams({ depositionIntensity })
        }
      />

      {/* Collapsible Parameter Sheet (3 Snap Points on Mobile / 360px Right Panel on Desktop) */}
      <ParameterSheet
        snapPoint={sheetSnap}
        activeTab={activeTab}
        params={params}
        activePreset={activePreset}
        isChromeDimmed={isChromeDimmed}
        onChangeSnapPoint={setSheetSnap}
        onChangeTab={setActiveTab}
        onUpdateParams={handleUpdateParams}
        onSelectPreset={handleSelectPreset}
        onClearPheromones={handleClearPheromones}
        onResetWorld={handleResetWorld}
      />

      {/* Field Guide & Science Modal */}
      <FieldGuideModal
        isOpen={fieldGuideOpen}
        onClose={() => setFieldGuideOpen(false)}
      />
    </main>
  );
}
