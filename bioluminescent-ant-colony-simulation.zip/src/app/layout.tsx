import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Fraunces, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
  weight: ["500", "600", "700"],
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Bioluminescent Macro-Sanctuary | Ant-Colony Neuroethology & Scent-Painting Sandbox",
  description:
    "Interactive computational entomology sandbox simulating Lasius niger & Linepithema humile bilateral tropotaxis, Weber-Fechner pheromone sensing, and emergent shortest-path foraging.",
  icons: {
    icon: "/logo.svg",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#03050a",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${plusJakarta.variable} dark`}>
      <body className="bg-[#03050a] text-slate-100 antialiased selection:bg-[#00f0ff]/25 selection:text-[#00f0ff]">
        {children}
      </body>
    </html>
  );
}
