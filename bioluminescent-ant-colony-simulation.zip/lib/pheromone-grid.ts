import { DirtyRect, PHEROMONE_CELL_SIZE } from "./types";

export const MAX_PHEROMONE_CONCENTRATION = 100.0;

/**
 * Saturating Age-Attenuated Deposition formula:
 * deposit = (baseStrength * Math.exp(-decayRate * timeSinceLastVisit)) / (1.0 + 0.08 * localConcentration)
 */
export function computeSaturatingDeposit(
  baseStrength: number,
  decayRate: number,
  timeSinceLastVisit: number,
  localConcentration: number
): number {
  const numerator = baseStrength * Math.exp(-decayRate * Math.max(0, timeSinceLastVisit));
  const denominator = 1.0 + 0.08 * Math.max(0, localConcentration);
  return numerator / denominator;
}

export interface PheromoneLUTs {
  foodTrailLUT: Uint8Array; // 256 * 4 RGBA
  homeGuideLUT: Uint8Array; // 256 * 4 RGBA
  alarmLUT: Uint8Array; // 256 * 4 RGBA
}

/**
 * Generates precomputed 256-entry RGB Color Look-Up Tables (LUTs) with non-linear gamma curves:
 * - foodTrail: Warm Rust (#4d1f00) -> Incandescent Amber-Gold (#ffae00) -> White-Hot core (#fff3b0)
 * - homeGuide: Deep Cobalt (#003366) -> Electric Cyan (#00f0ff)
 * - alarm: Dark Crimson (#4a0012) -> Crimson Pulse (#ff0a43)
 */
export function createPheromoneLUTs(): PheromoneLUTs {
  const foodTrailLUT = new Uint8Array(256 * 4);
  const homeGuideLUT = new Uint8Array(256 * 4);
  const alarmLUT = new Uint8Array(256 * 4);

  for (let i = 0; i < 256; i++) {
    const t = i / 255;
    const gammaT = Math.pow(t, 0.72); // Non-linear lift for luminous trail visibility
    const offset = i * 4;

    // 1. Food Trail (#4d1f00 -> #ffae00 -> #fff3b0)
    if (i === 0) {
      foodTrailLUT[offset] = 0;
      foodTrailLUT[offset + 1] = 0;
      foodTrailLUT[offset + 2] = 0;
      foodTrailLUT[offset + 3] = 0;
    } else if (gammaT < 0.45) {
      const u = gammaT / 0.45;
      foodTrailLUT[offset] = Math.round(77 * u);
      foodTrailLUT[offset + 1] = Math.round(31 * u);
      foodTrailLUT[offset + 2] = 0;
      foodTrailLUT[offset + 3] = Math.round(180 * u);
    } else if (gammaT < 0.85) {
      const u = (gammaT - 0.45) / 0.4;
      foodTrailLUT[offset] = Math.round(77 + (255 - 77) * u);
      foodTrailLUT[offset + 1] = Math.round(31 + (174 - 31) * u);
      foodTrailLUT[offset + 2] = 0;
      foodTrailLUT[offset + 3] = Math.round(180 + 60 * u);
    } else {
      const u = (gammaT - 0.85) / 0.15;
      foodTrailLUT[offset] = 255;
      foodTrailLUT[offset + 1] = Math.round(174 + (243 - 174) * u);
      foodTrailLUT[offset + 2] = Math.round(176 * u);
      foodTrailLUT[offset + 3] = 255;
    }

    // 2. Home Guide (#003366 -> #00f0ff)
    if (i === 0) {
      homeGuideLUT[offset] = 0;
      homeGuideLUT[offset + 1] = 0;
      homeGuideLUT[offset + 2] = 0;
      homeGuideLUT[offset + 3] = 0;
    } else if (gammaT < 0.5) {
      const u = gammaT / 0.5;
      homeGuideLUT[offset] = 0;
      homeGuideLUT[offset + 1] = Math.round(51 * u);
      homeGuideLUT[offset + 2] = Math.round(102 * u);
      homeGuideLUT[offset + 3] = Math.round(170 * u);
    } else {
      const u = (gammaT - 0.5) / 0.5;
      homeGuideLUT[offset] = Math.round(30 * Math.pow(u, 2));
      homeGuideLUT[offset + 1] = Math.round(51 + (240 - 51) * u);
      homeGuideLUT[offset + 2] = Math.round(102 + (255 - 102) * u);
      homeGuideLUT[offset + 3] = Math.round(170 + 85 * u);
    }

    // 3. Alarm (#4a0012 -> #ff0a43)
    if (i === 0) {
      alarmLUT[offset] = 0;
      alarmLUT[offset + 1] = 0;
      alarmLUT[offset + 2] = 0;
      alarmLUT[offset + 3] = 0;
    } else {
      alarmLUT[offset] = Math.round(74 + (255 - 74) * gammaT);
      alarmLUT[offset + 1] = Math.round(10 * Math.pow(gammaT, 1.5));
      alarmLUT[offset + 2] = Math.round(18 + (67 - 18) * gammaT);
      alarmLUT[offset + 3] = Math.round(255 * gammaT);
    }
  }

  return { foodTrailLUT, homeGuideLUT, alarmLUT };
}

export class PheromoneGrid {
  public readonly worldWidth: number;
  public readonly worldHeight: number;
  public readonly cellSize: number = PHEROMONE_CELL_SIZE;
  public readonly cols: number;
  public readonly rows: number;
  public readonly size: number;

  // Double-buffered ping-pong arrays
  public foodTrail: Float32Array;
  public foodTrailBack: Float32Array;
  public homeGuide: Float32Array;
  public homeGuideBack: Float32Array;
  public alarm: Float32Array;
  public alarmBack: Float32Array;

  // Obstacle wall mask (1 = solid wall, 0 = open) and smoothed organic contour field [0..1]
  public wallMask: Uint8Array;
  public smoothedWall: Float32Array;
  public dirtyRect: DirtyRect;

  public readonly luts: PheromoneLUTs;

  constructor(worldWidth: number, worldHeight: number) {
    this.worldWidth = worldWidth;
    this.worldHeight = worldHeight;
    this.cols = Math.ceil(worldWidth / this.cellSize);
    this.rows = Math.ceil(worldHeight / this.cellSize);
    this.size = this.cols * this.rows;

    this.foodTrail = new Float32Array(this.size);
    this.foodTrailBack = new Float32Array(this.size);
    this.homeGuide = new Float32Array(this.size);
    this.homeGuideBack = new Float32Array(this.size);
    this.alarm = new Float32Array(this.size);
    this.alarmBack = new Float32Array(this.size);

    this.wallMask = new Uint8Array(this.size);
    this.smoothedWall = new Float32Array(this.size);

    this.dirtyRect = {
      dirty: true,
      minCellX: 0,
      minCellY: 0,
      maxCellX: this.cols - 1,
      maxCellY: this.rows - 1,
    };

    this.luts = createPheromoneLUTs();
  }

  public clearPheromones(): void {
    this.foodTrail.fill(0);
    this.foodTrailBack.fill(0);
    this.homeGuide.fill(0);
    this.homeGuideBack.fill(0);
    this.alarm.fill(0);
    this.alarmBack.fill(0);
  }

  public clearAll(): void {
    this.clearPheromones();
    this.wallMask.fill(0);
    this.smoothedWall.fill(0);
    this.markFullTerrainDirty();
  }

  public markFullTerrainDirty(): void {
    this.dirtyRect.dirty = true;
    this.dirtyRect.minCellX = 0;
    this.dirtyRect.minCellY = 0;
    this.dirtyRect.maxCellX = this.cols - 1;
    this.dirtyRect.maxCellY = this.rows - 1;
  }

  public expandDirtyRect(minX: number, minY: number, maxX: number, maxY: number): void {
    const margin = 4;
    const cMinX = Math.max(0, Math.min(this.cols - 1, minX - margin));
    const cMinY = Math.max(0, Math.min(this.rows - 1, minY - margin));
    const cMaxX = Math.max(0, Math.min(this.cols - 1, maxX + margin));
    const cMaxY = Math.max(0, Math.min(this.rows - 1, maxY + margin));

    if (!this.dirtyRect.dirty) {
      this.dirtyRect.dirty = true;
      this.dirtyRect.minCellX = cMinX;
      this.dirtyRect.minCellY = cMinY;
      this.dirtyRect.maxCellX = cMaxX;
      this.dirtyRect.maxCellY = cMaxY;
    } else {
      if (cMinX < this.dirtyRect.minCellX) this.dirtyRect.minCellX = cMinX;
      if (cMinY < this.dirtyRect.minCellY) this.dirtyRect.minCellY = cMinY;
      if (cMaxX > this.dirtyRect.maxCellX) this.dirtyRect.maxCellX = cMaxX;
      if (cMaxY > this.dirtyRect.maxCellY) this.dirtyRect.maxCellY = cMaxY;
    }
  }

  /** Recomputes smoothed organic wall field inside a cell bounding box */
  public updateSmoothedWallRegion(minX: number, minY: number, maxX: number, maxY: number): void {
    const cols = this.cols;
    const rows = this.rows;
    const mask = this.wallMask;
    const smoothed = this.smoothedWall;

    const x0 = Math.max(0, minX);
    const y0 = Math.max(0, minY);
    const x1 = Math.min(cols - 1, maxX);
    const y1 = Math.min(rows - 1, maxY);

    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        let sum = 0;
        let weightSum = 0;
        for (let dy = -2; dy <= 2; dy++) {
          const ny = y + dy;
          if (ny < 0 || ny >= rows) continue;
          for (let dx = -2; dx <= 2; dx++) {
            const nx = x + dx;
            if (nx < 0 || nx >= cols) continue;
            const w = dx === 0 && dy === 0 ? 4.0 : Math.abs(dx) + Math.abs(dy) === 1 ? 2.0 : 1.0;
            sum += mask[ny * cols + nx] * w;
            weightSum += w;
          }
        }
        smoothed[y * cols + x] = weightSum > 0 ? sum / weightSum : 0;
      }
    }
  }

  public isWallAtWorld(worldX: number, worldY: number): boolean {
    const cx = Math.floor(worldX / this.cellSize);
    const cy = Math.floor(worldY / this.cellSize);
    if (cx < 0 || cx >= this.cols || cy < 0 || cy >= this.rows) return true;
    return this.wallMask[cy * this.cols + cx] === 1;
  }

  /**
   * Line-of-sight check between two world coordinates (e.g., ant head to antenna tip)
   * ensuring sensors never sample chemicals through solid obstacles.
   */
  public hasLineOfSight(x0: number, y0: number, x1: number, y1: number): boolean {
    const steps = 4;
    const dx = (x1 - x0) / steps;
    const dy = (y1 - y0) / steps;
    for (let i = 1; i <= steps; i++) {
      const sx = x0 + dx * i;
      const sy = y0 + dy * i;
      if (this.isWallAtWorld(sx, sy)) return false;
    }
    return true;
  }

  public sampleFieldAtWorld(field: Float32Array, worldX: number, worldY: number): number {
    const cx = Math.floor(worldX / this.cellSize);
    const cy = Math.floor(worldY / this.cellSize);
    if (cx < 0 || cx >= this.cols || cy < 0 || cy >= this.rows) return 0;
    const idx = cy * this.cols + cx;
    if (this.wallMask[idx] === 1) return 0;
    return field[idx];
  }

  public depositAtWorld(
    field: Float32Array,
    worldX: number,
    worldY: number,
    amount: number
  ): void {
    const cx = Math.floor(worldX / this.cellSize);
    const cy = Math.floor(worldY / this.cellSize);
    if (cx < 0 || cx >= this.cols || cy < 0 || cy >= this.rows) return;
    const idx = cy * this.cols + cx;
    if (this.wallMask[idx] === 1) return;
    const next = field[idx] + amount;
    field[idx] = next > MAX_PHEROMONE_CONCENTRATION ? MAX_PHEROMONE_CONCENTRATION : next;
  }

  /**
   * Executes Frame-Rate-Independent Exponential Evaporation and
   * CFL-Stable 3x3 Weighted Laplacian/Box Diffusion with strict Zero-Flux Neumann Boundaries.
   */
  public stepPhysics(dt: number, evaporationLambda: number, diffusionCoeff: number): void {
    const cols = this.cols;
    const rows = this.rows;
    const mask = this.wallMask;

    // Exact exponential decay factors
    const trailDecay = Math.exp(-dt * evaporationLambda);
    const alarmDecay = Math.exp(-dt * evaporationLambda * 3.5); // 3.5x faster alarm decay

    // Clamp diffusion coefficient for strict 2D explicit CFL stability (alpha <= 0.24)
    const alpha = Math.min(0.24, Math.max(0.0, diffusionCoeff));
    const oneMinusAlpha = 1.0 - alpha;
    // 3x3 stencil weights: orthogonal neighbors = 0.15, diagonal neighbors = 0.10 (sum = 1.0)
    const wOrtho = 0.15;
    const wDiag = 0.10;

    const fSrc = this.foodTrail;
    const fDst = this.foodTrailBack;
    const hSrc = this.homeGuide;
    const hDst = this.homeGuideBack;
    const aSrc = this.alarm;
    const aDst = this.alarmBack;

    for (let y = 0; y < rows; y++) {
      const rowOffset = y * cols;
      const yUp = y > 0 ? (y - 1) * cols : rowOffset;
      const yDown = y < rows - 1 ? (y + 1) * cols : rowOffset;

      for (let x = 0; x < cols; x++) {
        const idx = rowOffset + x;
        if (mask[idx] === 1) {
          fDst[idx] = 0;
          hDst[idx] = 0;
          aDst[idx] = 0;
          continue;
        }

        const fCenter = fSrc[idx];
        const hCenter = hSrc[idx];
        const aCenter = aSrc[idx];

        const xLeft = x > 0 ? x - 1 : x;
        const xRight = x < cols - 1 ? x + 1 : x;

        const idxN = yUp + x;
        const idxS = yDown + x;
        const idxW = rowOffset + xLeft;
        const idxE = rowOffset + xRight;
        const idxNW = yUp + xLeft;
        const idxNE = yUp + xRight;
        const idxSW = yDown + xLeft;
        const idxSE = yDown + xRight;

        // Zero-flux Neumann condition: if neighbor is wall, substitute center cell value
        const mN = mask[idxN] === 0;
        const mS = mask[idxS] === 0;
        const mW = mask[idxW] === 0;
        const mE = mask[idxE] === 0;
        const mNW = mask[idxNW] === 0;
        const mNE = mask[idxNE] === 0;
        const mSW = mask[idxSW] === 0;
        const mSE = mask[idxSE] === 0;

        // Food Trail stencil
        const fAvg =
          wOrtho *
            ((mN ? fSrc[idxN] : fCenter) +
              (mS ? fSrc[idxS] : fCenter) +
              (mW ? fSrc[idxW] : fCenter) +
              (mE ? fSrc[idxE] : fCenter)) +
          wDiag *
            ((mNW ? fSrc[idxNW] : fCenter) +
              (mNE ? fSrc[idxNE] : fCenter) +
              (mSW ? fSrc[idxSW] : fCenter) +
              (mSE ? fSrc[idxSE] : fCenter));

        const fNext = (oneMinusAlpha * fCenter + alpha * fAvg) * trailDecay;
        fDst[idx] = fNext < 0.0005 ? 0 : fNext;

        // Home Guide stencil
        const hAvg =
          wOrtho *
            ((mN ? hSrc[idxN] : hCenter) +
              (mS ? hSrc[idxS] : hCenter) +
              (mW ? hSrc[idxW] : hCenter) +
              (mE ? hSrc[idxE] : hCenter)) +
          wDiag *
            ((mNW ? hSrc[idxNW] : hCenter) +
              (mNE ? hSrc[idxNE] : hCenter) +
              (mSW ? hSrc[idxSW] : hCenter) +
              (mSE ? hSrc[idxSE] : hCenter));

        const hNext = (oneMinusAlpha * hCenter + alpha * hAvg) * trailDecay;
        hDst[idx] = hNext < 0.0005 ? 0 : hNext;

        // Alarm stencil
        const aAvg =
          wOrtho *
            ((mN ? aSrc[idxN] : aCenter) +
              (mS ? aSrc[idxS] : aCenter) +
              (mW ? aSrc[idxW] : aCenter) +
              (mE ? aSrc[idxE] : aCenter)) +
          wDiag *
            ((mNW ? aSrc[idxNW] : aCenter) +
              (mNE ? aSrc[idxNE] : aCenter) +
              (mSW ? aSrc[idxSW] : aCenter) +
              (mSE ? aSrc[idxSE] : aCenter));

        const aNext = (oneMinusAlpha * aCenter + alpha * aAvg) * alarmDecay;
        aDst[idx] = aNext < 0.0005 ? 0 : aNext;
      }
    }

    // Ping-pong swap
    this.foodTrail = fDst;
    this.foodTrailBack = fSrc;
    this.homeGuide = hDst;
    this.homeGuideBack = hSrc;
    this.alarm = aDst;
    this.alarmBack = aSrc;
  }

  /**
   * Paints a circular brush dab onto the target pheromone or wall/eraser field.
   */
  public applyBrushDab(
    worldX: number,
    worldY: number,
    radiusWorld: number,
    mode: "foodTrail" | "homeGuide" | "alarm" | "wall" | "eraser",
    intensity: number,
    nestX: number,
    nestY: number,
    nestSafeRadius: number
  ): boolean {
    const cx = Math.floor(worldX / this.cellSize);
    const cy = Math.floor(worldY / this.cellSize);
    const cellRadius = Math.ceil(radiusWorld / this.cellSize);
    const rSq = radiusWorld * radiusWorld;

    const minX = Math.max(1, cx - cellRadius);
    const maxX = Math.min(this.cols - 2, cx + cellRadius);
    const minY = Math.max(1, cy - cellRadius);
    const maxY = Math.min(this.rows - 2, cy + cellRadius);

    let touchedNestWithEraser = false;
    let wallChanged = false;

    for (let y = minY; y <= maxY; y++) {
      const py = (y + 0.5) * this.cellSize;
      const dy = py - worldY;
      for (let x = minX; x <= maxX; x++) {
        const px = (x + 0.5) * this.cellSize;
        const dx = px - worldX;
        const distSq = dx * dx + dy * dy;
        if (distSq > rSq) continue;

        const idx = y * this.cols + x;
        const falloff = 1.0 - Math.sqrt(distSq) / radiusWorld;

        // Check distance to Nest
        const ndx = px - nestX;
        const ndy = py - nestY;
        const distToNestSq = ndx * ndx + ndy * ndy;

        if (mode === "wall") {
          if (distToNestSq <= nestSafeRadius * nestSafeRadius) continue;
          if (this.wallMask[idx] === 0 && falloff > 0.2) {
            this.wallMask[idx] = 1;
            this.foodTrail[idx] = 0;
            this.homeGuide[idx] = 0;
            this.alarm[idx] = 0;
            wallChanged = true;
          }
        } else if (mode === "eraser") {
          if (distToNestSq <= nestSafeRadius * nestSafeRadius) {
            touchedNestWithEraser = true;
          }
          if (this.wallMask[idx] === 1) {
            this.wallMask[idx] = 0;
            wallChanged = true;
          }
          this.foodTrail[idx] = 0;
          this.homeGuide[idx] = 0;
          this.alarm[idx] = 0;
        } else {
          if (this.wallMask[idx] === 1) continue;
          const addAmount = intensity * falloff * 0.65;
          if (mode === "foodTrail") {
            this.foodTrail[idx] = Math.min(
              MAX_PHEROMONE_CONCENTRATION,
              this.foodTrail[idx] + addAmount
            );
          } else if (mode === "homeGuide") {
            this.homeGuide[idx] = Math.min(
              MAX_PHEROMONE_CONCENTRATION,
              this.homeGuide[idx] + addAmount
            );
          } else if (mode === "alarm") {
            this.alarm[idx] = Math.min(
              MAX_PHEROMONE_CONCENTRATION,
              this.alarm[idx] + addAmount
            );
          }
        }
      }
    }

    if (wallChanged) {
      this.updateSmoothedWallRegion(minX - 3, minY - 3, maxX + 3, maxY + 3);
      this.expandDirtyRect(minX, minY, maxX, maxY);
    }

    return touchedNestWithEraser;
  }

  /**
   * Renders the three pheromone fields into a preallocated RGBA ImageData buffer
   * using the 256-entry non-linear RGB LUTs. Zero allocations inside loop.
   */
  public renderToImageData(imgData: ImageData): void {
    const data = imgData.data;
    const size = this.size;
    const fField = this.foodTrail;
    const hField = this.homeGuide;
    const aField = this.alarm;
    const mask = this.wallMask;

    const fLUT = this.luts.foodTrailLUT;
    const hLUT = this.luts.homeGuideLUT;
    const aLUT = this.luts.alarmLUT;
    const scale = 255.0 / MAX_PHEROMONE_CONCENTRATION;

    for (let i = 0; i < size; i++) {
      const pIdx = i * 4;
      if (mask[i] === 1) {
        data[pIdx] = 0;
        data[pIdx + 1] = 0;
        data[pIdx + 2] = 0;
        data[pIdx + 3] = 0;
        continue;
      }

      const fVal = fField[i];
      const hVal = hField[i];
      const aVal = aField[i];

      if (fVal < 0.05 && hVal < 0.05 && aVal < 0.05) {
        data[pIdx] = 0;
        data[pIdx + 1] = 0;
        data[pIdx + 2] = 0;
        data[pIdx + 3] = 0;
        continue;
      }

      const fIdx = Math.min(255, (fVal * scale) | 0) * 4;
      const hIdx = Math.min(255, (hVal * scale) | 0) * 4;
      const aIdx = Math.min(255, (aVal * scale) | 0) * 4;

      // Screen-like additive blend across the 3 LUT channels
      const r = fLUT[fIdx] + hLUT[hIdx] + aLUT[aIdx];
      const g = fLUT[fIdx + 1] + hLUT[hIdx + 1] + aLUT[aIdx + 1];
      const b = fLUT[fIdx + 2] + hLUT[hIdx + 2] + aLUT[aIdx + 2];
      const a = Math.max(fLUT[fIdx + 3], hLUT[hIdx + 3], aLUT[aIdx + 3]);

      data[pIdx] = r > 255 ? 255 : r;
      data[pIdx + 1] = g > 255 ? 255 : g;
      data[pIdx + 2] = b > 255 ? 255 : b;
      data[pIdx + 3] = a > 255 ? 255 : a;
    }
  }
}
