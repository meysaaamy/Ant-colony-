import { SeededPRNG, tileableNoise2D, fbm2D } from "./prng-noise";

export const ANT_SPRITE_SIZE = 48; // 2x resolution cell size
export const ANT_SPRITE_FRAMES = 8;
export const ANT_SPRITE_STATES = 3; // 0: normal, 1: carrying food, 2: alarmed
export const CRYSTAL_VARIANT_COUNT = 8;
export const CRYSTAL_SPRITE_SIZE = 96;

export interface ProceduralAssetBundle {
  soilTile: HTMLCanvasElement;
  macroPlate: HTMLCanvasElement;
  basaltTile: HTMLCanvasElement;
  antSpriteSheet: HTMLCanvasElement;
  crystalVariants: HTMLCanvasElement[];
  crystalGlowSprite: HTMLCanvasElement;
  nestGlowSprite: HTMLCanvasElement;
  vignetteGrainCanvas: HTMLCanvasElement;
}

function createOffscreenCanvas(width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

/**
 * Synthesizes seamless dark soil albedo texture (256x256).
 * Strictly clamped so no pixel exceeds #0a0f18 (R<=10, G<=15, B<=24).
 */
function bakeSoilSubstrateTile(): HTMLCanvasElement {
  const size = 256;
  const canvas = createOffscreenCanvas(size, size);
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  const img = ctx.createImageData(size, size);
  const data = img.data;
  const prng = new SeededPRNG(1337);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const n1 = tileableNoise2D((x / size) * 16, (y / size) * 16, 16, 16, 11);
      const n2 = tileableNoise2D((x / size) * 48, (y / size) * 48, 48, 48, 29);
      const grain = prng.next() * 0.18;
      const val = n1 * 0.55 + n2 * 0.3 + grain;

      // Base #03050a (3, 5, 10) up to strictly <= #0a0f18 (10, 15, 24)
      const r = Math.min(10, Math.max(2, Math.floor(3 + val * 6.5)));
      const g = Math.min(15, Math.max(4, Math.floor(5 + val * 9.5)));
      const b = Math.min(24, Math.max(8, Math.floor(9 + val * 14.5)));

      const idx = (y * size + x) * 4;
      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  return canvas;
}

/**
 * Synthesizes macro mineral striations & ancient root impressions (512x512),
 * strictly graded so no pixel exceeds #0a0f18.
 */
function bakeMacroPlate(): HTMLCanvasElement {
  const size = 512;
  const canvas = createOffscreenCanvas(size, size);
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  const img = ctx.createImageData(size, size);
  const data = img.data;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = x / size;
      const ny = y / size;
      const warpX = fbm2D(nx * 4, ny * 4, 3, 2, 0.5, 91) * 0.25;
      const warpY = fbm2D(nx * 4 + 5.2, ny * 4 + 1.3, 3, 2, 0.5, 141) * 0.25;
      const ridge = Math.abs(fbm2D((nx + warpX) * 6, (ny + warpY) * 6, 4, 2.1, 0.5, 211) - 0.5) * 2;
      const rootVein = Math.pow(Math.max(0, 1 - ridge * 2.2), 2.5);

      const r = Math.min(10, Math.floor(3 + rootVein * 6));
      const g = Math.min(15, Math.floor(5 + rootVein * 9));
      const b = Math.min(24, Math.floor(10 + rootVein * 13));

      const idx = (y * size + x) * 4;
      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  return canvas;
}

/**
 * Synthesizes seamless basalt-obsidian rock texture (256x256).
 * Mean around #101622 (16, 22, 34), highlights capped strictly below #26354d (38, 53, 77).
 */
function bakeBasaltRockTile(): HTMLCanvasElement {
  const size = 256;
  const canvas = createOffscreenCanvas(size, size);
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  const img = ctx.createImageData(size, size);
  const data = img.data;
  const prng = new SeededPRNG(9001);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const coarse = tileableNoise2D((x / size) * 8, (y / size) * 8, 8, 8, 307);
      const medium = tileableNoise2D((x / size) * 24, (y / size) * 24, 24, 24, 509);
      const fine = tileableNoise2D((x / size) * 64, (y / size) * 64, 64, 64, 701);
      const facet = Math.abs(coarse - 0.5) * 1.3 + medium * 0.45 + fine * 0.2 + prng.next() * 0.05;

      // Center around (16, 22, 34), cap strictly below (37, 52, 76)
      const r = Math.min(36, Math.max(10, Math.floor(11 + facet * 16)));
      const g = Math.min(51, Math.max(14, Math.floor(15 + facet * 23)));
      const b = Math.min(75, Math.max(22, Math.floor(24 + facet * 34)));

      const idx = (y * size + x) * 4;
      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  return canvas;
}

/**
 * Pre-renders the 8-frame x 3-state 2x-resolution articulated ant sprite sheet.
 * Orientation: Ant faces +X (angle 0 rad = right).
 */
function bakeAntSpriteSheet(): HTMLCanvasElement {
  const width = ANT_SPRITE_SIZE * ANT_SPRITE_FRAMES;
  const height = ANT_SPRITE_SIZE * ANT_SPRITE_STATES;
  const canvas = createOffscreenCanvas(width, height);
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  for (let state = 0; state < ANT_SPRITE_STATES; state++) {
    const isCarrying = state === 1;
    const isAlarmed = state === 2;

    const rimColor = isAlarmed
      ? "#ff0a43"
      : isCarrying
      ? "#38bdf8"
      : "#476288";
    const stripeColor = isAlarmed
      ? "rgba(255, 10, 67, 0.55)"
      : "rgba(255, 174, 0, 0.35)";

    for (let frame = 0; frame < ANT_SPRITE_FRAMES; frame++) {
      const cx = frame * ANT_SPRITE_SIZE + ANT_SPRITE_SIZE * 0.5;
      const cy = state * ANT_SPRITE_SIZE + ANT_SPRITE_SIZE * 0.5;
      const phase = (frame / ANT_SPRITE_FRAMES) * Math.PI * 2;

      ctx.save();
      ctx.translate(cx, cy);

      // Alternating tripod gait leg swing
      const swingA = Math.sin(phase) * 3.2;
      const swingB = Math.sin(phase + Math.PI) * 3.2;

      // 6 two-segment jointed legs (3 per side)
      ctx.strokeStyle = isAlarmed ? "#881337" : "#1e293b";
      ctx.lineWidth = 1.6;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      const legAnchors = [
        { ax: 2, ay: -2.2, kx: 5 + swingA * 0.5, ky: -8.5, fx: 7 + swingA, fy: -14.5 },
        { ax: -1, ay: -2.5, kx: -1 + swingB * 0.6, ky: -9.5, fx: -2 + swingB, fy: -16 },
        { ax: -4, ay: -2.2, kx: -8 + swingA * 0.5, ky: -8.5, fx: -13 + swingA, fy: -14.5 },
        { ax: 2, ay: 2.2, kx: 5 + swingB * 0.5, ky: 8.5, fx: 7 + swingB, fy: 14.5 },
        { ax: -1, ay: 2.5, kx: -1 + swingA * 0.6, ky: 9.5, fx: -2 + swingA, fy: 16 },
        { ax: -4, ay: 2.2, kx: -8 + swingB * 0.5, ky: 8.5, fx: -13 + swingB, fy: 14.5 },
      ];

      for (let i = 0; i < legAnchors.length; i++) {
        const leg = legAnchors[i];
        ctx.beginPath();
        ctx.moveTo(leg.ax, leg.ay);
        ctx.lineTo(leg.kx, leg.ky);
        ctx.lineTo(leg.fx, leg.fy);
        ctx.stroke();

        // Tarsus highlight
        ctx.strokeStyle = rimColor;
        ctx.lineWidth = 0.85;
        ctx.beginPath();
        ctx.moveTo(leg.kx, leg.ky);
        ctx.lineTo(leg.fx, leg.fy);
        ctx.stroke();
        ctx.strokeStyle = isAlarmed ? "#881337" : "#1e293b";
        ctx.lineWidth = 1.6;
      }

      // Elbowed antennae
      const antTwitch = Math.sin(phase * 2) * 0.9;
      ctx.strokeStyle = isAlarmed ? "#ff0a43" : "#64748b";
      ctx.lineWidth = 1.25;
      ctx.beginPath();
      ctx.moveTo(10.5, -2);
      ctx.lineTo(15, -5.5 + antTwitch * 0.5);
      ctx.lineTo(19.5, -3.5 + antTwitch);
      ctx.moveTo(10.5, 2);
      ctx.lineTo(15, 5.5 - antTwitch * 0.5);
      ctx.lineTo(19.5, 3.5 - antTwitch);
      ctx.stroke();

      // If carrying food, draw glowing emerald shard in mandibles
      if (isCarrying) {
        const grad = ctx.createRadialGradient(16, 0, 0.5, 16, 0, 7.5);
        grad.addColorStop(0, "#b9f6ca");
        grad.addColorStop(0.45, "#00e676");
        grad.addColorStop(1, "rgba(0, 230, 118, 0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(16, 0, 7.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#00e676";
        ctx.strokeStyle = "#e8f5e9";
        ctx.lineWidth = 0.9;
        ctx.beginPath();
        ctx.moveTo(19.5, 0);
        ctx.lineTo(16, -3.4);
        ctx.lineTo(13, 0);
        ctx.lineTo(16, 3.4);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }

      // 1. Gaster (Abdomen)
      ctx.fillStyle = "#0d131f";
      ctx.strokeStyle = rimColor;
      ctx.lineWidth = 1.25;
      ctx.beginPath();
      ctx.ellipse(-11.5, 0, 6.8, 4.6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Banded gaster tergite stripes
      ctx.strokeStyle = stripeColor;
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.arc(-10.5, 0, 3.8, -1.1, 1.1);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(-13.2, 0, 3.2, -1.0, 1.0);
      ctx.stroke();

      // 2. Petiole node + Thorax (Mesosoma)
      ctx.fillStyle = "#111927";
      ctx.strokeStyle = rimColor;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.ellipse(-1, 0, 4.8, 2.7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // 3. Head (Prosoma)
      ctx.fillStyle = "#141d2e";
      ctx.strokeStyle = rimColor;
      ctx.lineWidth = 1.25;
      ctx.beginPath();
      ctx.ellipse(7.5, 0, 3.8, 3.3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Specular cuticle sheen on gaster, thorax, head
      ctx.fillStyle = "rgba(226, 232, 240, 0.28)";
      ctx.beginPath();
      ctx.ellipse(-12.5, -1.5, 3.2, 1.1, -0.15, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(-1.2, -0.8, 2.2, 0.7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(7.5, -1.0, 1.5, 0.8, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    }
  }

  return canvas;
}

/**
 * Pre-renders 8 faceted emerald nutrient crystal cluster variants (96x96 each).
 */
function bakeCrystalVariants(): HTMLCanvasElement[] {
  const variants: HTMLCanvasElement[] = [];
  const prng = new SeededPRNG(777);

  for (let v = 0; v < CRYSTAL_VARIANT_COUNT; v++) {
    const canvas = createOffscreenCanvas(CRYSTAL_SPRITE_SIZE, CRYSTAL_SPRITE_SIZE);
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      variants.push(canvas);
      continue;
    }

    const cx = CRYSTAL_SPRITE_SIZE * 0.5;
    const cy = CRYSTAL_SPRITE_SIZE * 0.5;
    const shardCount = 6 + (v % 3);

    ctx.save();
    ctx.translate(cx, cy);

    for (let s = 0; s < shardCount; s++) {
      const baseAngle = (s / shardCount) * Math.PI * 2 + prng.range(-0.2, 0.2);
      const length = prng.range(18, 34);
      const width = prng.range(7, 13);

      ctx.save();
      ctx.rotate(baseAngle);

      // Faceted hexagonal crystal prism
      const grad = ctx.createLinearGradient(0, -width, length, width);
      grad.addColorStop(0, "#052e16");
      grad.addColorStop(0.45, "#00e676");
      grad.addColorStop(1, "#b9f6ca");

      ctx.fillStyle = grad;
      ctx.strokeStyle = "#69f0ae";
      ctx.lineWidth = 1.25;

      ctx.beginPath();
      ctx.moveTo(2, -width * 0.45);
      ctx.lineTo(length * 0.72, -width * 0.55);
      ctx.lineTo(length, 0);
      ctx.lineTo(length * 0.72, width * 0.55);
      ctx.lineTo(2, width * 0.45);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Inner refraction streak
      ctx.strokeStyle = "rgba(255, 255, 255, 0.55)";
      ctx.lineWidth = 1.0;
      ctx.beginPath();
      ctx.moveTo(5, -width * 0.12);
      ctx.lineTo(length * 0.82, 0);
      ctx.stroke();

      ctx.restore();
    }

    // Central high-refraction core
    const coreGrad = ctx.createRadialGradient(0, 0, 1, 0, 0, 14);
    coreGrad.addColorStop(0, "#ffffff");
    coreGrad.addColorStop(0.4, "#69f0ae");
    coreGrad.addColorStop(1, "rgba(0, 230, 118, 0)");
    ctx.fillStyle = coreGrad;
    ctx.beginPath();
    ctx.arc(0, 0, 14, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
    variants.push(canvas);
  }

  return variants;
}

/**
 * Pre-renders a soft radial emerald glow sprite (128x128) for zero-blur crystal breathing.
 */
function bakeRadialGlowSprite(innerColor: string, midColor: string): HTMLCanvasElement {
  const size = 128;
  const canvas = createOffscreenCanvas(size, size);
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  const half = size * 0.5;
  const grad = ctx.createRadialGradient(half, half, 2, half, half, half);
  grad.addColorStop(0, innerColor);
  grad.addColorStop(0.38, midColor);
  grad.addColorStop(1, "rgba(0, 0, 0, 0)");

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  return canvas;
}

/**
 * Pre-renders the cached atmosphere overlay combining soft vignette + fine film grain.
 */
function bakeVignetteAndGrain(): HTMLCanvasElement {
  const size = 512;
  const canvas = createOffscreenCanvas(size, size);
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  const prng = new SeededPRNG(4096);
  const img = ctx.createImageData(size, size);
  const data = img.data;
  const half = size * 0.5;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (x - half) / half;
      const dy = (y - half) / half;
      const distSq = dx * dx + dy * dy;
      const vignetteAlpha = Math.min(185, Math.max(0, Math.floor(Math.pow(distSq * 0.78, 1.65) * 185)));
      const grain = Math.floor((prng.next() - 0.5) * 14);

      const idx = (y * size + x) * 4;
      const base = Math.max(0, Math.min(255, 4 + grain));
      data[idx] = base;
      data[idx + 1] = base;
      data[idx + 2] = Math.min(255, base + 4);
      data[idx + 3] = Math.max(6, vignetteAlpha + Math.abs(grain));
    }
  }

  ctx.putImageData(img, 0, 0);
  return canvas;
}

export function generateProceduralAssets(): ProceduralAssetBundle {
  return {
    soilTile: bakeSoilSubstrateTile(),
    macroPlate: bakeMacroPlate(),
    basaltTile: bakeBasaltRockTile(),
    antSpriteSheet: bakeAntSpriteSheet(),
    crystalVariants: bakeCrystalVariants(),
    crystalGlowSprite: bakeRadialGlowSprite("rgba(105, 240, 174, 0.52)", "rgba(0, 230, 118, 0.16)"),
    nestGlowSprite: bakeRadialGlowSprite("rgba(0, 240, 255, 0.35)", "rgba(255, 174, 0, 0.12)"),
    vignetteGrainCanvas: bakeVignetteAndGrain(),
  };
}
