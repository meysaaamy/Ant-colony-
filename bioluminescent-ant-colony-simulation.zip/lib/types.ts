export type ToolMode =
  | "foodTrail"
  | "homeGuide"
  | "alarm"
  | "foodCluster"
  | "wall"
  | "eraser";

export type PresetId =
  | "open-sanctuary"
  | "double-bridge"
  | "subterranean-labyrinth";

export type TimeScale = 1 | 2 | 4;

export type SheetSnapPoint = "peek" | "half" | "full";

export type ParameterTab = "Colony" | "Pheromones" | "Brush" | "World";

export const ANT_STATE_FORAGING = 0;
export const ANT_STATE_RETURNING = 1;
export const ANT_STATE_ALARMED = 2;

export const MAX_ANTS = 3000;
export const PHEROMONE_CELL_SIZE = 6;
export const SPATIAL_HASH_CELL_SIZE = 24;

export interface SimulationParams {
  maxPopulation: number;
  evaporationRate: number; // lambda (s^-1)
  diffusionRate: number; // D (0.02..0.24)
  trailSensitivity: number; // alpha (0.5..5.0)
  antennaAngleDeg: number; // degrees (15..65)
  brushRadius: number; // logical world units (12..72)
  depositionIntensity: number; // 10..100
  timeScale: TimeScale;
  paused: boolean;
}

export const DEFAULT_SIMULATION_PARAMS: SimulationParams = {
  maxPopulation: 650,
  evaporationRate: 0.11,
  diffusionRate: 0.12,
  trailSensitivity: 2.5,
  antennaAngleDeg: 34,
  brushRadius: 28,
  depositionIntensity: 78,
  timeScale: 1,
  paused: false,
};

export interface FoodCluster {
  id: number;
  x: number;
  y: number;
  amount: number;
  maxAmount: number;
  baseRadius: number;
  variant: number;
  pulsePhase: number;
  glintTimer: number;
}

export interface NestState {
  x: number;
  y: number;
  radius: number;
  storedFood: number;
  deliveryPulse: number;
  eraserProtectPulse: number;
  heartbeatPhase: number;
}

export interface MicroSpark {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  active: boolean;
}

export interface SporeMote {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  phase: number;
  color: string;
}

export interface StrokeRibbonPoint {
  x: number;
  y: number;
  radius: number;
  age: number;
}

export interface ActiveStrokeState {
  active: boolean;
  pointerId: number | null;
  tool: ToolMode;
  worldX: number;
  worldY: number;
  lastWorldX: number;
  lastWorldY: number;
  prevWorldX: number;
  prevWorldY: number;
  startX: number;
  startY: number;
  startRipple: number;
  ribbon: StrokeRibbonPoint[];
  ribbonCount: number;
}

export interface DirtyRect {
  dirty: boolean;
  minCellX: number;
  minCellY: number;
  maxCellX: number;
  maxCellY: number;
}

export interface TelemetrySnapshot {
  fps: number;
  activeAnts: number;
  storedFood: number;
  qualityTier: "high" | "adaptive";
  presetId: PresetId;
}

export interface PresetDefinition {
  id: PresetId;
  name: string;
  subtitle: string;
  description: string;
  initialAnts: number;
}
