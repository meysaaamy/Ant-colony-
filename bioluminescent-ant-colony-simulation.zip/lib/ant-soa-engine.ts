import {
  ANT_STATE_ALARMED,
  ANT_STATE_FORAGING,
  ANT_STATE_RETURNING,
  FoodCluster,
  MAX_ANTS,
  MicroSpark,
  NestState,
  SimulationParams,
  SPATIAL_HASH_CELL_SIZE,
} from "./types";
import { computeSaturatingDeposit, PheromoneGrid } from "./pheromone-grid";
import { SeededPRNG } from "./prng-noise";

/**
 * Weber-Fechner Law: transforms raw chemical concentration C >= 0
 * into perceived neural stimulus S = ln(1.0 + C).
 */
export function weberFechnerLaw(concentration: number): number {
  return Math.log(1.0 + (concentration > 0 ? concentration : 0));
}

/** Normalize angle to [-PI, PI] */
function wrapAngle(a: number): number {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

export class AntColonyEngine {
  public readonly worldWidth: number;
  public readonly worldHeight: number;

  // Structure-of-Arrays (SoA) preallocated TypedArrays for 3,000 ants
  public readonly x = new Float32Array(MAX_ANTS);
  public readonly y = new Float32Array(MAX_ANTS);
  public readonly vx = new Float32Array(MAX_ANTS);
  public readonly vy = new Float32Array(MAX_ANTS);
  public readonly angle = new Float32Array(MAX_ANTS);
  public readonly speed = new Float32Array(MAX_ANTS);
  public readonly homeDx = new Float32Array(MAX_ANTS);
  public readonly homeDy = new Float32Array(MAX_ANTS);
  public readonly legPhase = new Float32Array(MAX_ANTS);
  public readonly pheromoneTimer = new Float32Array(MAX_ANTS);
  public readonly timeSinceLastVisit = new Float32Array(MAX_ANTS);
  public readonly ouNoise = new Float32Array(MAX_ANTS);
  public readonly excitementTimer = new Float32Array(MAX_ANTS);
  public readonly stuckTimer = new Float32Array(MAX_ANTS);

  public readonly state = new Uint8Array(MAX_ANTS);
  public readonly carryingFood = new Uint8Array(MAX_ANTS);
  public readonly active = new Uint8Array(MAX_ANTS);

  public activeCount = 0;

  // O(1) 1D Spatial Hash Grid
  public readonly hashCellSize = SPATIAL_HASH_CELL_SIZE;
  public readonly hashCols: number;
  public readonly hashRows: number;
  public readonly hashHead: Int32Array;
  public readonly hashNext = new Int32Array(MAX_ANTS);

  // World entities
  public nest: NestState;
  public foodClusters: FoodCluster[] = [];
  private nextClusterId = 1;

  // Preallocated micro-spark pool for crystal harvests & active stroke
  public readonly maxSparks = 160;
  public readonly sparks: MicroSpark[] = [];
  private sparkCursor = 0;

  public readonly prng = new SeededPRNG(202605);

  // Event callbacks for contextual captions & toasts
  public onFirstFoodDelivered?: () => void;
  public onCapacityReached?: () => void;
  private hasDeliveredFoodOnce = false;
  private hasNotifiedCapacity = false;

  constructor(worldWidth: number, worldHeight: number) {
    this.worldWidth = worldWidth;
    this.worldHeight = worldHeight;
    this.hashCols = Math.ceil(worldWidth / this.hashCellSize);
    this.hashRows = Math.ceil(worldHeight / this.hashCellSize);
    this.hashHead = new Int32Array(this.hashCols * this.hashRows);
    this.hashHead.fill(-1);

    this.nest = {
      x: worldWidth * 0.2,
      y: worldHeight * 0.5,
      radius: 28,
      storedFood: 0,
      deliveryPulse: 0,
      eraserProtectPulse: 0,
      heartbeatPhase: 0,
    };

    for (let i = 0; i < this.maxSparks; i++) {
      this.sparks.push({
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        life: 0,
        maxLife: 0.5,
        color: "#00e676",
        size: 2,
        active: false,
      });
    }
  }

  public resetColony(nestX: number, nestY: number, initialAnts: number, maxPop: number): void {
    this.nest.x = nestX;
    this.nest.y = nestY;
    this.nest.storedFood = 0;
    this.nest.deliveryPulse = 0;
    this.nest.eraserProtectPulse = 0;
    this.active.fill(0);
    this.activeCount = 0;
    this.hasNotifiedCapacity = false;

    const count = Math.min(MAX_ANTS, Math.min(maxPop, initialAnts));
    for (let i = 0; i < count; i++) {
      this.spawnSingleAntAtNest();
    }
  }

  public spawnSingleAntAtNest(maxPop = MAX_ANTS): boolean {
    if (this.activeCount >= Math.min(MAX_ANTS, maxPop)) {
      if (!this.hasNotifiedCapacity && this.onCapacityReached) {
        this.hasNotifiedCapacity = true;
        this.onCapacityReached();
      }
      return false;
    }

    const idx = this.activeCount;
    const spawnAngle = this.prng.range(0, Math.PI * 2);
    const spawnDist = this.prng.range(4, this.nest.radius * 0.78);

    const px = this.nest.x + Math.cos(spawnAngle) * spawnDist;
    const py = this.nest.y + Math.sin(spawnAngle) * spawnDist;

    this.x[idx] = px;
    this.y[idx] = py;
    this.angle[idx] = spawnAngle;
    this.speed[idx] = 86 + this.prng.range(-8, 12);
    this.vx[idx] = Math.cos(spawnAngle) * this.speed[idx];
    this.vy[idx] = Math.sin(spawnAngle) * this.speed[idx];
    this.homeDx[idx] = this.nest.x - px;
    this.homeDy[idx] = this.nest.y - py;
    this.legPhase[idx] = this.prng.range(0, 8);
    this.pheromoneTimer[idx] = this.prng.range(0, 0.08);
    this.timeSinceLastVisit[idx] = 0;
    this.ouNoise[idx] = 0;
    this.excitementTimer[idx] = 0;
    this.stuckTimer[idx] = 0;
    this.state[idx] = ANT_STATE_FORAGING;
    this.carryingFood[idx] = 0;
    this.active[idx] = 1;

    this.activeCount++;
    return true;
  }

  public enforcePopulationCap(maxPop: number): void {
    const cap = Math.min(MAX_ANTS, Math.max(10, maxPop));
    if (this.activeCount > cap) {
      for (let i = cap; i < this.activeCount; i++) {
        this.active[i] = 0;
      }
      this.activeCount = cap;
    }
    if (this.activeCount < cap) {
      this.hasNotifiedCapacity = false;
    }
  }

  public addFoodCluster(x: number, y: number, amount = 180, radius = 26): void {
    // Prevent placing directly inside Nest
    const dx = x - this.nest.x;
    const dy = y - this.nest.y;
    if (dx * dx + dy * dy < (this.nest.radius + radius + 12) ** 2) return;

    // Merge if very close to existing cluster
    for (let i = 0; i < this.foodClusters.length; i++) {
      const c = this.foodClusters[i];
      const cdx = x - c.x;
      const cdy = y - c.y;
      if (cdx * cdx + cdy * cdy < (c.baseRadius + radius * 0.65) ** 2) {
        c.amount = Math.min(600, c.amount + amount * 0.6);
        c.maxAmount = Math.max(c.maxAmount, c.amount);
        return;
      }
    }

    if (this.foodClusters.length >= 28) return;

    this.foodClusters.push({
      id: this.nextClusterId++,
      x,
      y,
      amount,
      maxAmount: amount,
      baseRadius: radius,
      variant: Math.floor(this.prng.next() * 8),
      pulsePhase: this.prng.range(0, Math.PI * 2),
      glintTimer: this.prng.range(0.5, 3.5),
    });
  }

  public eraseEntitiesInRadius(worldX: number, worldY: number, radius: number): void {
    const rSq = (radius + 10) * (radius + 10);
    for (let i = this.foodClusters.length - 1; i >= 0; i--) {
      const c = this.foodClusters[i];
      const dx = c.x - worldX;
      const dy = c.y - worldY;
      if (dx * dx + dy * dy <= rSq) {
        this.foodClusters.splice(i, 1);
      }
    }
  }

  public emitSparks(
    worldX: number,
    worldY: number,
    count: number,
    color: string,
    speedScale = 1.0
  ): void {
    for (let i = 0; i < count; i++) {
      const s = this.sparks[this.sparkCursor];
      this.sparkCursor = (this.sparkCursor + 1) % this.maxSparks;
      const ang = this.prng.range(0, Math.PI * 2);
      const spd = this.prng.range(18, 68) * speedScale;
      s.x = worldX + this.prng.range(-4, 4);
      s.y = worldY + this.prng.range(-4, 4);
      s.vx = Math.cos(ang) * spd;
      s.vy = Math.sin(ang) * spd;
      s.life = 0;
      s.maxLife = this.prng.range(0.28, 0.62);
      s.color = color;
      s.size = this.prng.range(1.4, 2.8);
      s.active = true;
    }
  }

  /**
   * Safely ejects any ants overlapped by newly painted walls to the nearest open cell.
   */
  public ejectAntsFromWalls(grid: PheromoneGrid): void {
    const count = this.activeCount;
    for (let i = 0; i < count; i++) {
      const ax = this.x[i];
      const ay = this.y[i];
      if (!grid.isWallAtWorld(ax, ay)) continue;

      // Spiral search outward for nearest open cell
      let found = false;
      for (let ring = 1; ring <= 18 && !found; ring++) {
        const dist = ring * grid.cellSize;
        for (let step = 0; step < 12; step++) {
          const theta = (step / 12) * Math.PI * 2;
          const tx = ax + Math.cos(theta) * dist;
          const ty = ay + Math.sin(theta) * dist;
          if (
            tx > 12 &&
            tx < this.worldWidth - 12 &&
            ty > 12 &&
            ty < this.worldHeight - 12 &&
            !grid.isWallAtWorld(tx, ty)
          ) {
            this.x[i] = tx;
            this.y[i] = ty;
            this.angle[i] = theta;
            found = true;
            break;
          }
        }
      }
    }
  }

  private rebuildSpatialHash(): void {
    this.hashHead.fill(-1);
    const cols = this.hashCols;
    const rows = this.hashRows;
    const invCell = 1.0 / this.hashCellSize;
    const count = this.activeCount;

    for (let i = 0; i < count; i++) {
      let cx = (this.x[i] * invCell) | 0;
      let cy = (this.y[i] * invCell) | 0;
      if (cx < 0) cx = 0;
      else if (cx >= cols) cx = cols - 1;
      if (cy < 0) cy = 0;
      else if (cy >= rows) cy = rows - 1;

      const cellIdx = cy * cols + cx;
      this.hashNext[i] = this.hashHead[cellIdx];
      this.hashHead[cellIdx] = i;
    }
  }

  /**
   * Advances all active ants, spatial hash interactions, bilateral tropotaxis,
   * Weber-Fechner steering, path integration, and colony metabolism by dt seconds.
   */
  public stepAnts(dt: number, grid: PheromoneGrid, params: SimulationParams): void {
    this.enforcePopulationCap(params.maxPopulation);

    // Update Nest pulses
    this.nest.heartbeatPhase = (this.nest.heartbeatPhase + dt * 2.2) % (Math.PI * 2);
    if (this.nest.deliveryPulse > 0) {
      this.nest.deliveryPulse = Math.max(0, this.nest.deliveryPulse - dt * 2.4);
    }
    if (this.nest.eraserProtectPulse > 0) {
      this.nest.eraserProtectPulse = Math.max(0, this.nest.eraserProtectPulse - dt * 2.5);
    }

    // Update food cluster animations
    for (let i = 0; i < this.foodClusters.length; i++) {
      const c = this.foodClusters[i];
      c.pulsePhase = (c.pulsePhase + dt * 2.0) % (Math.PI * 2);
      c.glintTimer -= dt;
      if (c.glintTimer <= -0.35) {
        c.glintTimer = this.prng.range(1.8, 4.5);
      }
    }

    // Update micro-sparks
    for (let i = 0; i < this.maxSparks; i++) {
      const s = this.sparks[i];
      if (!s.active) continue;
      s.life += dt;
      if (s.life >= s.maxLife) {
        s.active = false;
        continue;
      }
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.vx *= 0.92;
      s.vy *= 0.92;
    }

    // Rebuild O(1) spatial hash grid
    this.rebuildSpatialHash();

    const count = this.activeCount;
    const sensorDist = 17.5;
    const sensorAngleRad = (params.antennaAngleDeg * Math.PI) / 180;
    const alphaSensitivity = params.trailSensitivity;
    const depositDecayRate = 0.085;
    const baseDepositStrength = (params.depositionIntensity / 78) * 18.0;

    const nestX = this.nest.x;
    const nestY = this.nest.y;
    const nestHarvestRadiusSq = (this.nest.radius + 7) * (this.nest.radius + 7);

    const wWidth = this.worldWidth;
    const wHeight = this.worldHeight;
    const margin = 12;

    for (let i = 0; i < count; i++) {
      let ax = this.x[i];
      let ay = this.y[i];
      let ang = this.angle[i];
      let st = this.state[i];
      const hasFood = this.carryingFood[i] === 1;

      this.timeSinceLastVisit[i] += dt;
      if (this.excitementTimer[i] > 0) {
        this.excitementTimer[i] = Math.max(0, this.excitementTimer[i] - dt);
        if (this.excitementTimer[i] === 0 && st === ANT_STATE_ALARMED) {
          st = hasFood ? ANT_STATE_RETURNING : ANT_STATE_FORAGING;
          this.state[i] = st;
        }
      }

      // 1. Bilateral Antenna Sensor Positions (Left: -theta, Center: 0, Right: +theta)
      const angL = ang - sensorAngleRad;
      const angR = ang + sensorAngleRad;

      const tipLX = ax + Math.cos(angL) * sensorDist;
      const tipLY = ay + Math.sin(angL) * sensorDist;
      const tipCX = ax + Math.cos(ang) * sensorDist;
      const tipCY = ay + Math.sin(ang) * sensorDist;
      const tipRX = ax + Math.cos(angR) * sensorDist;
      const tipRY = ay + Math.sin(angR) * sensorDist;

      const losL = grid.hasLineOfSight(ax, ay, tipLX, tipLY);
      const losC = grid.hasLineOfSight(ax, ay, tipCX, tipCY);
      const losR = grid.hasLineOfSight(ax, ay, tipRX, tipRY);

      // Check alarm pheromone at antenna tips
      const alarmL = losL ? grid.sampleFieldAtWorld(grid.alarm, tipLX, tipLY) : 0;
      const alarmC = losC ? grid.sampleFieldAtWorld(grid.alarm, tipCX, tipCY) : 0;
      const alarmR = losR ? grid.sampleFieldAtWorld(grid.alarm, tipRX, tipRY) : 0;

      const sAlarmL = weberFechnerLaw(alarmL);
      const sAlarmC = weberFechnerLaw(alarmC);
      const sAlarmR = weberFechnerLaw(alarmR);
      const totalAlarm = sAlarmL + sAlarmC + sAlarmR;

      if (totalAlarm > 0.35) {
        st = ANT_STATE_ALARMED;
        this.state[i] = st;
        this.excitementTimer[i] = 1.35;
      }

      // 2. Ornstein-Uhlenbeck persistent wander noise update
      let ou = this.ouNoise[i];
      ou += -3.2 * ou * dt + this.prng.gaussian() * 2.6 * Math.sqrt(dt);
      this.ouNoise[i] = ou;

      let steeringTorque = 0;
      let targetSpeed = 88;

      if (st === ANT_STATE_ALARMED) {
        // Evasive orthokinesis (speed boost) & repulsive klinokinesis away from alarm gradient
        const repelTurn = (sAlarmL - sAlarmR) * 4.2;
        steeringTorque = repelTurn + ou * 3.8;
        targetSpeed = 134;
      } else if (!hasFood) {
        // FORAGING: Sense foodTrail using Weber-Fechner law
        const cL = losL ? grid.sampleFieldAtWorld(grid.foodTrail, tipLX, tipLY) : 0;
        const cC = losC ? grid.sampleFieldAtWorld(grid.foodTrail, tipCX, tipCY) : 0;
        const cR = losR ? grid.sampleFieldAtWorld(grid.foodTrail, tipRX, tipRY) : 0;

        const sL = weberFechnerLaw(cL);
        const sC = weberFechnerLaw(cC);
        const sR = weberFechnerLaw(cR);

        // Bilateral difference weighted by center commitment
        const chemTorque =
          (alphaSensitivity * (sR - sL)) / (1.0 + 0.22 * sC);

        // Klinokinesis: suppress random wander when locked onto a strong trail
        const trailConfidence = Math.min(1.0, (sL + sC + sR) * 0.22);
        const wanderScale = 1.9 * (1.0 - 0.68 * trailConfidence);

        steeringTorque = chemTorque * 4.4 + ou * wanderScale;
        targetSpeed = 86 + trailConfidence * 24 + (this.excitementTimer[i] > 0 ? 22 : 0);

        // Social Antennation & Soft Neighbor Separation via 1D Spatial Hash
        const hcx = Math.max(0, Math.min(this.hashCols - 1, (ax / this.hashCellSize) | 0));
        const hcy = Math.max(0, Math.min(this.hashRows - 1, (ay / this.hashCellSize) | 0));
        let neighborChecks = 0;

        for (let ny = hcy - 1; ny <= hcy + 1; ny++) {
          if (ny < 0 || ny >= this.hashRows) continue;
          for (let nx = hcx - 1; nx <= hcx + 1; nx++) {
            if (nx < 0 || nx >= this.hashCols) continue;
            let other = this.hashHead[ny * this.hashCols + nx];
            while (other !== -1 && neighborChecks < 10) {
              if (other !== i) {
                neighborChecks++;
                const odx = this.x[other] - ax;
                const ody = this.y[other] - ay;
                const dSq = odx * odx + ody * ody;
                if (dSq > 0.01 && dSq < 156) {
                  // Antennation contact with a returning food-carrier!
                  if (this.carryingFood[other] === 1 && this.excitementTimer[i] <= 0) {
                    this.excitementTimer[i] = 0.75;
                    // Nudge foraging ant toward the direction the returning ant came from
                    const returnOriginAngle = wrapAngle(this.angle[other] + Math.PI);
                    const diff = wrapAngle(returnOriginAngle - ang);
                    steeringTorque += diff * 3.2;
                  }
                }
              }
              other = this.hashNext[other];
            }
          }
        }
      } else {
        // RETURNING WITH FOOD: Blend Path Integration (dead reckoning) + HomeGuide pheromone
        const hL = losL ? grid.sampleFieldAtWorld(grid.homeGuide, tipLX, tipLY) : 0;
        const hC = losC ? grid.sampleFieldAtWorld(grid.homeGuide, tipCX, tipCY) : 0;
        const hR = losR ? grid.sampleFieldAtWorld(grid.homeGuide, tipRX, tipRY) : 0;

        const sHL = weberFechnerLaw(hL);
        const sHC = weberFechnerLaw(hC);
        const sHR = weberFechnerLaw(hR);

        const homeSignalStrength = sHL + sHC + sHR;
        const chemTorque =
          (alphaSensitivity * (sHR - sHL)) / (1.0 + 0.22 * sHC);

        // Path integration homeward vector angle
        const piAngle = Math.atan2(this.homeDy[i], this.homeDx[i]);
        const piDiff = wrapAngle(piAngle - ang);

        // If line ahead is blocked by a wall, rely less on straight dead-reckoning and more on chemical gradient / exploration
        const centerBlocked = !losC;
        const chemWeight = Math.min(0.78, homeSignalStrength * 0.18 + (centerBlocked ? 0.45 : 0));
        const piWeight = centerBlocked ? 0.35 : 1.0 - chemWeight * 0.65;

        steeringTorque =
          piDiff * 3.6 * piWeight +
          chemTorque * 4.2 * (0.4 + chemWeight) +
          ou * (centerBlocked ? 2.8 : 1.15);

        targetSpeed = 94;
      }

      // 3. Proactive Whisker Obstacle Avoidance
      if (!losL || !losR || !losC) {
        if (!losL && losR) {
          steeringTorque += 9.5;
        } else if (!losR && losL) {
          steeringTorque -= 9.5;
        } else if (!losC) {
          steeringTorque += (i % 2 === 0 ? 1 : -1) * 11.5;
        }
      }

      // Apply angular update
      ang = wrapAngle(ang + steeringTorque * dt);
      const spd = this.speed[i] + (targetSpeed - this.speed[i]) * Math.min(1, dt * 8);
      this.speed[i] = spd;

      // 4. Sub-stepped kinematics & smooth tangent wall collision
      const moveDist = spd * dt;
      const subSteps = moveDist > grid.cellSize * 0.75 ? 2 : 1;
      const stepDist = moveDist / subSteps;
      let collided = false;

      for (let s = 0; s < subSteps; s++) {
        const vxStep = Math.cos(ang) * stepDist;
        const vyStep = Math.sin(ang) * stepDist;
        let nx = ax + vxStep;
        let ny = ay + vyStep;

        // World border reflection
        if (nx < margin) {
          nx = margin;
          ang = Math.PI - ang;
          collided = true;
        } else if (nx > wWidth - margin) {
          nx = wWidth - margin;
          ang = Math.PI - ang;
          collided = true;
        }
        if (ny < margin) {
          ny = margin;
          ang = -ang;
          collided = true;
        } else if (ny > wHeight - margin) {
          ny = wHeight - margin;
          ang = -ang;
          collided = true;
        }

        if (!grid.isWallAtWorld(nx, ny)) {
          ax = nx;
          ay = ny;
        } else {
          collided = true;
          // Try smooth tangent sliding along X or Y axis
          if (!grid.isWallAtWorld(ax + vxStep, ay)) {
            ax += vxStep * 0.85;
            ang = wrapAngle(ang + (vxStep >= 0 ? 0 - ang : Math.PI - ang) * 0.35);
          } else if (!grid.isWallAtWorld(ax, ay + vyStep)) {
            ay += vyStep * 0.85;
            ang = wrapAngle(ang + (vyStep >= 0 ? Math.PI * 0.5 - ang : -Math.PI * 0.5 - ang) * 0.35);
          } else {
            // Reflect heading with slight stochastic jitter
            ang = wrapAngle(ang + Math.PI * 0.65 + this.prng.range(-0.45, 0.45));
          }
        }
      }

      // Stuck-agent recovery
      if (collided) {
        this.stuckTimer[i] += dt;
        if (this.stuckTimer[i] > 0.35) {
          ang = wrapAngle(ang + this.prng.range(-2.2, 2.2));
          this.stuckTimer[i] = 0;
        }
      } else {
        this.stuckTimer[i] = Math.max(0, this.stuckTimer[i] - dt * 2);
      }

      // 5. Update noisy Path Integration accumulator (homeDx, homeDy)
      const movedX = ax - this.x[i];
      const movedY = ay - this.y[i];
      const piDrift = 0.015;
      this.homeDx[i] -= movedX + this.prng.gaussian() * piDrift;
      this.homeDy[i] -= movedY + this.prng.gaussian() * piDrift;
      // Gentle true-nest anchor relaxation (simulating skyline/geomagnetic compass correction)
      this.homeDx[i] += (nestX - ax - this.homeDx[i]) * 0.18 * dt;
      this.homeDy[i] += (nestY - ay - this.homeDy[i]) * 0.18 * dt;

      this.x[i] = ax;
      this.y[i] = ay;
      this.angle[i] = wrapAngle(ang);
      this.vx[i] = Math.cos(this.angle[i]) * spd;
      this.vy[i] = Math.sin(this.angle[i]) * spd;

      // Advance distance-driven leg animation phase (0..8)
      const actualDist = Math.hypot(movedX, movedY);
      this.legPhase[i] = (this.legPhase[i] + actualDist * 0.36) % 8.0;

      // 6. Saturating Age-Attenuated Pheromone Deposition
      this.pheromoneTimer[i] += dt;
      if (this.pheromoneTimer[i] >= 0.075) {
        this.pheromoneTimer[i] = 0;
        const tVisit = this.timeSinceLastVisit[i];

        if (hasFood) {
          const localC = grid.sampleFieldAtWorld(grid.foodTrail, ax, ay);
          const dep = computeSaturatingDeposit(
            baseDepositStrength * 1.25,
            depositDecayRate,
            tVisit,
            localC
          );
          if (dep > 0.02) {
            grid.depositAtWorld(grid.foodTrail, ax, ay, dep);
          }
        } else if (st === ANT_STATE_FORAGING) {
          const localH = grid.sampleFieldAtWorld(grid.homeGuide, ax, ay);
          const dep = computeSaturatingDeposit(
            baseDepositStrength * 0.85,
            depositDecayRate,
            tVisit,
            localH
          );
          if (dep > 0.02) {
            grid.depositAtWorld(grid.homeGuide, ax, ay, dep);
          }
        }
      }

      // 7. Check Nest Interaction
      const ndx = nestX - ax;
      const ndy = nestY - ay;
      const distToNestSq = ndx * ndx + ndy * ndy;

      if (distToNestSq <= nestHarvestRadiusSq) {
        // Reset path integration & stamina timer on visiting Nest
        this.homeDx[i] = ndx;
        this.homeDy[i] = ndy;
        this.timeSinceLastVisit[i] = 0;

        if (hasFood) {
          this.carryingFood[i] = 0;
          this.state[i] = ANT_STATE_FORAGING;
          this.angle[i] = wrapAngle(this.angle[i] + Math.PI + this.prng.range(-0.3, 0.3));
          this.nest.storedFood += 1;
          this.nest.deliveryPulse = 1.0;

          if (!this.hasDeliveredFoodOnce && this.onFirstFoodDelivered) {
            this.hasDeliveredFoodOnce = true;
            this.onFirstFoodDelivered();
          }

          // Every 3 stored food units spawns 1 new ant at the Nest
          if (this.nest.storedFood % 3 === 0) {
            this.spawnSingleAntAtNest(params.maxPopulation);
          }
        }
      }

      // 8. Check Nutrient Crystal Harvesting (if foraging)
      if (!hasFood && this.foodClusters.length > 0) {
        for (let cIdx = this.foodClusters.length - 1; cIdx >= 0; cIdx--) {
          const cluster = this.foodClusters[cIdx];
          const ratio = Math.max(0.25, cluster.amount / cluster.maxAmount);
          const currentRadius = cluster.baseRadius * Math.sqrt(ratio);
          const cdx = cluster.x - ax;
          const cdy = cluster.y - ay;
          if (cdx * cdx + cdy * cdy <= (currentRadius + 7) * (currentRadius + 7)) {
            cluster.amount -= 1;
            this.carryingFood[i] = 1;
            this.state[i] = ANT_STATE_RETURNING;
            this.timeSinceLastVisit[i] = 0;
            this.angle[i] = wrapAngle(this.angle[i] + Math.PI + this.prng.range(-0.25, 0.25));

            // Burst of emerald micro-sparks on harvest
            this.emitSparks(cluster.x, cluster.y, 4, "#00e676", 0.75);

            if (cluster.amount <= 0) {
              this.emitSparks(cluster.x, cluster.y, 14, "#69f0ae", 1.2);
              this.foodClusters.splice(cIdx, 1);
            }
            break;
          }
        }
      }
    }
  }
}
