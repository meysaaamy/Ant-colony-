import { AntColonyEngine } from "./ant-soa-engine";
import { PheromoneGrid } from "./pheromone-grid";
import {
  ANT_SPRITE_SIZE,
  CRYSTAL_SPRITE_SIZE,
  ProceduralAssetBundle,
} from "./procedural-assets";
import { SeededPRNG } from "./prng-noise";
import {
  ActiveStrokeState,
  ANT_STATE_ALARMED,
  SporeMote,
  ToolMode,
} from "./types";

const TOOL_COLORS: Record<ToolMode, string> = {
  foodTrail: "#ffae00",
  homeGuide: "#00f0ff",
  alarm: "#ff0a43",
  foodCluster: "#00e676",
  wall: "#384d6b",
  eraser: "#cbd5e1",
};

export class SanctuaryRenderer {
  public readonly worldWidth: number;
  public readonly worldHeight: number;
  public readonly assets: ProceduralAssetBundle;

  // Offscreen compositing layers
  private terrainCacheCanvas: HTMLCanvasElement;
  private terrainCacheCtx: CanvasRenderingContext2D | null;
  private soilPattern: CanvasPattern | null = null;
  private basaltPattern: CanvasPattern | null = null;

  private pheromoneCanvas: HTMLCanvasElement;
  private pheromoneCtx: CanvasRenderingContext2D | null;
  private pheromoneImageData: ImageData | null = null;

  private bloomCanvas: HTMLCanvasElement;
  private bloomCtx: CanvasRenderingContext2D | null;

  // Atmospheric drifting spore motes (up to 40)
  private readonly maxSpores = 40;
  private readonly spores: SporeMote[] = [];
  private readonly prng = new SeededPRNG(8080);

  // Rolling 60-frame Adaptive Quality Scaler
  private readonly frameTimes = new Float32Array(60);
  private frameCursor = 0;
  private frameCounter = 0;
  public currentFps = 60;
  public qualityTier: "high" | "adaptive" = "high";

  constructor(
    worldWidth: number,
    worldHeight: number,
    grid: PheromoneGrid,
    assets: ProceduralAssetBundle
  ) {
    this.worldWidth = worldWidth;
    this.worldHeight = worldHeight;
    this.assets = assets;
    this.frameTimes.fill(16.67);

    // 1. Static Terrain Cache Canvas (1:1 with logical world coordinates)
    this.terrainCacheCanvas = document.createElement("canvas");
    this.terrainCacheCanvas.width = worldWidth;
    this.terrainCacheCanvas.height = worldHeight;
    this.terrainCacheCtx = this.terrainCacheCanvas.getContext("2d");

    if (this.terrainCacheCtx) {
      this.soilPattern = this.terrainCacheCtx.createPattern(assets.soilTile, "repeat");
      this.basaltPattern = this.terrainCacheCtx.createPattern(assets.basaltTile, "repeat");
    }

    // 2. Pheromone LUT Offscreen Canvas (grid cols x rows)
    this.pheromoneCanvas = document.createElement("canvas");
    this.pheromoneCanvas.width = grid.cols;
    this.pheromoneCanvas.height = grid.rows;
    this.pheromoneCtx = this.pheromoneCanvas.getContext("2d");
    if (this.pheromoneCtx) {
      this.pheromoneImageData = this.pheromoneCtx.createImageData(grid.cols, grid.rows);
    }

    // 3. 1/4-Res Bloom Offscreen Canvas
    this.bloomCanvas = document.createElement("canvas");
    this.bloomCanvas.width = Math.max(16, Math.floor(grid.cols * 0.25));
    this.bloomCanvas.height = Math.max(16, Math.floor(grid.rows * 0.25));
    this.bloomCtx = this.bloomCanvas.getContext("2d");

    // 4. Initialize 40 drifting spore motes
    const sporeColors = ["#00f0ff", "#ffae00", "#00e676"];
    for (let i = 0; i < this.maxSpores; i++) {
      this.spores.push({
        x: this.prng.range(0, worldWidth),
        y: this.prng.range(0, worldHeight),
        vx: this.prng.range(-6, 6),
        vy: this.prng.range(-8, -2),
        radius: this.prng.range(1.0, 2.2),
        alpha: this.prng.range(0.14, 0.36),
        phase: this.prng.range(0, Math.PI * 2),
        color: sporeColors[i % sporeColors.length],
      });
    }
  }

  public recordFrameDelta(dtMs: number): void {
    const clamped = Math.min(100, Math.max(4, dtMs));
    this.frameTimes[this.frameCursor] = clamped;
    this.frameCursor = (this.frameCursor + 1) % 60;
    this.frameCounter++;

    let sum = 0;
    for (let i = 0; i < 60; i++) {
      sum += this.frameTimes[i];
    }
    const avgMs = sum / 60;
    this.currentFps = Math.min(60, Math.round(1000 / Math.max(1, avgMs)));

    // Hysteresis threshold around 50 FPS
    if (this.currentFps < 50 && this.qualityTier === "high") {
      this.qualityTier = "adaptive";
    } else if (this.currentFps >= 54 && this.qualityTier === "adaptive") {
      this.qualityTier = "high";
    }
  }

  public shouldStepDiffusionThisTick(): boolean {
    if (this.qualityTier === "high") return true;
    return this.frameCounter % 2 === 0;
  }

  /**
   * Updates ONLY the dirty rectangle of the Static Terrain Cache Canvas when walls are painted or erased.
   * Renders deep abyssal substrate (#03050a), faint scientific reticles, baked ambient occlusion halo,
   * and smooth organic basalt/obsidian silhouettes (#101622) with crisp rim-lighting (#26354d) and beveled inner contours.
   */
  public updateDirtyTerrainCache(grid: PheromoneGrid): void {
    const dr = grid.dirtyRect;
    if (!dr.dirty || !this.terrainCacheCtx) return;

    const ctx = this.terrainCacheCtx;
    const cellSize = grid.cellSize;

    const minCellX = Math.max(0, dr.minCellX);
    const minCellY = Math.max(0, dr.minCellY);
    const maxCellX = Math.min(grid.cols - 1, dr.maxCellX);
    const maxCellY = Math.min(grid.rows - 1, dr.maxCellY);

    const px0 = minCellX * cellSize;
    const py0 = minCellY * cellSize;
    const pw = (maxCellX - minCellX + 1) * cellSize;
    const ph = (maxCellY - minCellY + 1) * cellSize;

    ctx.save();
    ctx.beginPath();
    ctx.rect(px0, py0, pw, ph);
    ctx.clip();

    // 1. Deep Abyssal Substrate (#03050a) + Macro mineral plate
    ctx.fillStyle = "#03050a";
    ctx.fillRect(px0, py0, pw, ph);

    if (this.soilPattern) {
      ctx.fillStyle = this.soilPattern;
      ctx.fillRect(px0, py0, pw, ph);
    }

    ctx.globalAlpha = 0.45;
    ctx.drawImage(
      this.assets.macroPlate,
      0,
      0,
      this.assets.macroPlate.width,
      this.assets.macroPlate.height,
      0,
      0,
      this.worldWidth,
      this.worldHeight
    );
    ctx.globalAlpha = 1.0;

    // 2. Faint scientific coordinate reticles & edge tick marks
    ctx.strokeStyle = "rgba(38, 53, 77, 0.22)";
    ctx.lineWidth = 1;
    const gridSpacing = 120;

    const startGridX = Math.floor(px0 / gridSpacing) * gridSpacing;
    const endGridX = px0 + pw;
    const startGridY = Math.floor(py0 / gridSpacing) * gridSpacing;
    const endGridY = py0 + ph;

    for (let gx = startGridX; gx <= endGridX; gx += gridSpacing) {
      for (let gy = startGridY; gy <= endGridY; gy += gridSpacing) {
        // Crosshair reticle
        ctx.beginPath();
        ctx.moveTo(gx - 5, gy);
        ctx.lineTo(gx + 5, gy);
        ctx.moveTo(gx, gy - 5);
        ctx.lineTo(gx, gy + 5);
        ctx.stroke();
      }
    }

    // Edge tick marks if dirty rect touches border
    if (px0 <= 12 || py0 <= 12 || px0 + pw >= this.worldWidth - 12 || py0 + ph >= this.worldHeight - 12) {
      ctx.strokeStyle = "rgba(56, 77, 107, 0.38)";
      for (let tx = 0; tx < this.worldWidth; tx += 40) {
        ctx.beginPath();
        ctx.moveTo(tx, 0);
        ctx.lineTo(tx, tx % 120 === 0 ? 8 : 4);
        ctx.moveTo(tx, this.worldHeight);
        ctx.lineTo(tx, this.worldHeight - (tx % 120 === 0 ? 8 : 4));
        ctx.stroke();
      }
      for (let ty = 0; ty < this.worldHeight; ty += 40) {
        ctx.beginPath();
        ctx.moveTo(0, ty);
        ctx.lineTo(ty % 120 === 0 ? 8 : 4, ty);
        ctx.moveTo(this.worldWidth, ty);
        ctx.lineTo(this.worldWidth - (ty % 120 === 0 ? 8 : 4), ty);
        ctx.stroke();
      }
    }

    // 3. Baked Ambient Occlusion (AO) Halo + Smooth Organic Basalt Walls
    const smoothed = grid.smoothedWall;
    const cols = grid.cols;

    // Pass A: Ambient Occlusion Halo where substrate meets wall (smoothed in [0.12, 0.48])
    ctx.fillStyle = "rgba(1, 2, 5, 0.68)";
    for (let cy = minCellY; cy <= maxCellY; cy++) {
      const wy = (cy + 0.5) * cellSize;
      for (let cx = minCellX; cx <= maxCellX; cx++) {
        const s = smoothed[cy * cols + cx];
        if (s > 0.1 && s < 0.52) {
          const wx = (cx + 0.5) * cellSize;
          ctx.beginPath();
          ctx.arc(wx, wy, cellSize * 1.15, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // Pass B: Outer Rim-Lighting Silhouette (#26354d)
    ctx.fillStyle = "#26354d";
    for (let cy = minCellY; cy <= maxCellY; cy++) {
      const wy = (cy + 0.5) * cellSize;
      for (let cx = minCellX; cx <= maxCellX; cx++) {
        const s = smoothed[cy * cols + cx];
        if (s >= 0.36) {
          const wx = (cx + 0.5) * cellSize;
          ctx.beginPath();
          ctx.arc(wx, wy, cellSize * 0.86, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // Pass C: Basalt-Obsidian Core Fill (#101622 pattern)
    ctx.fillStyle = this.basaltPattern || "#101622";
    for (let cy = minCellY; cy <= maxCellY; cy++) {
      const wy = (cy + 0.5) * cellSize;
      for (let cx = minCellX; cx <= maxCellX; cx++) {
        const s = smoothed[cy * cols + cx];
        if (s >= 0.44) {
          const wx = (cx + 0.5) * cellSize;
          ctx.beginPath();
          ctx.arc(wx, wy, cellSize * 0.76, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // Pass D: Beveled Inner Contour Ridge (smoothed >= 0.78)
    ctx.fillStyle = "rgba(38, 53, 77, 0.32)";
    for (let cy = minCellY; cy <= maxCellY; cy++) {
      const wy = (cy + 0.5) * cellSize;
      for (let cx = minCellX; cx <= maxCellX; cx++) {
        const s = smoothed[cy * cols + cx];
        if (s >= 0.76 && s < 0.92) {
          const wx = (cx + 0.5) * cellSize;
          ctx.beginPath();
          ctx.arc(wx - 0.8, wy - 0.8, cellSize * 0.42, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    ctx.restore();
    dr.dirty = false;
  }

  /**
   * Executes the strict 9-stage zero-blur compositing pipeline onto the display canvas.
   */
  public renderFrame(
    displayCtx: CanvasRenderingContext2D,
    displayWidth: number,
    displayHeight: number,
    grid: PheromoneGrid,
    colony: AntColonyEngine,
    stroke: ActiveStrokeState,
    ghostStrokeProgress: number | null,
    dt: number
  ): void {
    // Update dirty rect on static terrain cache if needed
    if (grid.dirtyRect.dirty) {
      this.updateDirtyTerrainCache(grid);
    }

    // Update pheromone LUT ImageData
    if (this.pheromoneCtx && this.pheromoneImageData) {
      grid.renderToImageData(this.pheromoneImageData);
      this.pheromoneCtx.putImageData(this.pheromoneImageData, 0, 0);

      // Refresh 1/4-res bloom canvas every other frame in high quality tier
      if (this.qualityTier === "high" && this.bloomCtx && this.frameCounter % 2 === 0) {
        this.bloomCtx.clearRect(0, 0, this.bloomCanvas.width, this.bloomCanvas.height);
        this.bloomCtx.imageSmoothingEnabled = true;
        this.bloomCtx.drawImage(
          this.pheromoneCanvas,
          0,
          0,
          this.bloomCanvas.width,
          this.bloomCanvas.height
        );
      }
    }

    // Camera-to-screen transform (preserving logical world coordinate space)
    const scaleX = displayWidth / this.worldWidth;
    const scaleY = displayHeight / this.worldHeight;

    displayCtx.save();
    displayCtx.scale(scaleX, scaleY);

    // =========================================================================
    // LAYER 1: Static Terrain Cache Canvas
    // =========================================================================
    displayCtx.globalCompositeOperation = "source-over";
    displayCtx.globalAlpha = 1.0;
    displayCtx.drawImage(this.terrainCacheCanvas, 0, 0, this.worldWidth, this.worldHeight);

    // =========================================================================
    // LAYER 2: Pheromone LUT Offscreen Canvas (Screen-blended, bilinear smooth)
    // =========================================================================
    displayCtx.globalCompositeOperation = "screen";
    displayCtx.imageSmoothingEnabled = true;
    displayCtx.imageSmoothingQuality = "high";
    displayCtx.drawImage(this.pheromoneCanvas, 0, 0, this.worldWidth, this.worldHeight);

    // =========================================================================
    // LAYER 3: 1/4-Res Bloom Layer (Lighter-blended, shed first under load)
    // =========================================================================
    if (this.qualityTier === "high") {
      displayCtx.globalCompositeOperation = "lighter";
      displayCtx.globalAlpha = 0.38;
      displayCtx.drawImage(this.bloomCanvas, 0, 0, this.worldWidth, this.worldHeight);
      displayCtx.globalAlpha = 1.0;
    }

    // =========================================================================
    // LAYER 4: Bioluminescent Emerald Nutrient Crystals (Food)
    // =========================================================================
    displayCtx.globalCompositeOperation = "source-over";
    for (let i = 0; i < colony.foodClusters.length; i++) {
      const c = colony.foodClusters[i];
      const ratio = Math.max(0.22, c.amount / c.maxAmount);
      const scale = Math.sqrt(ratio);
      const breathe = 1.0 + Math.sin(c.pulsePhase) * 0.08;
      const drawSize = c.baseRadius * 2.5 * scale;

      // Radial breathing glow sprite
      displayCtx.globalCompositeOperation = "lighter";
      displayCtx.globalAlpha = 0.55 + Math.sin(c.pulsePhase) * 0.15;
      const glowRadius = drawSize * 1.45 * breathe;
      displayCtx.drawImage(
        this.assets.crystalGlowSprite,
        c.x - glowRadius * 0.5,
        c.y - glowRadius * 0.5,
        glowRadius,
        glowRadius
      );

      // Pre-rendered faceted crystal cluster sprite
      displayCtx.globalCompositeOperation = "source-over";
      displayCtx.globalAlpha = 1.0;
      const sprite = this.assets.crystalVariants[c.variant % this.assets.crystalVariants.length];
      displayCtx.drawImage(
        sprite,
        0,
        0,
        CRYSTAL_SPRITE_SIZE,
        CRYSTAL_SPRITE_SIZE,
        c.x - drawSize * 0.5,
        c.y - drawSize * 0.5,
        drawSize,
        drawSize
      );

      // Occasional specular glint
      if (c.glintTimer < 0 && c.glintTimer > -0.35) {
        const glintProgress = (c.glintTimer + 0.35) / 0.35;
        const glintAlpha = Math.sin(glintProgress * Math.PI);
        displayCtx.strokeStyle = `rgba(255, 255, 255, ${glintAlpha.toFixed(2)})`;
        displayCtx.lineWidth = 1.5;
        const gx = c.x + drawSize * 0.15;
        const gy = c.y - drawSize * 0.15;
        const gLen = 6 * scale;
        displayCtx.beginPath();
        displayCtx.moveTo(gx - gLen, gy);
        displayCtx.lineTo(gx + gLen, gy);
        displayCtx.moveTo(gx, gy - gLen);
        displayCtx.lineTo(gx, gy + gLen);
        displayCtx.stroke();
      }
    }

    // =========================================================================
    // LAYER 5: The Nest (Crater, Concentric Rings, Heartbeat, Delivery Pulse, Spawn Arc)
    // =========================================================================
    const nest = colony.nest;
    const heartbeat = 1.0 + Math.sin(nest.heartbeatPhase) * 0.045;

    // Soft ambient glow beneath Nest
    displayCtx.globalCompositeOperation = "lighter";
    displayCtx.globalAlpha = 0.65 + nest.deliveryPulse * 0.35;
    const nestGlowDiam = nest.radius * 4.2 * heartbeat;
    displayCtx.drawImage(
      this.assets.nestGlowSprite,
      nest.x - nestGlowDiam * 0.5,
      nest.y - nestGlowDiam * 0.5,
      nestGlowDiam,
      nestGlowDiam
    );

    displayCtx.globalCompositeOperation = "source-over";
    displayCtx.globalAlpha = 1.0;

    // Dark abyssal crater core
    displayCtx.fillStyle = "#040710";
    displayCtx.strokeStyle = "#1e293b";
    displayCtx.lineWidth = 2;
    displayCtx.beginPath();
    displayCtx.arc(nest.x, nest.y, nest.radius * 0.95, 0, Math.PI * 2);
    displayCtx.fill();
    displayCtx.stroke();

    // Inner amber ring
    displayCtx.strokeStyle = "#ffae00";
    displayCtx.lineWidth = 1.8;
    displayCtx.beginPath();
    displayCtx.arc(nest.x, nest.y, nest.radius * 0.58 * heartbeat, 0, Math.PI * 2);
    displayCtx.stroke();

    // Outer cyan orientation ring
    displayCtx.strokeStyle = "rgba(0, 240, 255, 0.72)";
    displayCtx.lineWidth = 1.5;
    displayCtx.setLineDash([5, 4]);
    displayCtx.beginPath();
    displayCtx.arc(nest.x, nest.y, nest.radius * 0.92 * heartbeat, 0, Math.PI * 2);
    displayCtx.stroke();
    displayCtx.setLineDash([]);

    // Thin progress arc around Nest filling toward next ant spawn (every 3 stored food units)
    const spawnProgress = (nest.storedFood % 3) / 3;
    const targetProgress = nest.deliveryPulse > 0.2 && nest.storedFood > 0 && nest.storedFood % 3 === 0 ? 1.0 : spawnProgress;
    if (targetProgress > 0) {
      displayCtx.strokeStyle = "#00e676";
      displayCtx.lineWidth = 2.6;
      displayCtx.lineCap = "round";
      displayCtx.beginPath();
      displayCtx.arc(
        nest.x,
        nest.y,
        nest.radius + 5.5,
        -Math.PI * 0.5,
        -Math.PI * 0.5 + targetProgress * Math.PI * 2
      );
      displayCtx.stroke();
    }

    // Delivery ripple expansion
    if (nest.deliveryPulse > 0.01) {
      const p = 1.0 - nest.deliveryPulse;
      displayCtx.strokeStyle = `rgba(255, 174, 0, ${nest.deliveryPulse.toFixed(2)})`;
      displayCtx.lineWidth = 2.2;
      displayCtx.beginPath();
      displayCtx.arc(nest.x, nest.y, nest.radius * (0.7 + p * 0.9), 0, Math.PI * 2);
      displayCtx.stroke();
    }

    // Protective shield pulse if touched by Eraser
    if (nest.eraserProtectPulse > 0.01) {
      displayCtx.strokeStyle = `rgba(0, 240, 255, ${nest.eraserProtectPulse.toFixed(2)})`;
      displayCtx.lineWidth = 3.0;
      displayCtx.beginPath();
      displayCtx.arc(nest.x, nest.y, nest.radius + 9, 0, Math.PI * 2);
      displayCtx.stroke();
    }

    // =========================================================================
    // LAYER 6: Procedural Ant Sprite-Sheet Batch (Up to 3,000 rotated ants)
    // =========================================================================
    const antSheet = this.assets.antSpriteSheet;
    const antCount = colony.activeCount;
    const drawAntSize = 18;
    const halfAnt = drawAntSize * 0.5;

    for (let i = 0; i < antCount; i++) {
      const ax = colony.x[i];
      const ay = colony.y[i];
      const ang = colony.angle[i];
      const frame = (colony.legPhase[i] | 0) & 7;

      let stateRow = 0;
      if (colony.state[i] === ANT_STATE_ALARMED) {
        stateRow = 2;
      } else if (colony.carryingFood[i] === 1) {
        stateRow = 1;
      }

      const sx = frame * ANT_SPRITE_SIZE;
      const sy = stateRow * ANT_SPRITE_SIZE;

      displayCtx.save();
      displayCtx.translate(ax, ay);
      displayCtx.rotate(ang);
      displayCtx.drawImage(
        antSheet,
        sx,
        sy,
        ANT_SPRITE_SIZE,
        ANT_SPRITE_SIZE,
        -halfAnt,
        -halfAnt,
        drawAntSize,
        drawAntSize
      );
      displayCtx.restore();
    }

    // =========================================================================
    // LAYER 7: Atmospheric Drifting Spore Motes
    // =========================================================================
    const activeSpores = this.qualityTier === "high" ? this.maxSpores : 14;
    displayCtx.globalCompositeOperation = "lighter";
    for (let i = 0; i < activeSpores; i++) {
      const m = this.spores[i];
      m.phase += dt * 1.4;
      m.x += (m.vx + Math.sin(m.phase) * 3) * dt;
      m.y += m.vy * dt;

      if (m.x < 0) m.x += this.worldWidth;
      else if (m.x > this.worldWidth) m.x -= this.worldWidth;
      if (m.y < 0) m.y += this.worldHeight;
      else if (m.y > this.worldHeight) m.y -= this.worldHeight;

      const twinkle = m.alpha * (0.65 + 0.35 * Math.sin(m.phase * 2));
      displayCtx.globalAlpha = twinkle;
      displayCtx.fillStyle = m.color;
      displayCtx.beginPath();
      displayCtx.arc(m.x, m.y, m.radius, 0, Math.PI * 2);
      displayCtx.fill();
    }
    displayCtx.globalAlpha = 1.0;

    // =========================================================================
    // LAYER 8: Active Stroke Ribbon, Brush Ring, Sparks & First-Run Ghost Stroke
    // =========================================================================
    // Render active micro-sparks (from crystal harvests & pointer strokes)
    for (let i = 0; i < colony.maxSparks; i++) {
      const s = colony.sparks[i];
      if (!s.active) continue;
      const alpha = Math.max(0, 1.0 - s.life / s.maxLife);
      displayCtx.globalAlpha = alpha;
      displayCtx.fillStyle = s.color;
      displayCtx.beginPath();
      displayCtx.arc(s.x, s.y, s.size * alpha, 0, Math.PI * 2);
      displayCtx.fill();
    }
    displayCtx.globalAlpha = 1.0;

    // First-run onboarding animated ghost stroke
    if (ghostStrokeProgress !== null && colony.foodClusters.length > 0) {
      let nearest = colony.foodClusters[0];
      let minDist = Infinity;
      for (let i = 0; i < colony.foodClusters.length; i++) {
        const c = colony.foodClusters[i];
        const d = Math.hypot(c.x - nest.x, c.y - nest.y);
        if (d < minDist) {
          minDist = d;
          nearest = c;
        }
      }

      const gx = nest.x + (nearest.x - nest.x) * ghostStrokeProgress;
      const gy = nest.y + (nearest.y - nest.y) * ghostStrokeProgress;

      displayCtx.save();
      displayCtx.globalCompositeOperation = "lighter";
      displayCtx.strokeStyle = "rgba(255, 174, 0, 0.38)";
      displayCtx.lineWidth = 10;
      displayCtx.lineCap = "round";
      displayCtx.setLineDash([10, 10]);
      displayCtx.beginPath();
      displayCtx.moveTo(nest.x, nest.y);
      displayCtx.lineTo(gx, gy);
      displayCtx.stroke();
      displayCtx.setLineDash([]);

      displayCtx.fillStyle = "#fff3b0";
      displayCtx.beginPath();
      displayCtx.arc(gx, gy, 7, 0, Math.PI * 2);
      displayCtx.fill();

      displayCtx.strokeStyle = "#ffae00";
      displayCtx.lineWidth = 2;
      displayCtx.beginPath();
      displayCtx.arc(gx, gy, 15, 0, Math.PI * 2);
      displayCtx.stroke();
      displayCtx.restore();
    }

    // Active pointer stroke ribbon & brush ring
    if (stroke.ribbonCount > 1) {
      const toolColor = TOOL_COLORS[stroke.tool];
      displayCtx.save();
      displayCtx.globalCompositeOperation = "lighter";
      displayCtx.lineCap = "round";
      displayCtx.lineJoin = "round";

      for (let i = 1; i < stroke.ribbonCount; i++) {
        const p0 = stroke.ribbon[i - 1];
        const p1 = stroke.ribbon[i];
        const taper = i / stroke.ribbonCount;
        const alpha = Math.max(0, (1.0 - p1.age * 3.2) * taper * 0.55);
        if (alpha <= 0.01) continue;

        displayCtx.strokeStyle = toolColor;
        displayCtx.globalAlpha = alpha;
        displayCtx.lineWidth = Math.max(2, p1.radius * 0.55 * taper);
        displayCtx.beginPath();
        displayCtx.moveTo(p0.x, p0.y);
        displayCtx.lineTo(p1.x, p1.y);
        displayCtx.stroke();
      }
      displayCtx.restore();
    }

    if (stroke.startRipple > 0.01) {
      const toolColor = TOOL_COLORS[stroke.tool];
      const rp = 1.0 - stroke.startRipple;
      displayCtx.save();
      displayCtx.strokeStyle = toolColor;
      displayCtx.globalAlpha = stroke.startRipple * 0.75;
      displayCtx.lineWidth = 2;
      displayCtx.beginPath();
      displayCtx.arc(stroke.startX, stroke.startY, 10 + rp * 32, 0, Math.PI * 2);
      displayCtx.stroke();
      displayCtx.restore();
    }

    if (stroke.active) {
      const toolColor = TOOL_COLORS[stroke.tool];
      const r = stroke.ribbonCount > 0 ? stroke.ribbon[stroke.ribbonCount - 1].radius : 28;
      displayCtx.save();
      displayCtx.strokeStyle = toolColor;
      displayCtx.lineWidth = 2;
      if (stroke.tool === "eraser") {
        // Dashed brush ring with dissolve shimmer for eraser
        displayCtx.setLineDash([6, 4]);
        displayCtx.lineDashOffset = -this.frameCounter * 0.8;
      }
      displayCtx.beginPath();
      displayCtx.arc(stroke.worldX, stroke.worldY, r, 0, Math.PI * 2);
      displayCtx.stroke();
      displayCtx.setLineDash([]);
      displayCtx.restore();
    }

    // =========================================================================
    // LAYER 9: Cached Vignette-and-Grain Atmosphere Overlay
    // =========================================================================
    displayCtx.globalCompositeOperation = "source-over";
    displayCtx.globalAlpha = 0.82;
    displayCtx.drawImage(
      this.assets.vignetteGrainCanvas,
      0,
      0,
      this.worldWidth,
      this.worldHeight
    );
    displayCtx.globalAlpha = 1.0;

    displayCtx.restore();
  }
}
