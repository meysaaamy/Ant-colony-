/**
 * Zero-allocation deterministic PRNG (Mulberry32 & XorShift32)
 * and 2D Value/Simplex-like FBM noise for procedural textures, caves, and agent Ornstein-Uhlenbeck wander.
 */

export class SeededPRNG {
  private state: number;

  constructor(seed = 0x5f3759df) {
    this.state = seed >>> 0 || 1;
  }

  public reseed(seed: number): void {
    this.state = seed >>> 0 || 1;
  }

  /** Returns float in [0, 1) using Mulberry32 */
  public next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /** Returns float in [min, max) */
  public range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  /** Returns approximate standard normal N(0, 1) using Box-Muller free fast sum */
  public gaussian(): number {
    return (this.next() + this.next() + this.next() - 1.5) * 1.632993161855452;
  }
}

/** Fast integer hash for 2D coordinates */
function hash2D(ix: number, iy: number, seed: number): number {
  let h = Math.imul(ix, 374761393) + Math.imul(iy, 668265263) + Math.imul(seed, 1442695041);
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function smoothstep(t: number): number {
  return t * t * (3 - 2 * t);
}

/** 2D smooth value noise in [0, 1] */
export function valueNoise2D(x: number, y: number, seed = 101): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;

  const u = smoothstep(fx);
  const v = smoothstep(fy);

  const n00 = hash2D(ix, iy, seed);
  const n10 = hash2D(ix + 1, iy, seed);
  const n01 = hash2D(ix, iy + 1, seed);
  const n11 = hash2D(ix + 1, iy + 1, seed);

  const nx0 = n00 + u * (n10 - n00);
  const nx1 = n01 + u * (n11 - n01);
  return nx0 + v * (nx1 - nx0);
}

/** Seamless tileable 2D value noise for period [periodX, periodY] in [0, 1] */
export function tileableNoise2D(
  x: number,
  y: number,
  periodX: number,
  periodY: number,
  seed = 101
): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;

  const u = smoothstep(fx);
  const v = smoothstep(fy);

  const px0 = ((ix % periodX) + periodX) % periodX;
  const px1 = (px0 + 1) % periodX;
  const py0 = ((iy % periodY) + periodY) % periodY;
  const py1 = (py0 + 1) % periodY;

  const n00 = hash2D(px0, py0, seed);
  const n10 = hash2D(px1, py0, seed);
  const n01 = hash2D(px0, py1, seed);
  const n11 = hash2D(px1, py1, seed);

  const nx0 = n00 + u * (n10 - n00);
  const nx1 = n01 + u * (n11 - n01);
  return nx0 + v * (nx1 - nx0);
}

/** Fractional Brownian Motion (FBM) 2D noise in [0, 1] */
export function fbm2D(
  x: number,
  y: number,
  octaves = 4,
  lacunarity = 2.0,
  gain = 0.5,
  seed = 42
): number {
  let total = 0;
  let frequency = 1;
  let amplitude = 1;
  let maxValue = 0;

  for (let i = 0; i < octaves; i++) {
    total += valueNoise2D(x * frequency, y * frequency, seed + i * 31) * amplitude;
    maxValue += amplitude;
    amplitude *= gain;
    frequency *= lacunarity;
  }

  return total / maxValue;
}
