import { AntColonyEngine } from "./ant-soa-engine";
import { PheromoneGrid } from "./pheromone-grid";
import { fbm2D } from "./prng-noise";
import { PresetDefinition, PresetId } from "./types";

export const PRESET_DEFINITIONS: PresetDefinition[] = [
  {
    id: "open-sanctuary",
    name: "Open Sanctuary",
    subtitle: "Free-form radial foraging & trail painting",
    description: "Central-left Nest with 3 emerald crystal groves across an unobstructed abyssal floor.",
    initialAnts: 280,
  },
  {
    id: "double-bridge",
    name: "Deneubourg's Double Bridge",
    subtitle: "1989 shortest-path autocatalysis experiment",
    description: "Asymmetric 1x vs 2x diamond bridge branches isolating positive feedback convergence.",
    initialAnts: 340,
  },
  {
    id: "subterranean-labyrinth",
    name: "Subterranean Labyrinth",
    subtitle: "Multi-chambered basalt cave exploration",
    description: "Organic cave network with choke points, dead-ends, and 2 deep nutrient vaults.",
    initialAnts: 360,
  },
];

function carveLineCorridor(
  grid: PheromoneGrid,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  radiusWorld: number
): void {
  const dist = Math.hypot(x1 - x0, y1 - y0);
  const steps = Math.max(1, Math.ceil(dist / (grid.cellSize * 0.6)));
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const px = x0 + (x1 - x0) * t;
    const py = y0 + (y1 - y0) * t;
    carveCircle(grid, px, py, radiusWorld, 0);
  }
}

function carveCircle(
  grid: PheromoneGrid,
  worldX: number,
  worldY: number,
  radiusWorld: number,
  val: 0 | 1
): void {
  const cx = Math.floor(worldX / grid.cellSize);
  const cy = Math.floor(worldY / grid.cellSize);
  const rCells = Math.ceil(radiusWorld / grid.cellSize);
  const rSq = radiusWorld * radiusWorld;

  const minX = Math.max(1, cx - rCells);
  const maxX = Math.min(grid.cols - 2, cx + rCells);
  const minY = Math.max(1, cy - rCells);
  const maxY = Math.min(grid.rows - 2, cy + rCells);

  for (let y = minY; y <= maxY; y++) {
    const py = (y + 0.5) * grid.cellSize;
    for (let x = minX; x <= maxX; x++) {
      const px = (x + 0.5) * grid.cellSize;
      const dx = px - worldX;
      const dy = py - worldY;
      if (dx * dx + dy * dy <= rSq) {
        grid.wallMask[y * grid.cols + x] = val;
      }
    }
  }
}

/**
 * Deterministically builds the selected preset world onto PheromoneGrid and AntColonyEngine.
 */
export function applyPresetWorld(
  presetId: PresetId,
  grid: PheromoneGrid,
  colony: AntColonyEngine,
  maxPopulation: number
): void {
  grid.clearAll();
  colony.foodClusters = [];

  const W = grid.worldWidth;
  const H = grid.worldHeight;
  const isPortrait = H > W;

  if (presetId === "open-sanctuary") {
    const nestX = isPortrait ? W * 0.5 : W * 0.22;
    const nestY = isPortrait ? H * 0.76 : H * 0.52;
    colony.resetColony(nestX, nestY, 280, maxPopulation);

    if (isPortrait) {
      colony.addFoodCluster(W * 0.3, H * 0.42, 220, 27);
      colony.addFoodCluster(W * 0.74, H * 0.34, 260, 29);
      colony.addFoodCluster(W * 0.48, H * 0.17, 320, 32);
    } else {
      colony.addFoodCluster(W * 0.54, H * 0.28, 220, 27);
      colony.addFoodCluster(W * 0.64, H * 0.74, 260, 29);
      colony.addFoodCluster(W * 0.84, H * 0.48, 320, 32);
    }
  } else if (presetId === "double-bridge") {
    // Fill world with basalt rock, then carve Nest chamber, Food chamber, and asymmetric 1x vs 2x diamond branches
    grid.wallMask.fill(1);

    if (isPortrait) {
      const nestX = W * 0.5;
      const nestY = H * 0.82;
      const foodX = W * 0.5;
      const foodY = H * 0.18;

      const forkBottomY = H * 0.68;
      const forkTopY = H * 0.32;

      // 1x Short Branch (Left subtle bend) vs 2x Long Branch (Right wide excursion)
      const shortMidX = W * 0.36;
      const shortMidY = H * 0.5;
      const longMidX = W * 0.84;
      const longMidY = H * 0.5;

      carveCircle(grid, nestX, nestY, 68, 0);
      carveCircle(grid, foodX, foodY, 68, 0);
      carveLineCorridor(grid, nestX, nestY, nestX, forkBottomY, 28);
      carveLineCorridor(grid, foodX, foodY, foodX, forkTopY, 28);

      // Short 1x branch
      carveLineCorridor(grid, nestX, forkBottomY, shortMidX, shortMidY, 26);
      carveLineCorridor(grid, shortMidX, shortMidY, foodX, forkTopY, 26);

      // Long 2x branch
      carveLineCorridor(grid, nestX, forkBottomY, longMidX, longMidY, 26);
      carveLineCorridor(grid, longMidX, longMidY, foodX, forkTopY, 26);

      colony.resetColony(nestX, nestY, 340, maxPopulation);
      colony.addFoodCluster(foodX, foodY, 420, 32);
    } else {
      const nestX = W * 0.16;
      const nestY = H * 0.5;
      const foodX = W * 0.84;
      const foodY = H * 0.5;

      const forkLeftX = W * 0.3;
      const forkRightX = W * 0.7;

      // 1x Short Upper Branch vs 2x Long Lower Branch
      const shortMidX = W * 0.5;
      const shortMidY = H * 0.37;
      const longMidX = W * 0.5;
      const longMidY = H * 0.84;

      carveCircle(grid, nestX, nestY, 72, 0);
      carveCircle(grid, foodX, foodY, 72, 0);
      carveLineCorridor(grid, nestX, nestY, forkLeftX, nestY, 28);
      carveLineCorridor(grid, foodX, foodY, forkRightX, foodY, 28);

      // Short 1x branch
      carveLineCorridor(grid, forkLeftX, nestY, shortMidX, shortMidY, 26);
      carveLineCorridor(grid, shortMidX, shortMidY, forkRightX, foodY, 26);

      // Long 2x branch
      carveLineCorridor(grid, forkLeftX, nestY, longMidX, longMidY, 26);
      carveLineCorridor(grid, longMidX, longMidY, forkRightX, foodY, 26);

      colony.resetColony(nestX, nestY, 340, maxPopulation);
      colony.addFoodCluster(foodX, foodY, 420, 32);
    }
  } else if (presetId === "subterranean-labyrinth") {
    // Organic FBM cave system with guaranteed navigable chambers and dead-ends
    for (let y = 0; y < grid.rows; y++) {
      for (let x = 0; x < grid.cols; x++) {
        const nx = (x / grid.cols) * 5.2;
        const ny = (y / grid.rows) * 5.2;
        const n = fbm2D(nx, ny, 4, 2.0, 0.5, 404);
        const borderDist = Math.min(
          x / grid.cols,
          1 - x / grid.cols,
          y / grid.rows,
          1 - y / grid.rows
        );
        if (borderDist < 0.04 || n > 0.53) {
          grid.wallMask[y * grid.cols + x] = 1;
        } else {
          grid.wallMask[y * grid.cols + x] = 0;
        }
      }
    }

    const nestX = isPortrait ? W * 0.5 : W * 0.18;
    const nestY = isPortrait ? H * 0.82 : H * 0.52;
    const vault1X = isPortrait ? W * 0.24 : W * 0.78;
    const vault1Y = isPortrait ? H * 0.22 : H * 0.24;
    const vault2X = isPortrait ? W * 0.78 : W * 0.82;
    const vault2Y = isPortrait ? H * 0.28 : H * 0.78;

    const hub1X = W * 0.42;
    const hub1Y = H * 0.36;
    const hub2X = W * 0.58;
    const hub2Y = H * 0.66;

    // Carve chambers & organic winding tunnels + dead ends
    carveCircle(grid, nestX, nestY, 68, 0);
    carveCircle(grid, vault1X, vault1Y, 62, 0);
    carveCircle(grid, vault2X, vault2Y, 62, 0);
    carveCircle(grid, hub1X, hub1Y, 46, 0);
    carveCircle(grid, hub2X, hub2Y, 46, 0);

    carveLineCorridor(grid, nestX, nestY, hub1X, hub1Y, 25);
    carveLineCorridor(grid, nestX, nestY, hub2X, hub2Y, 25);
    carveLineCorridor(grid, hub1X, hub1Y, vault1X, vault1Y, 24);
    carveLineCorridor(grid, hub2X, hub2Y, vault2X, vault2Y, 24);
    carveLineCorridor(grid, hub1X, hub1Y, hub2X, hub2Y, 22);

    // Dead-end alcoves
    carveLineCorridor(grid, hub1X, hub1Y, W * 0.2, H * 0.5, 22);
    carveCircle(grid, W * 0.2, H * 0.5, 34, 0);
    carveLineCorridor(grid, hub2X, hub2Y, W * 0.48, H * 0.85, 22);
    carveCircle(grid, W * 0.48, H * 0.85, 32, 0);

    colony.resetColony(nestX, nestY, 360, maxPopulation);
    colony.addFoodCluster(vault1X, vault1Y, 340, 30);
    colony.addFoodCluster(vault2X, vault2Y, 340, 30);
  }

  grid.updateSmoothedWallRegion(0, 0, grid.cols - 1, grid.rows - 1);
  grid.markFullTerrainDirty();
}

/**
 * Renders a live miniature schematic preview of each preset onto a small HTMLCanvasElement
 * for the ParameterSheet World tab cards.
 */
export function renderPresetPreviewCanvas(
  canvas: HTMLCanvasElement,
  presetId: PresetId
): void {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const w = canvas.width;
  const h = canvas.height;

  ctx.fillStyle = "#03050a";
  ctx.fillRect(0, 0, w, h);

  // Subtle coordinate grid lines
  ctx.strokeStyle = "rgba(38, 53, 77, 0.35)";
  ctx.lineWidth = 1;
  for (let x = 20; x < w; x += 24) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 16; y < h; y += 24) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  if (presetId === "open-sanctuary") {
    // Glowing amber trails radiating from left nest to 3 emerald clusters
    ctx.strokeStyle = "rgba(255, 174, 0, 0.65)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(28, h * 0.52);
    ctx.quadraticCurveTo(w * 0.4, h * 0.3, w * 0.56, h * 0.26);
    ctx.moveTo(28, h * 0.52);
    ctx.quadraticCurveTo(w * 0.45, h * 0.72, w * 0.66, h * 0.76);
    ctx.moveTo(28, h * 0.52);
    ctx.quadraticCurveTo(w * 0.55, h * 0.5, w * 0.84, h * 0.48);
    ctx.stroke();

    drawMiniNest(ctx, 28, h * 0.52);
    drawMiniCrystal(ctx, w * 0.56, h * 0.26);
    drawMiniCrystal(ctx, w * 0.66, h * 0.76);
    drawMiniCrystal(ctx, w * 0.84, h * 0.48);
  } else if (presetId === "double-bridge") {
    // Basalt barrier with diamond cut-out
    ctx.fillStyle = "#101622";
    ctx.strokeStyle = "#384d6b";
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(w * 0.34, h * 0.5);
    ctx.lineTo(w * 0.5, h * 0.34);
    ctx.lineTo(w * 0.66, h * 0.5);
    ctx.lineTo(w * 0.5, h * 0.76);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Short winner branch (bright amber)
    ctx.strokeStyle = "#ffae00";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(24, h * 0.5);
    ctx.lineTo(w * 0.3, h * 0.5);
    ctx.lineTo(w * 0.5, h * 0.22);
    ctx.lineTo(w * 0.7, h * 0.5);
    ctx.lineTo(w - 24, h * 0.5);
    ctx.stroke();

    // Long loser branch (faint cyan)
    ctx.strokeStyle = "rgba(0, 240, 255, 0.45)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(w * 0.3, h * 0.5);
    ctx.lineTo(w * 0.5, h * 0.88);
    ctx.lineTo(w * 0.7, h * 0.5);
    ctx.stroke();
    ctx.setLineDash([]);

    drawMiniNest(ctx, 24, h * 0.5);
    drawMiniCrystal(ctx, w - 24, h * 0.5);
  } else {
    // Subterranean Labyrinth chambers
    ctx.fillStyle = "#101622";
    ctx.strokeStyle = "#26354d";
    ctx.lineWidth = 1.2;
    const rocks = [
      { x: w * 0.32, y: h * 0.18, r: 12 },
      { x: w * 0.46, y: h * 0.52, r: 14 },
      { x: w * 0.28, y: h * 0.78, r: 13 },
      { x: w * 0.66, y: h * 0.46, r: 11 },
    ];
    for (const rk of rocks) {
      ctx.beginPath();
      ctx.arc(rk.x, rk.y, rk.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    ctx.strokeStyle = "rgba(255, 174, 0, 0.7)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(24, h * 0.52);
    ctx.quadraticCurveTo(w * 0.42, h * 0.32, w * 0.8, h * 0.25);
    ctx.moveTo(24, h * 0.52);
    ctx.quadraticCurveTo(w * 0.55, h * 0.72, w * 0.82, h * 0.76);
    ctx.stroke();

    drawMiniNest(ctx, 24, h * 0.52);
    drawMiniCrystal(ctx, w * 0.8, h * 0.25);
    drawMiniCrystal(ctx, w * 0.82, h * 0.76);
  }
}

function drawMiniNest(ctx: CanvasRenderingContext2D, x: number, y: number): void {
  ctx.strokeStyle = "#00f0ff";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(x, y, 7, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = "#ffae00";
  ctx.beginPath();
  ctx.arc(x, y, 3, 0, Math.PI * 2);
  ctx.fill();
}

function drawMiniCrystal(ctx: CanvasRenderingContext2D, x: number, y: number): void {
  ctx.fillStyle = "rgba(0, 230, 118, 0.3)";
  ctx.strokeStyle = "#00e676";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(x, y - 6);
  ctx.lineTo(x + 6, y);
  ctx.lineTo(x, y + 6);
  ctx.lineTo(x - 6, y);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
}
