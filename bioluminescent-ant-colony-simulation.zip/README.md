# Bioluminescent Macro-Sanctuary

**Emergent Ant-Colony Neuroethology & Scent-Painting Sandbox**

An ultra-high-performance interactive Canvas 2D biological simulation and tactile scent-painting sandbox modeling *Lasius niger* and *Linepithema humile* foraging neuroethology, bilateral antenna tropotaxis, Weber-Fechner logarithmic chemoreception, and Deneubourg's shortest-path autocatalysis.

## Key Scientific & Technical Architecture

- **Structure-of-Arrays (SoA) Agent Engine (`lib/ant-soa-engine.ts`):** Preallocated contiguous `Float32Array` and `Uint8Array` buffers for up to `3,000` autonomous ants with zero garbage-collection allocations inside the `requestAnimationFrame` loop.
- **O(1) 1D Spatial Hash Grid:** Preallocated `Int32Array` `head` and `next` linked lists updated each tick for neighbor separation and foraging-to-returning social antennation transfer.
- **Tri-Channel Pheromone Fields (`lib/pheromone-grid.ts`):** Double-buffered ping-pong `Float32Array` grids (`foodTrail`, `homeGuide`, `alarm`) at `6` logical world units per cell with frame-rate-independent exponential decay (`exp(-dt * lambda)`, `3.5x` faster for alarm) and CFL-stable `3x3` Laplacian diffusion enforcing strict zero-flux Neumann wall boundaries.
- **Multi-Layer Zero-Blur Compositor (`lib/renderer.ts`):**
  1. Dirty-Rect Static Terrain Cache Canvas (`#03050a` seamless substrate + `#101622` organic basalt silhouettes + `#26354d` rim-lighting + ambient occlusion halo).
  2. Pheromone 256-Entry Non-Linear RGB LUT Offscreen Canvas (`'screen'` blend).
  3. 1/4-Resolution Bloom Layer (`'lighter'` blend, dynamically shed by the Adaptive Quality Scaler if FPS drops below 50).
  4. Faceted Bioluminescent Emerald Nutrient Crystals (`#00e676`) with radial breathing glow and harvest micro-sparks.
  5. Living Nest Crater with concentric heartbeat rings, delivery pulse, and 3-unit ant spawn progress arc.
  6. 2x-Resolution Articulated Ant Sprite-Sheet (`8` leg frames x `3` states).
  7. Atmospheric Drifting Spore Motes, Tapered Active Stroke Ribbon, and Cached Vignette/Grain Overlay.
