import React, { useState } from 'react';
import { X, ChevronDown, ChevronUp, BookOpen, ExternalLink } from 'lucide-react';

interface FieldGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FieldGuideModal: React.FC<FieldGuideModalProps> = ({ isOpen, onClose }) => {
  const [openCard, setOpenCard] = useState<number | null>(0);

  if (!isOpen) return null;

  const toggleCard = (index: number) => {
    setOpenCard(openCard === index ? null : index);
  };

  const sections = [
    {
      title: '1. Bilateral Tropotaxis & Weber-Fechner Law',
      nature:
        'Ants (*Lasius niger*, *Linepithema humile*) compare chemical concentrations across two spatially separated antennae to compute steering torque.',
      sandbox:
        'Sensors compute left, center, and right sample points. Sensation S = ln(1 + C) maps physical concentration into neural stimulus.',
      diagram: (
        <svg viewBox="0 0 280 120" className="w-full h-28 my-2 rounded-xl bg-slate-900/80 border border-white/10">
          <circle cx="140" cy="90" r="14" fill="#151f2e" stroke="#334155" strokeWidth="1.5" />
          {/* Head & antennae */}
          <line x1="135" y1="80" x2="90" y2="35" stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />
          <line x1="145" y1="80" x2="190" y2="35" stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />
          <line x1="140" y1="80" x2="140" y2="28" stroke="#38bdf8" strokeWidth="1.5" />
          {/* Sensor tips */}
          <circle cx="90" cy="35" r="7" fill="#ffae00" />
          <text x="75" y="22" fill="#ffae00" fontSize="10" fontFamily="sans-serif">S_left</text>
          <circle cx="140" cy="28" r="7" fill="#38bdf8" />
          <text x="125" y="16" fill="#38bdf8" fontSize="10" fontFamily="sans-serif">S_center</text>
          <circle cx="190" cy="35" r="7" fill="#ffae00" />
          <text x="180" y="22" fill="#ffae00" fontSize="10" fontFamily="sans-serif">S_right</text>
        </svg>
      ),
    },
    {
      title: '2. Pheromone Dynamics & Color Scale (LUTs)',
      nature:
        'Glandular hydrocarbons undergo molecular diffusion and temperature-dependent exponential evaporation into the atmosphere.',
      sandbox:
        'Ping-pong Float32Array grids run 3x3 Laplacian stencils enforcing zero-flux Neumann boundary conditions at basalt walls.',
      diagram: (
        <div className="my-2 p-2 rounded-xl bg-slate-900/80 border border-white/10 space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-amber-400 font-semibold">Food Trail:</span>
            <div className="w-36 h-3 rounded-full bg-gradient-to-r from-[#4d1f00] via-[#ffae00] to-[#fff3b0]" />
            <span className="text-slate-400">Amber (Recruits)</span>
          </div>
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-cyan-400 font-semibold">Home Guide:</span>
            <div className="w-36 h-3 rounded-full bg-gradient-to-r from-[#003366] via-[#00f0ff] to-[#d0ffff]" />
            <span className="text-slate-400">Cyan (Orientation)</span>
          </div>
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-rose-400 font-semibold">Alarm Pulse:</span>
            <div className="w-36 h-3 rounded-full bg-gradient-to-r from-[#590216] via-[#ff0a43] to-[#ff8ca5]" />
            <span className="text-slate-400">Crimson (Repellent)</span>
          </div>
        </div>
      ),
    },
    {
      title: "3. Deneubourg's Double Bridge Experiment",
      nature:
        'In 1990, J.L. Deneubourg showed that identical foragers presented with 1x and 2x bridge branches mathematically converge onto the shorter path via autocatalysis.',
      sandbox:
        'Shorter path turnover is faster, concentrating pheromone deposits sooner and causing self-reinforcing recruitment onto the optimal branch.',
      diagram: (
        <svg viewBox="0 0 280 90" className="w-full h-24 my-2 rounded-xl bg-slate-900/80 border border-white/10">
          {/* Nest */}
          <circle cx="35" cy="45" r="14" fill="#00f0ff" opacity="0.3" />
          <text x="22" y="49" fill="#00f0ff" fontSize="10">Nest</text>
          {/* Food */}
          <circle cx="245" cy="45" r="14" fill="#00e676" opacity="0.3" />
          <text x="232" y="49" fill="#00e676" fontSize="10">Food</text>
          {/* Short bridge */}
          <path d="M50 40 Q 140 18 230 40" stroke="#ffae00" strokeWidth="4" fill="none" />
          <text x="110" y="14" fill="#ffae00" fontSize="9">Short Branch (1x) ★</text>
          {/* Long bridge */}
          <path d="M50 50 Q 140 82 230 50" stroke="#475569" strokeWidth="2" strokeDasharray="4 4" fill="none" />
          <text x="110" y="85" fill="#94a3b8" fontSize="9">Long Branch (2x)</text>
        </svg>
      ),
    },
    {
      title: '4. Path Integration & Colony Metabolism',
      nature:
        'Foraging insects maintain continuous dead reckoning vectors using celestial polarization and step counting (odometer), resetting upon nest re-entry.',
      sandbox:
        'Returning ants combine noisy homeward accumulators with sensed Home Guide pheromones. Storing food expands the colony population dynamically.',
    },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Field Guide & Science"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="glass-modal w-full max-w-xl max-h-[90vh] flex flex-col rounded-2xl overflow-hidden shadow-2xl border border-white/15">
        {/* Header */}
        <div className="px-5 py-4 flex items-center justify-between border-b border-white/10 bg-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center">
              <BookOpen size={18} />
            </div>
            <div>
              <h2 className="font-display text-base font-bold text-slate-100 tracking-wide">
                Field Guide & Science
              </h2>
              <p className="text-[11px] text-slate-400">
                Biological neuroethology vs. sandbox computational models
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition"
            aria-label="Close field guide"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content body */}
        <div className="p-5 overflow-y-auto space-y-3 text-xs leading-relaxed touch-pan-y">
          {sections.map((sec, idx) => {
            const isOpen = openCard === idx;
            return (
              <div
                key={idx}
                className="rounded-xl border border-white/10 bg-white/5 overflow-hidden transition"
              >
                <button
                  onClick={() => toggleCard(idx)}
                  className="w-full px-4 py-3 flex items-center justify-between text-left font-semibold text-slate-200 hover:text-white"
                >
                  <span>{sec.title}</span>
                  {isOpen ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 pt-1 space-y-2 border-t border-white/5 bg-black/30">
                    <div>
                      <span className="font-semibold text-emerald-400 block mb-0.5">In nature:</span>
                      <p className="text-slate-300 text-[11px]">{sec.nature}</p>
                    </div>
                    <div>
                      <span className="font-semibold text-cyan-400 block mb-0.5">In this sandbox:</span>
                      <p className="text-slate-300 text-[11px]">{sec.sandbox}</p>
                    </div>
                    {sec.diagram}
                  </div>
                )}
              </div>
            );
          })}

          {/* Scientific Credits & Asset Sources */}
          <div className="mt-5 p-4 rounded-xl bg-slate-950/70 border border-white/10">
            <h3 className="font-semibold text-slate-200 text-xs mb-2">Scientific & Asset Credits</h3>
            <ul className="text-[11px] text-slate-400 space-y-1">
              <li>
                <strong className="text-slate-300">Model Inspiration:</strong> Deneubourg et al. (1990) Double Bridge Experiment & Camazine et al. (2001) Self-Organization in Biological Systems.
              </li>
              <li>
                <strong className="text-slate-300">Typography:</strong> Cinzel (OFL by Natanael Gama) & Plus Jakarta Sans (OFL by Tokotype).
              </li>
              <li>
                <strong className="text-slate-300">Glyphs:</strong> Lucide Icons (ISC License).
              </li>
              <li>
                <strong className="text-slate-300">AI Integration:</strong> Google GenAI SDK (@google/genai) for Gemini Pro/Nano Banana visual plates & Lyria ambient audio generation.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
