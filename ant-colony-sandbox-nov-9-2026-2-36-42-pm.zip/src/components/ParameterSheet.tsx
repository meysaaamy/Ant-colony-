import React, { useState, useEffect } from 'react';
import {
  ChevronUp,
  ChevronDown,
  RotateCcw,
  Sparkles,
  Layers,
  Bug,
  Wind,
  Compass,
  Cloud,
} from 'lucide-react';
import { SimulationConfig, PresetType } from '../sim/types';

interface ParameterSheetProps {
  isOpen: boolean;
  onToggleOpen: () => void;
  config: SimulationConfig;
  activePreset: PresetType;
  onLoadPreset: (preset: PresetType) => void;
  onClearPheromones: () => void;
  onResetWorld: () => void;
  onUpdateConfig: (newConfig: Partial<SimulationConfig>) => void;
  onResetTabDefaults: (tab: 'colony' | 'pheromones' | 'world') => void;
}

export const ParameterSheet: React.FC<ParameterSheetProps> = ({
  isOpen,
  onToggleOpen,
  config,
  activePreset,
  onLoadPreset,
  onClearPheromones,
  onResetWorld,
  onUpdateConfig,
  onResetTabDefaults,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'colony' | 'pheromones' | 'world'>('presets');
  const [resetArmed, setResetArmed] = useState(false);

  // Armed Reset World timer (3 seconds)
  useEffect(() => {
    if (!resetArmed) return;
    const timer = setTimeout(() => {
      setResetArmed(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, [resetArmed]);

  const handleResetWorldClick = () => {
    if (resetArmed) {
      setResetArmed(false);
      onResetWorld();
    } else {
      setResetArmed(true);
    }
  };

  const presetDescriptions: Record<PresetType, { title: string; desc: string; icon: string }> = {
    sanctuary: {
      title: 'Open Sanctuary',
      desc: 'Central Nest, 3 rich emerald nutrient groves, open space for freeform scent-line art.',
      icon: '🌿',
    },
    double_bridge: {
      title: "Deneubourg's Double Bridge",
      desc: 'Asymmetric 1x vs 2x diamond branches demonstrating emergent shortest-path discovery.',
      icon: '⚖️',
    },
    labyrinth: {
      title: 'Subterranean Labyrinth',
      desc: 'Organic cave chambers, choke points, and 2 deep nutrient vaults in solid basalt.',
      icon: '🕸️',
    },
  };

  return (
    <>
      {/* Backdrop scrim */}
      {isOpen && (
        <div
          onClick={onToggleOpen}
          className="fixed inset-0 z-35 bg-black/50 backdrop-blur-xs transition-opacity duration-200"
        />
      )}

      <div
        className={`fixed bottom-0 left-0 right-0 z-40 transition-transform duration-300 ease-out flex flex-col ${
          isOpen ? 'translate-y-0' : 'translate-y-full pointer-events-none'
        }`}
      >
        {/* Header Strip & Drag Handle */}
        <div className="glass-sheet rounded-t-3xl px-4 py-2.5 flex items-center justify-between border-t border-white/10 select-none shadow-2xl">
          <button
            onClick={onToggleOpen}
            className="flex items-center gap-2 text-xs font-medium text-slate-300 hover:text-white"
            aria-expanded={isOpen}
            aria-label="Collapse parameter sheet"
          >
            <div className="w-8 h-1 rounded-full bg-slate-500 mx-auto" />
            <span className="font-semibold text-slate-200">
              {presetDescriptions[activePreset]?.title ?? 'Simulation Parameters'}
            </span>
            <ChevronDown size={14} />
          </button>

          <div className="flex items-center gap-2">
            {/* Clear Pheromones button */}
            <button
              onClick={onClearPheromones}
              className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 text-[11px] font-medium text-slate-200 transition"
              title="Instant wipe of all chemical scent fields"
            >
              Clear trails
            </button>

            {/* Reset World with two-tap arm protection */}
            <button
              onClick={handleResetWorldClick}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition active:scale-95 flex items-center gap-1 ${
                resetArmed
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'bg-white/10 hover:bg-white/20 text-slate-200'
              }`}
              title="Reload active scenario preset"
            >
              <RotateCcw size={11} />
              <span>{resetArmed ? 'Confirm' : 'Reset world'}</span>
            </button>

            <button
              onClick={onToggleOpen}
              className="px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 active:scale-95 text-[11px] font-semibold text-slate-200 transition ml-1"
            >
              Done
            </button>
          </div>
        </div>

      {/* Sheet Content Body (Scrollable) */}
      <div className="glass-modal max-h-[60vh] sm:max-h-[500px] overflow-y-auto px-4 pb-6 pt-3 text-xs text-slate-300 touch-pan-y safe-bottom">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 pb-3 mb-4 border-b border-white/10">
          {[
            { id: 'presets', label: 'Presets', icon: <Layers size={13} /> },
            { id: 'colony', label: 'Colony', icon: <Bug size={13} /> },
            { id: 'pheromones', label: 'Pheromones', icon: <Wind size={13} /> },
            { id: 'world', label: 'World & Brush', icon: <Compass size={13} /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                  : 'bg-white/5 hover:bg-white/10 text-slate-400'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab 1: Presets */}
        {activeTab === 'presets' && (
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
              {(['sanctuary', 'double_bridge', 'labyrinth'] as PresetType[]).map((p) => {
                const isSelected = activePreset === p;
                const info = presetDescriptions[p];
                return (
                  <button
                    key={p}
                    onClick={() => onLoadPreset(p)}
                    className={`text-left p-3.5 rounded-xl border transition-all duration-200 active:scale-98 ${
                      isSelected
                        ? 'border-amber-400 bg-amber-400/10 shadow-[0_0_20px_-3px_rgba(255,174,0,0.3)]'
                        : 'border-white/10 bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-semibold text-slate-100 font-display text-sm">
                        {info.title}
                      </span>
                      <span className="text-lg">{info.icon}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">{info.desc}</p>
                    {isSelected && (
                      <span className="inline-block mt-2 px-1.5 py-0.5 rounded text-[10px] bg-amber-400/30 text-amber-300 font-mono-num font-semibold">
                        Active Scenario
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: Colony Parameters */}
        {activeTab === 'colony' && (
          <div className="space-y-4">
            {/* Max Colony Population */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Max population (carrying capacity)</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.maxPopulation}</span>
              </div>
              <p className="text-[10px] text-slate-400 mb-1.5">Upper cap for ant births (every 3 food delivered spawns 1 ant).</p>
              <input
                type="range"
                min="100"
                max="3000"
                step="50"
                value={config.maxPopulation}
                onChange={(e) => onUpdateConfig({ maxPopulation: Number(e.target.value) })}
                className="w-full accent-amber-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            {/* Ant Base Speed */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Locomotion speed (orthokinesis)</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.antBaseSpeed.toFixed(1)} px/f</span>
              </div>
              <input
                type="range"
                min="1.5"
                max="4.0"
                step="0.1"
                value={config.antBaseSpeed}
                onChange={(e) => onUpdateConfig({ antBaseSpeed: Number(e.target.value) })}
                className="w-full accent-cyan-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            {/* Antenna Sensing Angle */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Antenna span angle (bilateral offset)</span>
                <span className="font-mono-num text-slate-100 font-semibold">{Math.round((config.antennaAngle * 180) / Math.PI)}°</span>
              </div>
              <input
                type="range"
                min="0.3"
                max="1.1"
                step="0.05"
                value={config.antennaAngle}
                onChange={(e) => onUpdateConfig({ antennaAngle: Number(e.target.value) })}
                className="w-full accent-amber-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            {/* Trail Sensitivity (alpha) */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Trail responsiveness (sensitivity α)</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.trailSensitivity.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.5"
                step="0.05"
                value={config.trailSensitivity}
                onChange={(e) => onUpdateConfig({ trailSensitivity: Number(e.target.value) })}
                className="w-full accent-emerald-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => onResetTabDefaults('colony')}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-white/5"
              >
                Reset tab to defaults
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Pheromones */}
        {activeTab === 'pheromones' && (
          <div className="space-y-4">
            {/* Rendering Mode Toggle: Glow vs Fog */}
            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <div className="flex justify-between items-center mb-1.5">
                <span className="font-semibold text-slate-200">Rendering mode</span>
                <span className="text-[10px] font-mono-num uppercase tracking-wider text-slate-400">
                  {config.pheromoneRenderMode === 'fog' ? 'Fog (Dense)' : 'Glow (Neon)'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mb-2.5 leading-relaxed">
                <strong className="text-amber-300">Glow</strong> offers translucent bioluminescent filaments; <strong className="text-cyan-300">Fog</strong> makes chemical trails heavily opaque at high concentrations.
              </p>
              <div className="grid grid-cols-2 gap-2 p-1 bg-black/40 rounded-xl border border-white/10">
                <button
                  type="button"
                  onClick={() => onUpdateConfig({ pheromoneRenderMode: 'glow' })}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition ${
                    config.pheromoneRenderMode !== 'fog'
                      ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                  aria-pressed={config.pheromoneRenderMode !== 'fog'}
                >
                  <Sparkles size={14} />
                  <span>Glow</span>
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateConfig({ pheromoneRenderMode: 'fog' })}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition ${
                    config.pheromoneRenderMode === 'fog'
                      ? 'bg-cyan-400/20 text-cyan-300 border border-cyan-400/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                  aria-pressed={config.pheromoneRenderMode === 'fog'}
                >
                  <Cloud size={14} />
                  <span>Fog</span>
                </button>
              </div>
            </div>

            {/* Evaporation Rate (lambda) */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Trail fade (evaporation λ)</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.evaporationRate.toFixed(3)}</span>
              </div>
              <p className="text-[10px] text-slate-400 mb-1.5">Exponential decay constant (alarm evaporates 3.5x faster).</p>
              <input
                type="range"
                min="0.005"
                max="0.04"
                step="0.001"
                value={config.evaporationRate}
                onChange={(e) => onUpdateConfig({ evaporationRate: Number(e.target.value) })}
                className="w-full accent-amber-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            {/* Diffusion Coefficient */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Spatial diffusion rate</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.diffusionRate.toFixed(2)}</span>
              </div>
              <p className="text-[10px] text-slate-400 mb-1.5">3x3 stencil chemical spreading with zero-flux wall boundaries.</p>
              <input
                type="range"
                min="0.04"
                max="0.24"
                step="0.01"
                value={config.diffusionRate}
                onChange={(e) => onUpdateConfig({ diffusionRate: Number(e.target.value) })}
                className="w-full accent-cyan-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            {/* Alarm Evaporation Multiplier */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Alarm volatility multiplier</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.alarmEvapMultiplier.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="2.0"
                max="6.0"
                step="0.5"
                value={config.alarmEvapMultiplier}
                onChange={(e) => onUpdateConfig({ alarmEvapMultiplier: Number(e.target.value) })}
                className="w-full accent-rose-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => onResetTabDefaults('pheromones')}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-white/5"
              >
                Reset tab to defaults
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: World & Brush */}
        {activeTab === 'world' && (
          <div className="space-y-4">
            {/* Simulation Speed */}
            <div>
              <span className="font-medium block text-slate-300 mb-1.5">Simulation time scale</span>
              <div className="grid grid-cols-3 gap-2">
                {([1, 2, 4] as const).map((spd) => (
                  <button
                    key={spd}
                    onClick={() => onUpdateConfig({ timeScale: spd })}
                    className={`py-1.5 rounded-lg font-mono-num font-semibold text-center transition ${
                      config.timeScale === spd
                        ? 'bg-amber-400 text-slate-950 shadow-md'
                        : 'bg-white/10 hover:bg-white/20 text-slate-300'
                    }`}
                  >
                    {spd}x speed
                  </button>
                ))}
              </div>
            </div>

            {/* Brush Radius */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Brush radius</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.brushRadius} px</span>
              </div>
              <input
                type="range"
                min="12"
                max="70"
                value={config.brushRadius}
                onChange={(e) => onUpdateConfig({ brushRadius: Number(e.target.value) })}
                className="w-full accent-amber-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            {/* Brush Intensity */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Deposition intensity</span>
                <span className="font-mono-num text-slate-100 font-semibold">{config.brushIntensity}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={config.brushIntensity}
                onChange={(e) => onUpdateConfig({ brushIntensity: Number(e.target.value) })}
                className="w-full accent-cyan-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => onResetTabDefaults('world')}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-white/5"
              >
                Reset tab to defaults
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  </>
);
};
