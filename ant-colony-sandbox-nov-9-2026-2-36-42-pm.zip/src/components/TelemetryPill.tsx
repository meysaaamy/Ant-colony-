import React from 'react';
import {
  Play,
  Pause,
  BookOpen,
  Sliders,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { TelemetryData } from '../sim/types';

interface TelemetryPillProps {
  telemetry: TelemetryData;
  onTogglePause: () => void;
  onCycleSpeed: () => void;
  onOpenFieldGuide: () => void;
  onOpenSettings: () => void;
  onOpenAI: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TelemetryPill: React.FC<TelemetryPillProps> = ({
  telemetry,
  onTogglePause,
  onCycleSpeed,
  onOpenFieldGuide,
  onOpenSettings,
  onOpenAI,
  isMuted,
  onToggleMute,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between px-3 sm:px-4 py-2 sm:py-3 pointer-events-none safe-top">
      {/* Left unified status pill matching screenshot */}
      <div className="glass-pill pointer-events-auto flex items-center gap-2 sm:gap-2.5 px-3 py-1.5 rounded-2xl text-xs font-medium text-slate-200 shadow-xl border border-white/10">
        {/* Ant Icon & Count */}
        <div className="flex items-center gap-1.5" title="Active Ant Population">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300">
            {/* Stylized Ant */}
            <ellipse cx="12" cy="17" rx="3.5" ry="4" />
            <ellipse cx="12" cy="10" rx="2.5" ry="2" />
            <ellipse cx="12" cy="5" rx="2" ry="1.5" />
            <path d="M10 4L8 1" />
            <path d="M14 4L16 1" />
            <path d="M9.5 9L4 7" />
            <path d="M14.5 9L20 7" />
            <path d="M9.5 11L4 12" />
            <path d="M14.5 11L20 12" />
            <path d="M9.5 13L5 17" />
            <path d="M14.5 13L19 17" />
          </svg>
          <span className="font-mono-num font-bold text-slate-100 text-xs sm:text-sm">{telemetry.antCount}</span>
          <span className="text-[11px] text-slate-400">ants</span>
        </div>

        <div className="w-[1px] h-4 bg-white/10" />

        {/* Food Icon (Green Lantern/Crystal) & Count */}
        <div className="flex items-center gap-1.5" title="Stored Food Delivered to Nest">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00e676" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 19 8 19 16 12 22 5 16 5 8" fill="#00e676" fillOpacity="0.2" />
            <line x1="12" y1="2" x2="12" y2="22" />
            <line x1="5" y1="8" x2="19" y2="16" />
            <line x1="19" y1="8" x2="5" y2="16" />
          </svg>
          <span className="font-mono-num font-bold text-[#00e676] text-xs sm:text-sm">{telemetry.storedFood}</span>
          <span className="text-[11px] text-slate-400">food</span>
        </div>

        <div className="w-[1px] h-4 bg-white/10" />

        {/* Speed Button */}
        <button
          onClick={onCycleSpeed}
          className="font-mono-num px-2 py-0.5 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 transition text-[11px] font-bold text-slate-200 border border-white/5"
          title="Cycle Simulation Speed (1x, 2x, 4x)"
          aria-label={`Simulation speed ${telemetry.simSpeed}x`}
        >
          {telemetry.simSpeed}x
        </button>

        <div className="w-[1px] h-4 bg-white/10" />

        {/* Play/Pause Button */}
        <button
          onClick={onTogglePause}
          className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/10 active:scale-95 transition text-slate-200"
          title={telemetry.isPaused ? 'Resume Simulation (Space)' : 'Pause Simulation (Space)'}
          aria-label={telemetry.isPaused ? 'Resume simulation' : 'Pause simulation'}
        >
          {telemetry.isPaused ? (
            <Play size={13} className="fill-current text-amber-400 ml-0.5" />
          ) : (
            <Pause size={13} className="text-slate-200" />
          )}
        </button>
      </div>

      {/* Right action buttons matching screenshot */}
      <div className="glass-pill pointer-events-auto flex items-center gap-1.5 p-1 rounded-2xl text-slate-300 shadow-xl border border-white/10">
        {/* Audio Mute/Unmute */}
        <button
          onClick={onToggleMute}
          className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/10 active:scale-95 transition text-slate-300"
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
        >
          {isMuted ? <VolumeX size={15} className="text-rose-400" /> : <Volume2 size={15} />}
        </button>

        {/* AI Studio Generative Panel */}
        <button
          onClick={onOpenAI}
          className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/10 active:scale-95 transition text-cyan-400"
          title="AI Studio: Generate Backdrops & Music"
          aria-label="AI Studio generator"
        >
          <Sparkles size={15} />
        </button>

        {/* Field Guide & Science (i) */}
        <button
          onClick={onOpenFieldGuide}
          className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/10 active:scale-95 transition text-slate-300"
          title="Field Guide & Science"
          aria-label="Open Field Guide and Science"
        >
          <BookOpen size={15} />
        </button>

        {/* Parameter Settings Sheet (Sliders) */}
        <button
          onClick={onOpenSettings}
          className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/10 active:scale-95 transition text-slate-300"
          title="Simulation Parameters & Presets"
          aria-label="Open Parameters Sheet"
        >
          <Sliders size={15} />
        </button>
      </div>
    </header>
  );
};
