import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Image as ImageIcon,
  Music,
  Loader2,
  Play,
  Pause,
  Download,
  Check,
} from 'lucide-react';

interface AIGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyBackground: (imgUrl: string) => void;
  onPlayMusic: (audioUrl: string) => void;
  onStopMusic: () => void;
}

export const AIGeneratorModal: React.FC<AIGeneratorModalProps> = ({
  isOpen,
  onClose,
  onApplyBackground,
  onPlayMusic,
  onStopMusic,
}) => {
  const [activeTab, setActiveTab] = useState<'image' | 'music'>('image');

  // Image generation state
  const [imagePrompt, setImagePrompt] = useState(
    'Bioluminescent mycorrhizal network, glowing electric cyan hyphae, macro nature photography on deep basalt obsidian rock'
  );
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '1:1' | '9:16'>('16:9');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [imageNotice, setImageNotice] = useState<string | null>(null);
  const [imageApplied, setImageApplied] = useState(false);

  // Music generation state
  const [musicPrompt, setMusicPrompt] = useState(
    'Ethereal subterranean bio-music, delicate crystal chimes, warm acoustic drone, calming deep sanctuary ambient'
  );
  const [musicType, setMusicType] = useState<'clip' | 'pro'>('clip');
  const [isGeneratingMusic, setIsGeneratingMusic] = useState(false);
  const [generatedMusicUrl, setGeneratedMusicUrl] = useState<string | null>(null);
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);
  const [musicNotice, setMusicNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerateImage = async () => {
    setIsGeneratingImage(true);
    setImageNotice(null);
    setImageApplied(false);
    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: imagePrompt,
          imageSize,
          aspectRatio,
        }),
      });
      const data = await res.json();
      if (data.imageUrl) {
        setGeneratedImageUrl(data.imageUrl);
        if (data.notice) setImageNotice(data.notice);
      } else {
        setImageNotice(data.error || 'Failed to generate image');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setImageNotice(msg);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleApplyBackground = () => {
    if (!generatedImageUrl) return;
    onApplyBackground(generatedImageUrl);
    setImageApplied(true);
  };

  const handleGenerateMusic = async () => {
    setIsGeneratingMusic(true);
    setMusicNotice(null);
    try {
      const res = await fetch('/api/generate-music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: musicPrompt,
          modelType: musicType,
        }),
      });
      const data = await res.json();
      if (data.audioDataUrl) {
        setGeneratedMusicUrl(data.audioDataUrl);
      } else {
        setMusicNotice(data.error || data.notice || 'Could not generate audio');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setMusicNotice(msg);
    } finally {
      setIsGeneratingMusic(false);
    }
  };

  const handleTogglePlayMusic = () => {
    if (!generatedMusicUrl) return;
    if (isPlayingMusic) {
      onStopMusic();
      setIsPlayingMusic(false);
    } else {
      onPlayMusic(generatedMusicUrl);
      setIsPlayingMusic(true);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="AI Sanctuary Studio"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="glass-modal w-full max-w-lg max-h-[90vh] flex flex-col rounded-2xl overflow-hidden shadow-2xl border border-white/15">
        {/* Header */}
        <div className="px-5 py-4 flex items-center justify-between border-b border-white/10 bg-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-400/20 text-cyan-300 flex items-center justify-center">
              <Sparkles size={18} />
            </div>
            <div>
              <h2 className="font-display text-base font-bold text-slate-100 tracking-wide">
                AI Sanctuary Studio
              </h2>
              <p className="text-[11px] text-slate-400">
                Generate high-fidelity macro plates & Lyria music
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition"
            aria-label="Close studio"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-white/10 bg-black/20 px-5 pt-3">
          <button
            onClick={() => setActiveTab('image')}
            className={`flex items-center gap-2 pb-2.5 px-3 text-xs font-semibold border-b-2 transition ${
              activeTab === 'image'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon size={14} />
            <span>Generate Macro Visuals</span>
          </button>
          <button
            onClick={() => setActiveTab('music')}
            className={`flex items-center gap-2 pb-2.5 px-3 text-xs font-semibold border-b-2 transition ${
              activeTab === 'music'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Music size={14} />
            <span>Generate Lyria Music</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs touch-pan-y">
          {activeTab === 'image' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Macro Plate Prompt
                </label>
                <textarea
                  rows={3}
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-white/10 text-slate-100 focus:outline-none focus:border-cyan-400 resize-none text-xs"
                  placeholder="Describe subterranean textures, bioluminescent fungus, or crystal formations..."
                />
              </div>

              {/* Resolution Affordance (1K, 2K, 4K) */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Image Size (Resolution)
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['1K', '2K', '4K'] as const).map((sz) => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setImageSize(sz)}
                        className={`py-1.5 rounded-lg font-mono-num font-semibold text-center transition ${
                          imageSize === sz
                            ? 'bg-cyan-400 text-slate-950 shadow-sm'
                            : 'bg-white/5 hover:bg-white/10 text-slate-300'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Aspect Ratio
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['16:9', '1:1', '9:16'] as const).map((ar) => (
                      <button
                        key={ar}
                        type="button"
                        onClick={() => setAspectRatio(ar)}
                        className={`py-1.5 rounded-lg font-mono-num font-semibold text-center transition ${
                          aspectRatio === ar
                            ? 'bg-cyan-400 text-slate-950 shadow-sm'
                            : 'bg-white/5 hover:bg-white/10 text-slate-300'
                        }`}
                      >
                        {ar}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Preset prompt pills */}
              <div>
                <span className="block text-slate-400 text-[11px] mb-1.5">Inspiration presets:</span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Bioluminescent mycorrhizal fungal grove',
                    'Basalt fissure with glowing obsidian veins',
                    'Iridescent emerald quartz cave',
                  ].map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => setImagePrompt(p)}
                      className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 text-[10px] transition"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerateImage}
                disabled={isGeneratingImage}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-98 font-semibold text-white shadow-lg transition flex items-center justify-center gap-2"
              >
                {isGeneratingImage ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Synthesizing Macro Backdrop...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={16} />
                    <span>Generate Macro Backdrop</span>
                  </>
                )}
              </button>

              {imageNotice && (
                <p className="text-[11px] text-amber-300/90 bg-amber-400/10 p-2.5 rounded-xl border border-amber-400/20">
                  {imageNotice}
                </p>
              )}

              {/* Image Preview & Apply */}
              {generatedImageUrl && (
                <div className="p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2.5">
                  <span className="font-semibold text-slate-200 block text-[11px]">Preview:</span>
                  <div className="relative aspect-video rounded-lg overflow-hidden bg-black">
                    <img
                      src={generatedImageUrl}
                      alt="Generated macro backdrop"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={handleApplyBackground}
                      className={`flex-1 py-1.5 rounded-lg font-medium transition flex items-center justify-center gap-1.5 text-xs ${
                        imageApplied
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                          : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                      }`}
                    >
                      {imageApplied ? (
                        <>
                          <Check size={14} />
                          <span>Applied to Sanctuary</span>
                        </>
                      ) : (
                        <span>Apply as Backdrop Plate</span>
                      )}
                    </button>
                    <a
                      href={generatedImageUrl}
                      download="sanctuary_backdrop.png"
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 flex items-center justify-center transition"
                      title="Download image"
                    >
                      <Download size={14} />
                    </a>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'music' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Lyria Music Prompt
                </label>
                <textarea
                  rows={3}
                  value={musicPrompt}
                  onChange={(e) => setMusicPrompt(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-white/10 text-slate-100 focus:outline-none focus:border-amber-400 resize-none text-xs"
                  placeholder="Describe ambient music, instruments, mood, or tempos..."
                />
              </div>

              {/* Clip vs Pro selection */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Model Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setMusicType('clip')}
                    className={`py-2 px-3 rounded-xl border text-left transition ${
                      musicType === 'clip'
                        ? 'border-amber-400 bg-amber-400/10 text-amber-200'
                        : 'border-white/10 bg-white/5 text-slate-300'
                    }`}
                  >
                    <div className="font-semibold text-xs">Lyria 3 Clip</div>
                    <div className="text-[10px] text-slate-400">Up to 30s loopable clip</div>
                  </button>
                  <button
                    onClick={() => setMusicType('pro')}
                    className={`py-2 px-3 rounded-xl border text-left transition ${
                      musicType === 'pro'
                        ? 'border-amber-400 bg-amber-400/10 text-amber-200'
                        : 'border-white/10 bg-white/5 text-slate-300'
                    }`}
                  >
                    <div className="font-semibold text-xs">Lyria 3 Pro</div>
                    <div className="text-[10px] text-slate-400">Full-length atmospheric track</div>
                  </button>
                </div>
              </div>

              {/* Generate Music Button */}
              <button
                onClick={handleGenerateMusic}
                disabled={isGeneratingMusic}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 active:scale-98 font-semibold text-slate-950 shadow-lg transition flex items-center justify-center gap-2"
              >
                {isGeneratingMusic ? (
                  <>
                    <Loader2 size={16} className="animate-spin text-slate-950" />
                    <span>Generating Audio Stream...</span>
                  </>
                ) : (
                  <>
                    <Music size={16} />
                    <span>Generate Ambient Music</span>
                  </>
                )}
              </button>

              {musicNotice && (
                <p className="text-[11px] text-amber-300/90 bg-amber-400/10 p-2.5 rounded-xl border border-amber-400/20">
                  {musicNotice}
                </p>
              )}

              {/* Music Player */}
              {generatedMusicUrl && (
                <div className="p-3.5 rounded-xl bg-slate-900 border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200 text-xs">Generated Lyria Soundtrack</span>
                    <button
                      onClick={handleTogglePlayMusic}
                      className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold flex items-center gap-1.5 transition active:scale-95 text-xs"
                    >
                      {isPlayingMusic ? <Pause size={14} /> : <Play size={14} className="fill-current" />}
                      <span>{isPlayingMusic ? 'Pause Music' : 'Play in Game'}</span>
                    </button>
                  </div>
                  <audio
                    src={generatedMusicUrl}
                    controls
                    className="w-full h-8"
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
