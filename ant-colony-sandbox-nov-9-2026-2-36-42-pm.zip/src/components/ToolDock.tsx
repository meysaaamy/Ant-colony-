import React, { useState } from 'react';
import { ToolType, PresetType } from '../sim/types';
import { Sliders, Sparkles, RotateCcw, Settings, ChevronDown } from 'lucide-react';

interface ToolDockProps {
  activeTool: ToolType;
  onSelectTool: (tool: ToolType) => void;
  brushRadius: number;
  brushIntensity: number;
  onChangeBrushRadius: (r: number) => void;
  onChangeBrushIntensity: (i: number) => void;
  activePreset: PresetType;
  onOpenWorldControls: () => void;
  onClearTrails: () => void;
  onResetWorld: () => void;
  isFaded: boolean;
}

interface ToolDefinition {
  id: ToolType;
  name: string;
  accent: string;
  shortcut: string;
  icon: React.ReactNode;
}

export const ToolDock: React.FC<ToolDockProps> = ({
  activeTool,
  onSelectTool,
  brushRadius,
  brushIntensity,
  onChangeBrushRadius,
  onChangeBrushIntensity,
  activePreset,
  onOpenWorldControls,
  onClearTrails,
  onResetWorld,
  isFaded,
}) => {
  const [showBrushPopover, setShowBrushPopover] = useState(false);
  const [resetArmed, setResetArmed] = useState(false);

  const presetTitles: Record<PresetType, string> = {
    sanctuary: 'Open Sanctuary',
    double_bridge: 'Double Bridge',
    labyrinth: 'Subterranean Labyrinth',
  };

  const handleToolClick = (tool: ToolType) => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(8);
      } catch {
        // ignore
      }
    }
    onSelectTool(tool);
  };

  const handleResetClick = () => {
    if (resetArmed) {
      setResetArmed(false);
      onResetWorld();
    } else {
      setResetArmed(true);
      setTimeout(() => setResetArmed(false), 3000);
    }
  };

  const tools: ToolDefinition[] = [
    {
      id: 'food_trail',
      name: 'Food trail',
      accent: '#00e676',
      shortcut: '1',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 18C7 18 8 13 12 13C16 13 17 6 20 6" />
          <polygon points="17 4 21 6 18 9" fill="currentColor" />
        </svg>
      ),
    },
    {
      id: 'home_trail',
      name: 'Home trail',
      accent: '#0099ff',
      shortcut: '2',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 12C8 12 8 8 12 8C16 8 16 16 20 16" />
          <path d="M4 16C8 16 8 12 12 12C16 12 16 20 20 20" opacity="0.45" />
        </svg>
      ),
    },
    {
      id: 'alarm',
      name: 'Alarm',
      accent: '#ff0a43',
      shortcut: '3',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="3" fill="currentColor" />
          <path d="M12 4V2" />
          <path d="M12 22V20" />
          <path d="M4 12H2" />
          <path d="M22 12H20" />
        </svg>
      ),
    },
    {
      id: 'food_cluster',
      name: 'Food cluster',
      accent: '#00e676',
      shortcut: '4',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polygon points="12 2 19 8 19 16 12 22 5 16 5 8" fill="currentColor" fillOpacity="0.2" />
          <line x1="12" y1="2" x2="12" y2="22" />
          <line x1="5" y1="8" x2="19" y2="16" />
          <line x1="19" y1="8" x2="5" y2="16" />
        </svg>
      ),
    },
    {
      id: 'wall',
      name: 'Wall',
      accent: '#94a3b8',
      shortcut: '5',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 20L10 6L14 13L17 9L21 20H3Z" />
        </svg>
      ),
    },
    {
      id: 'eraser',
      name: 'Eraser',
      accent: '#cbd5e1',
      shortcut: '6',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M18 13.5L13.5 18L5 9.5L9.5 5L18 13.5Z" />
          <path d="M14 14L10 18H20" />
        </svg>
      ),
    },
  ];

  const currentToolDef = tools.find((t) => t.id === activeTool) || tools[0];

  return (
    <div
      className={`fixed bottom-2 sm:bottom-4 left-0 right-0 z-30 flex flex-col items-center pointer-events-none safe-bottom px-3 transition-opacity duration-200 ${
        isFaded ? 'opacity-30' : 'opacity-100'
      }`}
    >
      {/* Brush Settings Floating Popover */}
      {showBrushPopover && (
        <div className="glass-modal pointer-events-auto mb-2 w-80 p-4 rounded-2xl shadow-2xl border border-white/10 text-xs">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-white/10">
            <span className="font-semibold text-slate-100">Brush Settings</span>
            <button
              onClick={() => setShowBrushPopover(false)}
              className="text-slate-400 hover:text-slate-100 px-2 py-0.5 rounded text-[11px]"
            >
              Done
            </button>
          </div>

          {/* Radius Slider */}
          <div className="mb-3.5">
            <div className="flex justify-between text-slate-300 mb-1.5">
              <span>Radius [ / ]</span>
              <span className="font-mono-num text-slate-100 font-semibold">{brushRadius}px</span>
            </div>
            <input
              type="range"
              min="12"
              max="70"
              value={brushRadius}
              onChange={(e) => onChangeBrushRadius(Number(e.target.value))}
              className="w-full accent-emerald-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
            />
          </div>

          {/* Intensity Slider */}
          <div>
            <div className="flex justify-between text-slate-300 mb-1.5">
              <span>Deposition Intensity</span>
              <span className="font-mono-num text-slate-100 font-semibold">{brushIntensity}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={brushIntensity}
              onChange={(e) => onChangeBrushIntensity(Number(e.target.value))}
              className="w-full accent-cyan-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer touch-none"
            />
          </div>
        </div>
      )}

      {/* Unified Floating Controls Card matching the User's Screenshot */}
      <div className="pointer-events-auto w-full max-w-[460px] bg-[#09111b]/92 backdrop-blur-xl border border-white/10 rounded-2xl sm:rounded-3xl p-2.5 sm:p-3 shadow-2xl flex flex-col gap-2.5">
        {/* Top Grab Handle */}
        <div
          onClick={onOpenWorldControls}
          className="w-10 h-1 bg-white/20 rounded-full mx-auto -mt-0.5 mb-0.5 cursor-pointer hover:bg-white/40 transition"
        />

        {/* Row 1: World controls & Action buttons */}
        <div className="flex items-center justify-between gap-2">
          {/* World controls button */}
          <button
            onClick={onOpenWorldControls}
            className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-98 transition text-left border border-white/5"
            title="Open Scenario & Colony Parameters"
          >
            <div className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center text-slate-300">
              <Sliders size={14} />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium leading-none">World controls</span>
              <span className="text-xs font-bold text-slate-100 leading-tight mt-0.5">
                {presetTitles[activePreset] || 'Double Bridge'}
              </span>
            </div>
          </button>

          {/* Right action buttons: Clear trails & Reset */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onClearTrails}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-xs font-medium text-slate-200 transition border border-white/5 flex items-center gap-1.5"
              title="Clear all chemical scent fields"
            >
              <Sparkles size={13} className="text-amber-400" />
              <span>Clear trails</span>
            </button>

            <button
              onClick={handleResetClick}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-medium transition active:scale-95 border flex items-center gap-1.5 ${
                resetArmed
                  ? 'bg-rose-600 border-rose-500 text-white animate-pulse'
                  : 'bg-white/5 hover:bg-white/10 border-white/5 text-slate-200'
              }`}
              title="Reset world to initial scenario state"
            >
              <RotateCcw size={13} />
              <span>{resetArmed ? 'Confirm' : 'Reset'}</span>
            </button>
          </div>
        </div>

        {/* Row 2: Active Tool Badge & Brush Size Selector */}
        <div className="flex items-center justify-between px-1">
          {/* Left: Active Tool Pill with colored dot */}
          <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-black/40 border border-white/10 text-xs font-medium text-slate-200">
            <span
              className="w-2 h-2 rounded-full"
              style={{
                backgroundColor: currentToolDef.accent,
                boxShadow: `0 0 8px ${currentToolDef.accent}`,
              }}
            />
            <span className="font-semibold">{currentToolDef.name}</span>
            <span className="text-[10px] text-slate-400 font-mono-num">· {currentToolDef.shortcut}</span>
          </div>

          {/* Right: Brush Size Dropdown */}
          <button
            onClick={() => setShowBrushPopover((prev) => !prev)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-black/40 hover:bg-black/60 border border-white/10 text-xs text-slate-200 active:scale-95 transition"
            title="Adjust Brush Radius"
            aria-expanded={showBrushPopover}
          >
            <Settings size={13} className="text-slate-400" />
            <span className="font-mono-num font-semibold">{brushRadius}</span>
            <ChevronDown size={13} className="text-slate-400" />
          </button>
        </div>

        {/* Row 3: The 6 Tool Buttons */}
        <div className="grid grid-cols-6 gap-1 sm:gap-1.5 p-1 bg-black/40 rounded-xl sm:rounded-2xl border border-white/10">
          {tools.map((t) => {
            const isActive = activeTool === t.id;
            return (
              <button
                key={t.id}
                onClick={() => handleToolClick(t.id)}
                title={`${t.name} (Key: ${t.shortcut})`}
                aria-label={t.name}
                aria-pressed={isActive}
                style={{
                  color: isActive ? t.accent : '#94a3b8',
                  borderColor: isActive ? t.accent : 'transparent',
                  backgroundColor: isActive ? `${t.accent}20` : 'transparent',
                  boxShadow: isActive ? `0 0 16px -2px ${t.accent}60, inset 0 0 10px -2px ${t.accent}30` : 'none',
                }}
                className={`relative flex flex-col items-center justify-center h-12 sm:h-14 rounded-lg sm:rounded-xl border transition-all duration-150 active:scale-95 ${
                  isActive ? 'border-2' : 'hover:bg-white/5'
                }`}
              >
                <div>{t.icon}</div>
                <span className="absolute bottom-1 right-1.5 text-[9px] font-mono-num font-semibold text-slate-500 leading-none">
                  {t.shortcut}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
