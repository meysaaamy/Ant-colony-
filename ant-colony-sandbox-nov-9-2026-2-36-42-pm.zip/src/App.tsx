import React, { useEffect, useRef, useState, useCallback } from 'react';
import { SimulationEngine } from './sim/engine';
import { SimulationRenderer } from './sim/renderer';
import { ToolType, PresetType, StrokePoint, TelemetryData, SimulationConfig } from './sim/types';
import { interpolateStroke } from './sim/math';
import { BioSoundscape } from './audio/soundscape';
import { TelemetryPill } from './components/TelemetryPill';
import { ToolDock } from './components/ToolDock';
import { ParameterSheet } from './components/ParameterSheet';
import { FieldGuideModal } from './components/FieldGuideModal';
import { AIGeneratorModal } from './components/AIGeneratorModal';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Engine, Renderer, and Soundscape instances
  const engineRef = useRef<SimulationEngine | null>(null);
  const rendererRef = useRef<SimulationRenderer | null>(null);
  const soundscapeRef = useRef<BioSoundscape | null>(null);

  // Animation frame and timing refs
  const rafIdRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);
  const accumulatorRef = useRef<number>(0);
  const frameTimesRef = useRef<number[]>([]);
  const lastHudUpdateRef = useRef<number>(0);

  // Pointer state for single-touch drawing
  const activePointerIdRef = useRef<number | null>(null);
  const isPointerDownRef = useRef<boolean>(false);
  const lastStrokePointRef = useRef<{ x: number; y: number } | null>(null);
  const strokePointsRef = useRef<StrokePoint[]>([]);
  const strokeEndTimerRef = useRef<number | null>(null);

  // Active UI States
  const [activeTool, setActiveTool] = useState<ToolType>('food_trail');
  const [isSheetOpen, setIsSheetOpen] = useState<boolean>(false);
  const [isFieldGuideOpen, setIsFieldGuideOpen] = useState<boolean>(false);
  const [isAIOpen, setIsAIOpen] = useState<boolean>(false);
  const [isChromeFaded, setIsChromeFaded] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [hasDrawnFirstStroke, setHasDrawnFirstStroke] = useState<boolean>(() => {
    try {
      return localStorage.getItem('myrmecodia_onboarded') === 'true';
    } catch {
      return false;
    }
  });

  // Config and Telemetry State
  const [simConfig, setSimConfig] = useState<SimulationConfig>(() => {
    const e = new SimulationEngine();
    return e.config;
  });

  const [telemetry, setTelemetry] = useState<TelemetryData>({
    fps: 60,
    antCount: 160,
    storedFood: 0,
    simSpeed: 1,
    isPaused: false,
    activePreset: 'sanctuary',
    atCapacity: false,
    fpsStatus: 'emerald',
  });

  // Show a single discreet toast
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2400);
  }, []);

  // Initialize Simulation Engine & Renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new SimulationEngine();
    engineRef.current = engine;
    setSimConfig({ ...engine.config });

    const renderer = new SimulationRenderer(canvas, engine);
    rendererRef.current = renderer;

    const soundscape = new BioSoundscape();
    soundscapeRef.current = soundscape;

    // Attach callbacks
    engine.onFoodHarvested = () => {
      soundscape.playHarvestChime();
    };
    engine.onFoodDelivered = () => {
      soundscape.playDeliveryChime();
    };
    engine.onColonyCapacity = () => {
      showToast('Colony at capacity. Raise the cap in Colony settings.');
    };

    // Calculate canvas size and camera transform
    const updateCanvasDimensions = () => {
      if (!canvas || !engine) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const displayWidth = window.innerWidth;
      const displayHeight = window.innerHeight;

      canvas.width = Math.floor(displayWidth * dpr);
      canvas.height = Math.floor(displayHeight * dpr);
      canvas.style.width = `${displayWidth}px`;
      canvas.style.height = `${displayHeight}px`;

      // Transform camera to fit world within screen while maintaining aspect ratio
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset
        const scaleX = (displayWidth * dpr) / engine.config.worldWidth;
        const scaleY = (displayHeight * dpr) / engine.config.worldHeight;
        const scale = Math.max(scaleX, scaleY); // Cover fill
        const offsetX = (displayWidth * dpr - engine.config.worldWidth * scale) / 2;
        const offsetY = (displayHeight * dpr - engine.config.worldHeight * scale) / 2;
        ctx.setTransform(scale, 0, 0, scale, offsetX, offsetY);
      }
    };

    updateCanvasDimensions();

    let resizeTimeout: ReturnType<typeof setTimeout> | null = null;
    const handleResize = () => {
      if (resizeTimeout) clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(updateCanvasDimensions, 150);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    // Visibility change handler (prevent spiral of death)
    const handleVisibilityChange = () => {
      if (document.hidden) {
        lastTimeRef.current = 0;
        accumulatorRef.current = 0;
      } else {
        lastTimeRef.current = performance.now();
        accumulatorRef.current = 0;
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Main animation loop
    const fixedDt = 1 / 60;
    const loop = (currentTime: number) => {
      rafIdRef.current = requestAnimationFrame(loop);

      if (lastTimeRef.current === 0) {
        lastTimeRef.current = currentTime;
        return;
      }

      const frameTimeMs = Math.min(100, currentTime - lastTimeRef.current);
      lastTimeRef.current = currentTime;

      // Track rolling FPS
      frameTimesRef.current.push(frameTimeMs);
      if (frameTimesRef.current.length > 30) frameTimesRef.current.shift();

      // Adaptive quality scaling: throttle diffusion if average frame time > 20ms (< 50 FPS)
      const avgFrameTime =
        frameTimesRef.current.reduce((a, b) => a + b, 0) / (frameTimesRef.current.length || 1);
      engine.qualityThrottleDiffusion = avgFrameTime > 20.0;

      // Accumulate physics steps if not paused
      if (!engineRef.current) return;
      const isPaused = telemetry.isPaused;
      const speed = engine.config.timeScale;

      if (!isPaused) {
        accumulatorRef.current += (frameTimeMs / 1000) * speed;
        // Clamp accumulator to max 3 steps to prevent spiral-of-death
        accumulatorRef.current = Math.min(accumulatorRef.current, fixedDt * 3 * speed);

        while (accumulatorRef.current >= fixedDt) {
          engine.step(fixedDt);
          accumulatorRef.current -= fixedDt;
        }
      }

      // Render frame
      if (rendererRef.current) {
        const strokePos = lastStrokePointRef.current;
        rendererRef.current.render(engine, activeTool, {
          isDown: isPointerDownRef.current,
          x: strokePos ? strokePos.x : -100,
          y: strokePos ? strokePos.y : -100,
          strokePoints: strokePointsRef.current,
        });
      }

      // Throttle HUD DOM telemetry updates to 10Hz
      if (currentTime - lastHudUpdateRef.current > 100) {
        lastHudUpdateRef.current = currentTime;
        const validFrameTime = Math.max(8.33, Math.min(100, avgFrameTime || 16.6));
        const currentFps = Math.max(1, Math.min(120, Math.round(1000 / validFrameTime)));
        const status = currentFps >= 55 ? 'emerald' : currentFps >= 40 ? 'amber' : 'crimson';

        setTelemetry((prev) => ({
          ...prev,
          fps: currentFps,
          antCount: engine.activeCount,
          storedFood: engine.nest.storedFood,
          simSpeed: engine.config.timeScale,
          activePreset: engine.activePreset,
          atCapacity: engine.activeCount >= engine.config.maxPopulation,
          fpsStatus: status,
        }));
      }
    };

    lastTimeRef.current = performance.now();
    rafIdRef.current = requestAnimationFrame(loop);

    return () => {
      if (rafIdRef.current) cancelAnimationFrame(rafIdRef.current);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  // Map pointer client coordinates to logical world simulation coordinates
  const clientToWorld = useCallback((clientX: number, clientY: number): { x: number; y: number } => {
    const canvas = canvasRef.current;
    const engine = engineRef.current;
    if (!canvas || !engine) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const canvasPxX = (clientX - rect.left) * dpr;
    const canvasPxY = (clientY - rect.top) * dpr;

    // Invert the transform matrix
    const scaleX = (rect.width * dpr) / engine.config.worldWidth;
    const scaleY = (rect.height * dpr) / engine.config.worldHeight;
    const scale = Math.max(scaleX, scaleY);
    const offsetX = (rect.width * dpr - engine.config.worldWidth * scale) / 2;
    const offsetY = (rect.height * dpr - engine.config.worldHeight * scale) / 2;

    const wx = (canvasPxX - offsetX) / scale;
    const wy = (canvasPxY - offsetY) / scale;

    return {
      x: Math.max(0, Math.min(engine.config.worldWidth, wx)),
      y: Math.max(0, Math.min(engine.config.worldHeight, wy)),
    };
  }, []);

  // Stroke Execution
  const applyBrushAtPoint = useCallback(
    (wx: number, wy: number) => {
      const engine = engineRef.current;
      const sound = soundscapeRef.current;
      if (!engine) return;

      const r = engine.config.brushRadius;
      const intensity = engine.config.brushIntensity;

      if (activeTool === 'food_trail') {
        engine.depositPheromone(engine.foodTrail, wx, wy, r, intensity);
        sound?.playStrokeHum('food_trail');
      } else if (activeTool === 'home_trail') {
        engine.depositPheromone(engine.homeGuide, wx, wy, r, intensity);
        sound?.playStrokeHum('home_trail');
      } else if (activeTool === 'alarm') {
        engine.depositPheromone(engine.alarm, wx, wy, r, intensity * 1.5);
        sound?.playStrokeHum('alarm');
      } else if (activeTool === 'food_cluster') {
        engine.addFoodCluster(wx, wy);
        sound?.playStrokeHum('food_cluster');
      } else if (activeTool === 'wall') {
        engine.paintWallAt(wx, wy, r);
        sound?.playStrokeHum('wall');
      } else if (activeTool === 'eraser') {
        engine.eraseAt(wx, wy, r);
        sound?.playStrokeHum('eraser');
      }
    },
    [activeTool]
  );

  // Pointer Event Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    // Only track single primary pointer
    if (activePointerIdRef.current !== null && activePointerIdRef.current !== e.pointerId) {
      return;
    }

    soundscapeRef.current?.resume();

    activePointerIdRef.current = e.pointerId;
    isPointerDownRef.current = true;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);

    // Fade chrome during drawing stroke
    setIsChromeFaded(true);
    if (strokeEndTimerRef.current) clearTimeout(strokeEndTimerRef.current);

    // Dismiss first run onboarding hint
    if (!hasDrawnFirstStroke) {
      setHasDrawnFirstStroke(true);
      try {
        localStorage.setItem('myrmecodia_onboarded', 'true');
      } catch {
        // ignore
      }
    }

    const { x, y } = clientToWorld(e.clientX, e.clientY);
    lastStrokePointRef.current = { x, y };
    strokePointsRef.current = [{ x, y, time: performance.now() }];

    applyBrushAtPoint(x, y);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const { x, y } = clientToWorld(e.clientX, e.clientY);

    if (!isPointerDownRef.current || activePointerIdRef.current !== e.pointerId) {
      // Just hover cursor update for desktop
      lastStrokePointRef.current = { x, y };
      return;
    }

    const last = lastStrokePointRef.current;
    if (last) {
      // Dense linear interpolation spaced at 0.25 * brushRadius so fast finger swipes produce continuous highways
      const engine = engineRef.current;
      const stepSpacing = (engine?.config.brushRadius ?? 32) * 0.25;
      const points = interpolateStroke(last.x, last.y, x, y, stepSpacing);

      for (const pt of points) {
        applyBrushAtPoint(pt.x, pt.y);
      }
    }

    lastStrokePointRef.current = { x, y };
    strokePointsRef.current.push({ x, y, time: performance.now() });

    // Keep recent stroke trail limited
    if (strokePointsRef.current.length > 25) {
      strokePointsRef.current.shift();
    }
  };

  const endStroke = () => {
    isPointerDownRef.current = false;
    activePointerIdRef.current = null;
    strokePointsRef.current = [];

    // Delay restoring chrome by 200ms
    if (strokeEndTimerRef.current) clearTimeout(strokeEndTimerRef.current);
    strokeEndTimerRef.current = window.setTimeout(() => {
      setIsChromeFaded(false);
    }, 200);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (activePointerIdRef.current === e.pointerId) {
      endStroke();
    }
  };

  const handlePointerCancel = () => {
    endStroke();
  };

  // Keyboard Shortcuts (1-6 tools, Space pause, [ / ] brush size, Esc close)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.key === '1') setActiveTool('food_trail');
      if (e.key === '2') setActiveTool('home_trail');
      if (e.key === '3') setActiveTool('alarm');
      if (e.key === '4') setActiveTool('food_cluster');
      if (e.key === '5') setActiveTool('wall');
      if (e.key === '6') setActiveTool('eraser');

      if (e.key === ' ') {
        e.preventDefault();
        setTelemetry((prev) => ({ ...prev, isPaused: !prev.isPaused }));
      }

      if (e.key === '[') {
        setSimConfig((prev) => {
          const nextR = Math.max(12, prev.brushRadius - 4);
          if (engineRef.current) engineRef.current.config.brushRadius = nextR;
          return { ...prev, brushRadius: nextR };
        });
      }

      if (e.key === ']') {
        setSimConfig((prev) => {
          const nextR = Math.min(70, prev.brushRadius + 4);
          if (engineRef.current) engineRef.current.config.brushRadius = nextR;
          return { ...prev, brushRadius: nextR };
        });
      }

      if (e.key === 'Escape') {
        setIsSheetOpen(false);
        setIsFieldGuideOpen(false);
        setIsAIOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // UI Handlers
  const handleTogglePause = () => {
    setTelemetry((prev) => ({ ...prev, isPaused: !prev.isPaused }));
  };

  const handleCycleSpeed = () => {
    const nextSpeed: 1 | 2 | 4 = telemetry.simSpeed === 1 ? 2 : telemetry.simSpeed === 2 ? 4 : 1;
    if (engineRef.current) {
      engineRef.current.config.timeScale = nextSpeed;
    }
    setSimConfig((prev) => ({ ...prev, timeScale: nextSpeed }));
    setTelemetry((prev) => ({ ...prev, simSpeed: nextSpeed }));
  };

  const handleClearPheromones = () => {
    engineRef.current?.clearPheromones();
    showToast('Pheromones cleared');
  };

  const handleResetWorld = () => {
    engineRef.current?.resetWorld();
    showToast('World reset');
  };

  const handleLoadPreset = (preset: PresetType) => {
    engineRef.current?.loadPreset(preset);
    showToast(`Loaded ${preset.replace('_', ' ')} scenario`);
  };

  const handleUpdateConfig = (newCfg: Partial<SimulationConfig>) => {
    if (engineRef.current) {
      Object.assign(engineRef.current.config, newCfg);
    }
    setSimConfig((prev) => ({ ...prev, ...newCfg }));
  };

  const handleResetTabDefaults = (tab: 'colony' | 'pheromones' | 'world') => {
    const defaults = new SimulationEngine().config;
    if (tab === 'colony') {
      handleUpdateConfig({
        maxPopulation: defaults.maxPopulation,
        antBaseSpeed: defaults.antBaseSpeed,
        antennaAngle: defaults.antennaAngle,
        trailSensitivity: defaults.trailSensitivity,
      });
    } else if (tab === 'pheromones') {
      handleUpdateConfig({
        evaporationRate: defaults.evaporationRate,
        diffusionRate: defaults.diffusionRate,
        alarmEvapMultiplier: defaults.alarmEvapMultiplier,
        pheromoneRenderMode: 'glow',
      });
    } else if (tab === 'world') {
      handleUpdateConfig({
        timeScale: 1,
        brushRadius: defaults.brushRadius,
        brushIntensity: defaults.brushIntensity,
      });
    }
    showToast('Reset to defaults');
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundscapeRef.current?.setMuted(nextMuted);
  };

  const handleApplyBackground = (imgUrl: string) => {
    const img = new Image();
    img.src = imgUrl;
    img.onload = () => {
      if (rendererRef.current && engineRef.current) {
        rendererRef.current.customBackground = img;
        rendererRef.current.bakeTerrain(engineRef.current);
        showToast('Macro backdrop applied');
      }
    };
  };

  return (
    <main className="relative w-full h-[100dvh] overflow-hidden bg-[#03050a] select-none touch-none">
      {/* 60 FPS Canvas */}
      <canvas
        ref={canvasRef}
        role="img"
        aria-label="Interactive Bioluminescent Ant Colony Simulation Canvas"
        className="absolute inset-0 block w-full h-full cursor-crosshair touch-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerCancel}
      />

      {/* Top Compact Telemetry Pill */}
      <TelemetryPill
        telemetry={telemetry}
        onTogglePause={handleTogglePause}
        onCycleSpeed={handleCycleSpeed}
        onOpenFieldGuide={() => setIsFieldGuideOpen(true)}
        onOpenSettings={() => setIsSheetOpen((prev) => !prev)}
        onOpenAI={() => setIsAIOpen(true)}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* Bottom Floating Tool Dock matching user screenshot */}
      <ToolDock
        activeTool={activeTool}
        onSelectTool={setActiveTool}
        brushRadius={simConfig.brushRadius}
        brushIntensity={simConfig.brushIntensity}
        onChangeBrushRadius={(r) => handleUpdateConfig({ brushRadius: r })}
        onChangeBrushIntensity={(i) => handleUpdateConfig({ brushIntensity: i })}
        activePreset={telemetry.activePreset}
        onOpenWorldControls={() => setIsSheetOpen((prev) => !prev)}
        onClearTrails={handleClearPheromones}
        onResetWorld={handleResetWorld}
        isFaded={isChromeFaded}
      />

      {/* Collapsible Parameter Sheet */}
      <ParameterSheet
        isOpen={isSheetOpen}
        onToggleOpen={() => setIsSheetOpen((prev) => !prev)}
        config={simConfig}
        activePreset={telemetry.activePreset}
        onLoadPreset={handleLoadPreset}
        onClearPheromones={handleClearPheromones}
        onResetWorld={handleResetWorld}
        onUpdateConfig={handleUpdateConfig}
        onResetTabDefaults={handleResetTabDefaults}
      />

      {/* Onboarding First-Run Hint */}
      {!hasDrawnFirstStroke && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-16 left-1/2 -translate-x-1/2 z-30 pointer-events-none px-4 py-2 rounded-full glass-pill border border-amber-400/40 text-amber-300 text-xs font-medium shadow-2xl animate-bounce flex items-center gap-2"
        >
          <span className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_#ffae00]" />
          <span>Draw an amber trail from the nest to the crystals</span>
        </div>
      )}

      {/* Single Toast Notification */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-24 left-1/2 -translate-x-1/2 z-40 pointer-events-none px-3.5 py-1.5 rounded-full glass-modal border border-white/20 text-slate-100 text-xs font-medium shadow-2xl animate-in fade-in slide-in-from-bottom-2 duration-150"
        >
          {toastMessage}
        </div>
      )}

      {/* Field Guide & Science Modal */}
      <FieldGuideModal
        isOpen={isFieldGuideOpen}
        onClose={() => setIsFieldGuideOpen(false)}
      />

      {/* AI Sanctuary Studio Modal (Image Generation & Lyria Music) */}
      <AIGeneratorModal
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
        onApplyBackground={handleApplyBackground}
        onPlayMusic={(url) => soundscapeRef.current?.playAiMusic(url)}
        onStopMusic={() => soundscapeRef.current?.stopAiMusic()}
      />
    </main>
  );
}
