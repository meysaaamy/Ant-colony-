import test from 'node:test';
import assert from 'node:assert/strict';
import {
  weberFechner,
  exponentialEvaporation,
  saturatingDeposition,
  computeAntennaPositions,
  computeTropotaxisSteering,
  lineOfSight,
  interpolateStroke,
  resolveWallCollision,
  hashCoord,
  computePheromoneAlpha,
  computeWhiskerAvoidance,
} from './math';

test('Weber-Fechner stimulus logarithm', () => {
  assert.equal(weberFechner(0), 0);
  assert.equal(weberFechner(-5), 0);
  const stim10 = weberFechner(10);
  const stim100 = weberFechner(100);
  assert.ok(stim10 > 0);
  assert.ok(stim100 > stim10);
  assert.ok(Math.abs(stim10 - Math.log(11)) < 1e-6);
});

test('Exponential evaporation calculation', () => {
  const initial = 50;
  const lambda = 0.02;
  const dt = 1.0;
  const next = exponentialEvaporation(initial, dt, lambda);
  assert.ok(next < initial);
  assert.ok(next > 0);
  assert.ok(Math.abs(next - 50 * Math.exp(-0.02)) < 1e-6);
  assert.equal(exponentialEvaporation(0, 1, 0.02), 0);
});

test('Saturating deposition prevents runaway concentrations', () => {
  const depLow = saturatingDeposition(10, 0, 0.1, 0);
  const depHigh = saturatingDeposition(10, 0, 0.1, 100);
  assert.ok(depHigh < depLow, 'Deposition should saturate at high local concentrations');
  assert.ok(depLow > 0);
  assert.ok(depHigh > 0);

  const agedDep = saturatingDeposition(10, 5, 0.1, 0);
  assert.ok(agedDep < depLow, 'Older visits should deposit less pheromone');
});

test('Antenna sensor positions compute correct offsets', () => {
  const heading = 0; // facing +X
  const dist = 18;
  const angle = Math.PI / 4; // 45 deg
  const sensors = computeAntennaPositions(100, 100, heading, dist, angle);

  // Center should be at 118, 100
  assert.ok(Math.abs(sensors.cx - 118) < 1e-5);
  assert.ok(Math.abs(sensors.cy - 100) < 1e-5);

  // Left should be turned negative angle (upwards in canvas coordinates)
  assert.ok(sensors.ly < sensors.cy);
  // Right should be turned positive angle (downwards)
  assert.ok(sensors.ry > sensors.cy);
});

test('Tropotaxis steering responds to bilateral gradient', () => {
  // Balanced stimulus with zero noise -> near zero torque
  const balanced = computeTropotaxisSteering(1.5, 1.5, 1.5, 0, 1.0);
  assert.ok(Math.abs(balanced) < 0.05);

  // Right antenna has stronger stimulus -> positive steering torque (turns right)
  const turnRight = computeTropotaxisSteering(0.2, 1.0, 3.0, 0, 1.2);
  assert.ok(turnRight > 0.1, 'Should steer towards right antenna');

  // Left antenna has stronger stimulus -> negative steering torque (turns left)
  const turnLeft = computeTropotaxisSteering(3.0, 1.0, 0.2, 0, 1.2);
  assert.ok(turnLeft < -0.1, 'Should steer towards left antenna');
});

test('Line of sight raycasting identifies obstacles', () => {
  const cellSize = 10;
  // Wall placed at grid (5, 0) -> world x: 50..60, y: 0..10
  const isWall = (gx: number, gy: number) => gx === 5 && gy === 0;

  // Clear path from (10, 5) to (40, 5)
  assert.equal(lineOfSight(10, 5, 40, 5, isWall, cellSize), true);

  // Blocked path through (50, 5)
  assert.equal(lineOfSight(10, 5, 80, 5, isWall, cellSize), false);
});

test('Dense stroke interpolation generates continuous points', () => {
  const pts = interpolateStroke(0, 0, 100, 0, 10);
  assert.equal(pts.length, 10);
  assert.equal(pts[pts.length - 1].x, 100);
  assert.equal(pts[pts.length - 1].y, 0);

  // Short distance below step spacing returns endpoint
  const shortPts = interpolateStroke(0, 0, 1, 0, 10);
  assert.equal(shortPts.length, 1);
});

test('Wall collision detection and tangent sliding', () => {
  const cellSize = 10;
  // Wall at (5, 5) -> x: 50..60, y: 50..60
  const isWall = (gx: number, gy: number) => gx === 5 && gy === 5;

  // Ant circle radius 4 placed at (48, 55) penetrates left side of wall
  const res = resolveWallCollision(48, 55, 4, isWall, cellSize);
  assert.equal(res.collided, true);
  // Should be pushed away from the wall to x <= 46
  assert.ok(res.x <= 46.1);
  assert.ok(res.normalX < 0);
});

test('Spatial hash coordinate hashing is within bounds', () => {
  const idx = hashCoord(45, 65, 10, 20, 20);
  // gx = 4, gy = 6 -> 6 * 20 + 4 = 124
  assert.equal(idx, 124);

  // Clamp out of bounds
  const idxClamp = hashCoord(-50, 500, 10, 20, 20);
  assert.ok(idxClamp >= 0 && idxClamp < 400);
});

test('Pheromone alpha computation: Fog mode is significantly more opaque at high levels', () => {
  // At zero concentration, both are 0
  assert.equal(computePheromoneAlpha(0, 'glow'), 0);
  assert.equal(computePheromoneAlpha(0, 'fog'), 0);

  // At high concentration (e.g. 150/255)
  const glowAlpha = computePheromoneAlpha(150, 'glow');
  const fogAlpha = computePheromoneAlpha(150, 'fog');

  // Fog should be fully saturated / opaque (255)
  assert.equal(fogAlpha, 255);
  // At moderate level 80/255, Fog should have much higher opacity than Glow
  const glowMod = computePheromoneAlpha(80, 'glow');
  const fogMod = computePheromoneAlpha(80, 'fog');
  assert.ok(fogMod > glowMod, 'Fog mode should provide higher opacity than Glow mode at mid/high levels');
});

test('Proactive whisker avoidance steers away from obstacles before collision', () => {
  const cellSize = 10;
  // Wall at (5, 5) -> x: 50..60, y: 50..60
  const isWall = (gx: number, gy: number) => gx === 5 && gy === 5;

  // Ant approaching wall from left at (38, 55) heading East (0 radians)
  // Center feeler (dist 16) reaches x = 54 (inside wall at 50..60)
  const torque = computeWhiskerAvoidance(38, 55, 0, 16, Math.PI / 6, isWall, cellSize);
  assert.ok(Math.abs(torque) > 0.3, 'Should generate significant steering torque away from obstacle');

  // Clear area at (20, 20) generates zero avoidance torque
  const clearTorque = computeWhiskerAvoidance(20, 20, 0, 16, Math.PI / 6, isWall, cellSize);
  assert.equal(clearTorque, 0);
});
