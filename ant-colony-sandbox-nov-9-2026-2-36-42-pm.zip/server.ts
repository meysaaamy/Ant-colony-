import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

// Shared server-side Gemini client with 'aistudio-build' User-Agent header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

/**
 * Endpoint: POST /api/generate-image
 * Generates high-quality macro background plates, mineral terrain, or bio-crystal textures.
 * Uses gemini-nano-banana-2.1 / gemini-3-pro-image with 1K, 2K, 4K resolution selection.
 */
app.post('/api/generate-image', async (req: Request, res: Response): Promise<void> => {
  try {
    const { prompt, imageSize = '1K', aspectRatio = '16:9' } = req.body;

    if (!prompt) {
      res.status(400).json({ error: 'Prompt is required' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      // Offline fallback: Generate procedural macro substrate SVG data URL
      const fallbackSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
        <defs>
          <radialGradient id="grad1" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
            <stop offset="0%" style="stop-color:#0d1826;stop-opacity:1" />
            <stop offset="60%" style="stop-color:#060a12;stop-opacity:1" />
            <stop offset="100%" style="stop-color:#020407;stop-opacity:1" />
          </radialGradient>
          <filter id="noise">
            <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="4" result="noise"/>
            <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.15 0"/>
          </filter>
        </defs>
        <rect width="1024" height="1024" fill="url(#grad1)" />
        <rect width="1024" height="1024" filter="url(#noise)" />
        <circle cx="300" cy="400" r="180" fill="#003366" opacity="0.25" filter="blur(40px)"/>
        <circle cx="720" cy="620" r="140" fill="#00e676" opacity="0.18" filter="blur(50px)"/>
        <circle cx="500" cy="780" r="160" fill="#ffae00" opacity="0.15" filter="blur(60px)"/>
      </svg>`;
      const fallbackUrl = `data:image/svg+xml;base64,${Buffer.from(fallbackSvg).toString('base64')}`;

      res.json({
        imageUrl: fallbackUrl,
        prompt,
        notice: 'Generated using procedural bio-sanctuary generator (Add GEMINI_API_KEY in Secrets for live AI rendering).',
      });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-nano-banana-2.1',
      contents: {
        parts: [
          {
            text: `Macro nature cinematography, ultra-detailed bioluminescent macro subterranean substrate: ${prompt}. Dark bio-digital sanctuary, abyssal black background (#03050a), glowing cyan and amber filaments, mineral crust, high contrast, 8k resolution, cinematic lighting.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as '16:9' | '1:1' | '9:16',
          imageSize: imageSize as '1K' | '2K' | '4K',
        },
      },
    });

    let imageUrl = '';
    let textDescription = '';

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData?.data) {
        const mime = part.inlineData.mimeType || 'image/png';
        imageUrl = `data:${mime};base64,${part.inlineData.data}`;
      } else if (part.text) {
        textDescription += part.text;
      }
    }

    if (!imageUrl) {
      res.status(500).json({ error: 'No image data returned from model', details: textDescription });
      return;
    }

    res.json({
      imageUrl,
      prompt,
      description: textDescription,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error('Error in /api/generate-image:', errorMsg);
    res.status(500).json({ error: errorMsg });
  }
});

/**
 * Endpoint: POST /api/generate-music
 * Generates ambient macro sanctuary music with Lyria (lyria-3-clip-preview / lyria-3-pro-preview).
 */
app.post('/api/generate-music', async (req: Request, res: Response): Promise<void> => {
  try {
    const { prompt, modelType = 'clip' } = req.body;

    const selectedModel = modelType === 'pro' ? 'lyria-3-pro-preview' : 'lyria-3-clip-preview';

    if (!process.env.GEMINI_API_KEY) {
      res.status(400).json({
        error: 'GEMINI_API_KEY is not configured in environment secrets.',
        notice: 'The app is using the built-in procedural Web Audio synthesizer for ambient soundscapes.',
      });
      return;
    }

    const responseStream = await ai.models.generateContentStream({
      model: selectedModel,
      contents: prompt || 'Hypnotic dark ambient subterranean bio-music, delicate bioluminescent crystal chimes, warm sub-bass pulse, organic nature drone, relaxing macro sanctuary soundscape.',
    });

    const audioChunks: Buffer[] = [];
    let lyrics = '';
    let mimeType = 'audio/mpeg';

    for await (const chunk of responseStream) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;
      for (const part of parts) {
        if (part.inlineData?.data) {
          if (audioChunks.length === 0 && part.inlineData.mimeType) {
            mimeType = part.inlineData.mimeType;
          }
          audioChunks.push(Buffer.from(part.inlineData.data, 'base64'));
        }
        if (part.text) {
          lyrics += part.text;
        }
      }
    }

    if (audioChunks.length === 0) {
      res.status(500).json({ error: 'No audio returned from Lyria model', details: lyrics });
      return;
    }

    const audioBase64 = Buffer.concat(audioChunks).toString('base64');
    const audioDataUrl = `data:${mimeType};base64,${audioBase64}`;

    res.json({
      audioDataUrl,
      lyrics,
      prompt,
      model: selectedModel,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error('Error in /api/generate-music:', errorMsg);
    res.status(500).json({ error: errorMsg });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    // Mount Vite dev server middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve production build
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
